'use strict';
// 顾问协作自动化（老板 2026-11-27 规则）：
// 场景1：老板让问 GPT → 得到回复 → 老板批准 → 执行。
// 场景2：老板批准后执行反复失败 3 次 → 执行方自动问 GPT → 带方案继续执行 → 回复老板。
// 本模块实现"自动问 + 自动接续 + 可回读证据"，不实现业务判断。
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawnSync } = require('node:child_process');

const API = 9333; // 境外窗 9233 的 CDP 代理端口
const HOME = path.join(os.homedir(), '.workbuddy', 'browser-cli-dual-vpn');
const EVID_DIR = path.join(HOME, 'consult-evidence');
const FAIL_LOG = path.join(HOME, 'failures.json');

function ensure() { fs.mkdirSync(EVID_DIR, { recursive: true }); }
function now() { return new Date().toISOString(); }
function readJson(p, fallback) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; } }
function writeJson(p, o) { ensure(); fs.writeFileSync(p, JSON.stringify(o, null, 2) + '\n', 'utf8'); }

function cmd(name, args = []) {
  const body = JSON.stringify({ cmd: name, args });
  const r = spawnSync('curl', ['-s', '-m', '30', '-X', 'POST', 'http://127.0.0.1:' + API + '/cmd',
    '-H', 'Content-Type: application/json', '-d', body], { encoding: 'utf8' });
  if (r.status !== 0) return { ok: false, error: r.stderr };
  try { return JSON.parse(r.stdout || '{}'); } catch { return { ok: false, raw: r.stdout }; }
}
function ev(js) { const r = cmd('eval', [js]); return r.result || ''; }
function sleep(ms) { spawnSync('node', ['-e', 'setTimeout(()=>{},' + ms + ')']); }

// 失败计数：同一问题同一方法重试不重复计数；换方法算新的一次尝试。
function recordFailure(taskId, method, reason) {
  const data = readJson(FAIL_LOG, { tasks: {} });
  const t = data.tasks[taskId] || { attempts: [], createdAt: now() };
  const last = t.attempts[t.attempts.length - 1];
  if (last && last.method === method) last.retries = (last.retries || 0) + 1;
  else t.attempts.push({ method, reason, at: now(), retries: 0 });
  t.updatedAt = now();
  data.tasks[taskId] = t;
  writeJson(FAIL_LOG, data);
  return { taskId, methodsTried: t.attempts.length, shouldConsult: t.attempts.length >= 3 };
}

// 精确锁定 form 内的编辑器（页面上可能有多个 ProseMirror，历史消息编辑态是陷阱）
const FOCUS_JS = "(function(){var p=document.querySelector('form div.ProseMirror[contenteditable=\"true\"]')||document.querySelector('form .ProseMirror');if(!p)return 'NO_EDITOR';p.focus();return 'OK'})()";
const CLEAR_JS = "(function(){var p=document.querySelector('form div.ProseMirror[contenteditable=\"true\"]')||document.querySelector('form .ProseMirror');p.focus();document.execCommand('selectAll',false,null);return 'CLEAR'})()";
const TYPED_JS = "(function(){var p=document.querySelector('form div.ProseMirror[contenteditable=\"true\"]')||document.querySelector('form .ProseMirror');var b=Array.from((document.querySelector('form')||document).querySelectorAll('button')).find(x=>(x.getAttribute('aria-label')||'')==='发送');return JSON.stringify({len:p?p.innerText.length:0,btn:!!b,btnEnabled:b?!b.disabled:false})})()";
const SEND_JS = "(function(){var f=document.querySelector('form');if(!f)return 'NO_FORM';var b=Array.from(f.querySelectorAll('button')).find(x=>(x.getAttribute('aria-label')||'')==='发送');if(!b)return 'NO_BTN';b.click();return 'SENT'})()";
const STATE_JS = "(function(){var t=document.body.innerText||'';return JSON.stringify({len:t.length,done:/回答已完成|ChatGPT can make mistakes|ChatGPT 可能会出错/.test(t.slice(-500)),err:t.includes('未收到 ChatGPT 的回复'),ctx:/上下文.*上限/.test(t),tail:t.slice(-3000)})})()";

function parse(js) { try { return JSON.parse(ev(js)); } catch { return {}; } }

// 上下文接续：点页面内「新聊天」，硬判据 = 出现"接续自 <原对话名>"
function continuationCheck() {
  const before = parse("JSON.stringify({title:document.title,ctx:/上下文.*上限/.test(document.body.innerText)})");
  if (!before.ctx) return { needed: false };
  const clicked = ev("(function(){var b=Array.from(document.querySelectorAll('button')).find(x=>(x.getAttribute('aria-label')||x.textContent||'').trim()==='新聊天');if(!b)return 'NO_BTN';b.click();return 'CLICKED'})()");
  sleep(4000);
  const after = parse("JSON.stringify({continuation:/接续自/.test(document.body.innerText),head:document.body.innerText.slice(0,400),url:location.href})");
  const ok = after.continuation === true;
  return { needed: true, clicked, ok, after,
    note: ok ? '接续成功' : '接续失败：未出现"接续自"标识，禁止冒充接续' };
}

// 问 GPT：返回可回读证据；失败时不假装成功
function ask(packetFile, timeoutSec = 180) {
  ensure();
  const text = fs.readFileSync(packetFile, 'utf8');
  const id = 'q-' + Date.now();
  const packetCopy = path.join(EVID_DIR, id + '-packet.md');
  fs.copyFileSync(packetFile, packetCopy);
  const focus = ev(FOCUS_JS);
  if (String(focus).includes('NO_EDITOR')) return { ok: false, error: 'NO_EDITOR' };
  ev(CLEAR_JS);
  cmd('type', [text]);
  sleep(1200);
  const typed = parse(TYPED_JS);
  if (!typed.len || typed.len < text.length * 0.9) {
    return { ok: false, error: 'TYPED_TOO_SHORT', expected: Math.round(text.length * 0.9), actual: typed.len };
  }
  const sent = ev(SEND_JS);
  if (!String(sent).includes('SENT')) return { ok: false, error: 'SEND_FAILED', detail: String(sent) };
  const t0 = Date.now();
  let last = {};
  while ((Date.now() - t0) / 1000 < timeoutSec) {
    sleep(4000);
    last = parse(STATE_JS);
    if (last.err) break;
    if (last.done && last.len > 0) break;
  }
  const replyFile = path.join(EVID_DIR, id + '-reply.md');
  fs.writeFileSync(replyFile, (last.tail || '') + '\n', 'utf8');
  const evidence = { id, at: now(), packetFile: packetCopy, packetChars: text.length,
    typedChars: typed.len, sendResult: String(sent), replyFile,
    replyChars: (last.tail || '').length, elapsedSec: Math.round((Date.now() - t0) / 1000),
    err: Boolean(last.err), ctx: Boolean(last.ctx) };
  writeJson(path.join(EVID_DIR, id + '-evidence.json'), evidence);
  return { ok: Boolean(last.done && !last.err), evidence, reply: last.tail || '' };
}

function usage() {
  console.log(`consultant.js —— 顾问协作自动化

  node consultant.js fail <taskId> <method> <reason>   记录一次失败，返回是否达到3次
  node consultant.js continuation-check                 检查/执行上下文接续（硬判据：接续自）
  node consultant.js ask <信息包文件> [超时秒]          问GPT并留可回读证据
  node consultant.js evidence                          列出所有咨询证据
`);
}

(async () => {
  const [a, ...rest] = process.argv.slice(2);
  let out;
  switch (a) {
    case 'fail': out = recordFailure(rest[0], rest[1], rest[2] || ''); break;
    case 'continuation-check': out = continuationCheck(); break;
    case 'ask': out = ask(rest[0], Number(rest[1] || 180)); break;
    case 'evidence': ensure(); out = fs.readdirSync(EVID_DIR).map(f => path.join(EVID_DIR, f)); break;
    default: usage(); return;
  }
  console.log(JSON.stringify(out, null, 2));
  if (out && out.ok === false) process.exitCode = 4;
})();
