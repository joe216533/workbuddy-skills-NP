# 浏览器CLI双开VPN v1.0.2

按需维护最多两个浏览器出口槽位：vpn（境外，GPT/Gemini/GitHub）与 direct（国内直连，小红书/夸克/百度）。同出口复用、按域名路由、未知域名拦截；PID 身份核验后安全 down。CDP 控制与 GPT/Gemini 顾问协作为附属能力。

## 安装

**下载渠道按登录身份决策**：未登录夸克→GitHub 直链；已登录 159（创建者）→直接 download；已登录其他账号→saveas→download。降级条件只有"未登录"，不是"操作失败"。所有渠道都校验 SHA256。


1. 解压到技能目录 `browser-cli-dual-vpn/`（目录名必须与 name 一致）
2. Node ≥ 18，无需 npm install（零第三方依赖）
3. 本机需有 Chrome，并能访问本地代理 `127.0.0.1:11719`（境外窗需要）
4. 跑 `node browser-cli.js selfcheck`

## 快速开始

```bash
node browser-cli.js route <url>           # 查出口：vpn/direct/未知拦截
node browser-cli.js open <url>            # 按出口按需启动或复用，并在该实例打开
node browser-cli.js up [vpn|direct]       # 启动指定实例（不传=不自动开）
node browser-cli.js check                 # CDP、代理参数硬证据
node browser-cli.js exit-ip               # 公网出口实测
node browser-cli.js down [vpn|direct|all] # 身份核验后仅停本轮登记实例
node browser-cli.js selfcheck             # 按需双实例自检：0→VPN→DIRECT→2
```

浏览器窗口**默认可见**（需要扫码登录），不会离屏。

## 验收状态（2026-11-27）

| 测试 | 状态 | 说明 |
|-|-|-|
| T1 双窗启动 | PASS | 三个实例同时运行，独立 profile |
| T2 出口隔离 | PASS | 国内 101.65.161.134 / 境外 85.121.125.112 |
| T3 代理硬证据 | PASS | 境外窗命令行含 `--proxy-server`，国内窗不含 |
| T4 异常不假 PASS | PASS | 端口冲突 / 未知 profile 均报失败状态 |
| T5 安全恢复 | PASS | 复用浏览器不被误停 |
| T8 双 GPT 并发 | PASS | 两个独立 GPT 浏览器并发发信息包，无串台 |
| T6 干净环境 | **待另一台电脑验证** | 本机 Node 启动路径存在缺陷，已改 PowerShell 启动器；换机验证后再关闭 |

T6 不阻塞本版发布：它验证的是"换机独立性"，本机已测出并修复了启动器缺陷，真实换机验证由另一台电脑完成。

## 已知边界

- 只支持 Windows（Chrome 启动用 PowerShell）
- 不自动开关 VPN/TUN；基线 GLOBAL=Pioneer + tun=true 由使用者自行维护
- 技能只读 VPN 状态，不修改全局代理配置
