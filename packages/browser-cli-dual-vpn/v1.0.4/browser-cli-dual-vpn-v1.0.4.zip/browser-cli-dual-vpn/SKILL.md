---
name: browser-cli-dual-vpn
description: 浏览器CLI双开VPN（v1.0.2 按需双实例）。维护最多两个浏览器出口槽位——一个 VPN（境外，GPT/Gemini/GitHub）、一个 DIRECT（国内直连，小红书/夸克/百度）；按目标域名按需启动或复用，同出口复用不重复开，最多两个实例。含严格域名出口路由与未知域名拦截、独立 Profile/CDP/PID 身份核验、down 身份不符拒绝终止、公网出口实测、VPN 只读基线恢复；并提供 CDP 浏览器控制与 GPT/Gemini 信息包发送、回复抓取、顾问协作闭环。当需要按网络出口管理浏览器时，用 route 查出口、open 打开网站。
display_name: "浏览器CLI双开VPN"
display_name_en: "Browser CLI Dual VPN"
description_zh: "按需维护最多两个浏览器出口实例（VPN 境外 + DIRECT 国内直连），同出口复用、按域名路由、未知域名拦截，含 PID 身份核验安全关闭、出口实测与基线恢复；提供 CDP 控制与 GPT/Gemini 顾问协作。"
description_en: "On-demand dual-instance browser egress manager: at most one VPN (overseas) and one DIRECT (domestic) Chrome, reuse by egress, strict domain routing with unknown-domain interception, PID-identity-verified down, egress IP checks and baseline restore; includes CDP control and GPT/Gemini consultant workflow."
version: 1.0.4
---

# 浏览器CLI双开VPN

## 定位

主体：**按需双实例 + 网络出口路由**。不是固定开两个浏览器，而是维护两个出口槽位：

| 槽位 | 出口 | 典型网站 | CDP | API | Profile | 代理 |
|-|-|-|-|-|-|-|
| vpn | 境外 | GPT / Gemini / GitHub | 9233 | 9342 | chrome-gpt-profile | `127.0.0.1:11719` |
| direct | 国内直连 | 小红书 / 夸克 / 百度 | 9231 | 9341 | chrome-xhs-profile | 无 |

**核心规则**：
- 一个出口最多一个实例，总数 0–2；不要求两个同时存在
- 同出口复用：GPT → Gemini → GitHub 都在同一个 vpn 实例，不新开
- 不同出口才新开：vpn 已开、要开小红书 → 另开 direct 实例
- 已满 2 个时按出口复用，绝不开第三个；也不为开新站关闭已有实例
- 未知域名不猜出口、不导航，问老板；跨域跳转重新判定
- 禁止用"把 vpn 窗临时关 VPN"当直连——不切代理、不共用 Profile
- 旧 `domestic`→`direct`、`overseas`→`vpn` 别名兼容；`overseas2`/9234 已退出实例池，调用返回 `SLOT_RETIRED_IN_V1_0_2`

域名映射见 `domain-routing.json`（严格边界匹配，`github.com.evil.example` 不会误匹配 `github.com`）。附属：CDP 浏览器控制、GPT/Gemini 信息包发送与回复抓取。

## 硬规则（违反即失败）

1. **浏览器必须让用户看得见。** 启动参数永远 `CDP_OFFSCREEN=0`，禁止 `--window-position=-32000,-32000`。用户需要扫码登录、人工确认；看不见窗口等于功能不可用。启动后应确认窗口在可视区，不能只靠 CDP 能连通就算成功。
2. **只读 VPN 状态，不擅自改。** 当前基线 `GLOBAL=Pioneer`、`tun.enable=true`。技能启动和退出都不能改；切换 VPN 必须先经老板批准。
3. **不杀复用的浏览器，且 down 必须核验身份。** `down` 只停本轮启动并登记 PID 的进程；复用（老板原本在用的，如 9250）必须保留。禁止按进程名或数量杀 Chrome。v1.0.2 起 down 前必须逐项核对 PID / executablePath / creationDate / CDP 端口 / profile，任一项不符 → `SAFETY BLOCK`，一个 kill 都不执行（防 PID 复用误杀）。启动脚本 `launch-chrome.ps1` 按 CDP 端口 + profile 唯一定位真实 Chrome 主进程，登记 `pid = $w.ProcessId`（不是启动器 PID）；零匹配或多匹配都 fail closed。
3a. **实例数硬上限 2。** 异常恢复、重复调用、并发调用都不得突破；两个请求同时发现 VPN 不存在时只能创建一个实例。
4. **`--no-proxy-server` ≠ 绕过 TUN。** 必须实测公网出口 IP 才能判定隔离，不能只看 Chrome 启动参数。
5. **不把没测的写成已测。** 13.5.1 上下文接续在本技能首次封装时未真实触发，只能写"继承规程"。
6. **自检只用本包内代码**，禁止运行时依赖其他技能目录或 `work/` 下的临时脚本。

## 命令

```bash
node browser-cli.js route <url|host>                        # 查出口：vpn/direct/未知拦截
node browser-cli.js open <url>                              # 按出口按需启动或复用实例，并在该实例打开 URL
node browser-cli.js up [vpn|direct]                         # 启动/复用指定实例（不传=不自动开）
node browser-cli.js check [vpn|direct]                      # CDP + 代理参数硬证据
node browser-cli.js exit-ip [vpn|direct]                    # 公网出口实测
node browser-cli.js baseline [save|show]                    # 只读保存/显示 VPN 基线
node browser-cli.js down [vpn|direct|all]                   # 身份核验后仅停本轮登记实例
node browser-cli.js status                                  # 实例池登记状态
node browser-cli.js selfcheck                               # 按需双实例：初始0→VPN→DIRECT→2，第三个被拒
```

**典型用法**：问 GPT → `open https://chatgpt.com`（只起 vpn）；再发 Gemini → `open https://gemini.google.com`（复用 vpn）；再开小红书 → `open https://www.xiaohongshu.com`（另起 direct）；再回 GPT → 复用原 vpn。全程 2 个实例。

## v1.0.1 → v1.0.2 升级迁移

- 三个旧 Profile **全部保留**，不删、不改名、不合并；它们只是 `legacy_profiles`，逻辑实例按需分配，不硬绑定某个旧目录
- 旧 `state.json` **原样备份**（`state.legacy-<ts>.json`），**不直接复用**三窗登记；新建 schema_version 2 的 `instances: {}`，初始 0 个实例
- `baseline.json` 保留或按结构迁移，不直接重置
- 升级前若旧浏览器进程仍在运行，先正常关闭再迁移；只改 state 留旧进程继续跑是禁止的
- 未确认旧 Profile 与新实例的对应关系前，不自动启动浏览器

## 安装包下载渠道决策（自举）

安装本技能自身时，先查夸克 CLI **真实登录身份**，不得按文件名/分享者/缓存猜：

| 状态 | 动作 |
|-|-|
| 未登录夸克 | 不 saveas、不 download，直接 GitHub 直链，校验 SHA256 |
| 已登录且为分享创建者 159 | **直接 download**，不 saveas；失败报错，不自动 saveas |
| 已登录其他账号 | saveas 转存成功后再 download；失败报错，不自动切 GitHub |

**降级条件只有"未登录"**，不是"操作失败"。任何渠道下载后都校验 SHA256，不一致禁止安装。本规则写在此处是为了自举——技能三未安装时不能依赖技能一已安装。

## 状态机

`PASS / WARN / NEEDS_CONFIG / CLI_MISSING / PORT_CONFLICT / PROXY_UNAVAILABLE / ERROR`

退出码：有非 PASS/WARN 状态 → 4；正常 → 0。

## 协作规则（写在这里，不伪装成程序功能）

- **S3 信息包六块**：背景与前置、本轮做了什么（含真实数字）、没做到什么、自曝、反对至少 1 条（无实质反对就写"本轮未发现"，不许编造）、提问。由大模型结合上下文填写，脚本只提供模板。
- **S6 终态判定**：只有设计方明确输出"验收通过"才算；"有条件通过/待验收/先做这几项"一律未到终态。语义由大模型判断，脚本只提供清单。
- **S8 回报四块**：做了什么、没做到什么、反对、提问。顺序固定，内容由执行方填写，脚本不得编造。
- **A/B/C/D 任务路由**：模型判断任务类型，脚本执行路由结果；不让代码仅凭 URL 决定开几个窗。
- **GPT 是唯一主设计方**（能宣布验收）；Gemini 副审只在方案成型前、连续 3 轮不收敛、终态认定前三个节点介入，不能宣布验收。
- **13.5.1 上下文接续**：GPT 达上下文上限时，点页面内「新聊天」，确认出现"接续自 <原对话名>"，重发自包含信息包；不得新开窗口/普通空白对话冒充。

## 本对话踩过的坑（已纳入容错）

- ChatGPT 页面选择器会变：`.ProseMirror`、aria-label「发送」集中配置，失效时报明确错误，不要静默改用旧选择器。
- 中文长文本不要走 shell 参数，用文件传递。
- Python 调 bash 包装的 CLI（lark-cli）会失败，要明确运行环境和退出码。
- 文本长度稳定判回复完成会误判长停顿，必须结合"回答已完成"标记 + 停止按钮 + 角色 + 尾部指纹。
- 发送成功 ≠ 已回复 ≠ 验收通过。
- `down` 必须登记 Chrome 主进程 PID（按 profile + CDP 端口精确匹配），否则只停 Node 服务、Chrome 留着占端口。

## 顾问协作自动化（老板 2026-11-27 规则）

GPT 不是"老板叫才问"。有两个场景，必须分清：

| 场景 | 流程 | 要不要请示老板 |
|-|-|-|
| 场景 1 · 老板发起 | 老板给任务 → 执行方整理信息问 GPT → 回复老板 → 老板批准 → 执行 | 问之前不用，执行前必须批准 |
| 场景 2 · 失败触发 | 老板已批准执行 → 执行反复失败达 3 次 → **执行方自动开浏览器问 GPT** → 带方案继续执行成功 → 回复老板 | **自动问 GPT 不用再请示**（已授权） |

### "失败 3 次"的可执行定义

- **同一方法重试不重复计数**（第一次失败后同一方法再试 2 次，仍算 1 次尝试）
- **换一种实质不同的方法才算新的一次尝试**
- 由代码计数，不让执行方凭感觉判断：`node runtime/consultant.js fail <taskId> <method> <reason>`
- 计数存 `~/.workbuddy/browser-cli-dual-vpn/failures.json`
- 返回 `shouldConsult: true` 时，**必须**自动进入下面的咨询流程，不得跳过

### 自动咨询流程（场景 2）

1. 写自包含信息包到文件（背景 / 已批准的方案 / 做了什么 / **三次失败的真实报错与已排除项** / 需要 GPT 裁决什么）。中文长文本走文件，不走 shell 参数。
2. 若上下文已满 → 执行 `node runtime/consultant.js continuation-check`：
   - 它点页面内「新聊天」并硬判据检查是否出现 **"接续自 <原对话名>"**
   - `ok:false` 时**禁止声称接续成功**，如实报告并停止（不得用普通空白对话冒充）
3. `node runtime/consultant.js ask <信息包文件> [超时秒]`
   - 精确锁定 `form div.ProseMirror[contenteditable="true"]`（页面上可能有历史消息编辑框，选错就发不出去）
   - 输入字数 ≥ 信息包 90% 才点 form 内的「发送」按钮
   - 轮询"回答已完成"标记 + 停止按钮 + 尾部指纹
   - 页面报"未收到 ChatGPT 的回复"立即判失败，不假装成功
4. 拿 GPT 方案后继续执行；**若方案涉及改代码/删文件/外部写操作，仍回到老板批准**（自动授权只覆盖"问 GPT"这个动作本身）
5. 成功后回复老板，附证据路径

### 可回读证据（防假阳性）

每次咨询自动在 `~/.workbuddy/browser-cli-dual-vpn/consult-evidence/` 留下：
- `<id>-packet.md` 信息包原文
- `<id>-reply.md` GPT 回复原文
- `<id>-evidence.json` 时间戳 / 输入字数 / 发送结果 / 回复字数 / 耗时 / 是否报错

**没有这三份文件，不得说"已问过 GPT"。** 执行方写一句"已咨询"不算证据。

### 命令速查（补充）

```bash
node runtime/consultant.js fail <taskId> <method> <reason>   # 记一次失败，返回 shouldConsult
node runtime/consultant.js continuation-check                # 上下文接续检查（硬判据）
node runtime/consultant.js ask <信息包文件> [超时秒]          # 问GPT并留证据
node runtime/consultant.js evidence                          # 列出所有证据文件
```


## 版本检查（只读，独立于自检）

本技能带统一只读版本检查器。按 00A 第21节，版本唯一权威是 GitHub 正式发布 Tag，manifest.json / SKILL.md / 00C / 安装语言 / 包名都是镜像。

```bash
node scripts/check-version.js            # 本地 + 远程（网络失败自动降级）
node scripts/check-version.js --offline  # 仅本地，主动离线
node scripts/check-version.js --json     # JSON 输出
```

退出码：0=通过；1=版本不一致或本地落后；2=本地文件异常；3=本地通过但远程不可用（主动离线不返回 3）；4=检查器异常。

硬边界：检查器**只读**，不修改/下载/覆盖任何文件，不启动 VPN、不改代理。发现新版只提示，绝不自行升级。升级必须走 00A 第20节（用户确认 + 备份 + 迁移 + 回滚）。远程不可用时只做本地检查，不得误判技能损坏或已最新。版本检查不改变原有 verify/selfcheck 行为与退出码。
