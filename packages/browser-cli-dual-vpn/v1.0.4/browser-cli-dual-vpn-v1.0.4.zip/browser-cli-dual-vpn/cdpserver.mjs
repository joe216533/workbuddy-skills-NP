// 常驻 CDP 代理服务：自己拉起 Chrome 并保持其存活，对外提供 HTTP 操作接口
// 用法: node cdpserver.mjs   （作为后台常驻任务运行）
// 调用: curl -s -X POST http://127.0.0.1:9333/cmd -d '{"cmd":"shot","args":["D:/a.png"]}'
import http from 'node:http';
import { spawn, execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// 可移植：优先用 CDP_CHROME，其次探测常见安装位置，最后退回 PATH 上的 chrome
function findChrome() {
  if (process.env.CDP_CHROME) return process.env.CDP_CHROME;
  const candidates = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'Application', 'chrome.exe') : '',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    '/usr/bin/google-chrome', '/usr/bin/chromium', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  ].filter(Boolean);
  for (const p of candidates) { try { if (fs.existsSync(p)) return p; } catch {} }
  return process.platform === 'win32' ? 'chrome.exe' : 'google-chrome';
}
const CHROME = findChrome();
// 单实例仅占用一组端口；多开请为每个实例指定不同的 CDP_PORT / CDP_API / CDP_PROFILE
// 例: CDP_PORT=9223 CDP_API=9334 CDP_PROFILE=D:/x/p2 CDP_KEYWORD=douyin node cdpserver.mjs
const PORT = Number(process.env.CDP_PORT || 9222);
const API = Number(process.env.CDP_API || 9333);
// 使用独立 profile：与用户日常浏览器完全隔离，互不抢占登录态/标签页/窗口
// 注意：绝不能用默认 User Data，否则 Chrome 会把启动请求转给已运行进程，调试端口不生效
// 必须解析成绝对路径：传相对路径时, node 拉起的 Chrome 会把它解析到非预期的 cwd,
// 导致 profile 用错（且实测 9222 调试端口不绑定, cdpserver 等待超时退出）
// 默认 profile 放在当前工作目录，避免写死某台机器的绝对路径
const PROFILE = path.resolve(process.env.CDP_PROFILE || './chrome-cdp-profile');
const START_URL = process.env.CDP_URL || 'https://viggle.ai/meme/app/mix';
// 只让本浏览器实例走指定代理(如 127.0.0.1:11719)，不影响系统全局与其他浏览器
const PROXY = process.env.CDP_PROXY || '';
// 窗口偏移到屏幕外，避免弹出时抢占用户焦点与屏幕空间（headless 时忽略）
const OFFSCREEN = process.env.CDP_OFFSCREEN !== '0';
const HEADLESS = process.env.CDP_HEADLESS === '1';
const WIN_W = Number(process.env.CDP_WIN_W || 1280);
const WIN_H = Number(process.env.CDP_WIN_H || 900);

let ws = null;
let idCounter = 0;
let currentTargetId = null;
const pending = new Map();
let targetKeyword = process.env.CDP_KEYWORD || 'viggle'; // 当前操作的页面（可被 switch 切换）

function log(...a) { console.log(new Date().toISOString().slice(11, 19), ...a); }

// Windows 下改用 PowerShell Start-Process 启动 Chrome。
// GPT P32 裁定 + 本机实测：Node spawn 起的 Chrome 进程存在但 DevTools 端口不绑定；
// PowerShell Start-Process 用相同参数则 2 秒内 DevTools listening。
// Node 只负责 CDP 服务和生命周期管理，不再直接 spawn Chrome。
function quoteWindowsArg(value) {
  const str = String(value);
  let result = '"';
  let slashes = 0;
  for (const ch of str) {
    if (ch === '\\') { slashes++; }
    else if (ch === '"') { result += '\\'.repeat(slashes * 2 + 1) + '"'; slashes = 0; }
    else { result += '\\'.repeat(slashes) + ch; slashes = 0; }
  }
  result += '\\'.repeat(slashes * 2) + '"';
  return result;
}
function psQuote(v) { return "'" + String(v).replace(/'/g, "''") + "'"; }

function spawnChrome() {
  const args = [
    `--remote-debugging-port=${PORT}`,
    `--remote-debugging-address=127.0.0.1`,
    ...(PROXY ? [`--proxy-server=${PROXY}`] : []),
    `--user-data-dir=${PROFILE}`,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-features=Translate,OptimizationHints,MediaRouter',
    '--disable-session-crashed-bubble',
    '--disable-crash-reporter',
    '--disable-breakpad',
    '--noerrdialogs',
    '--deny-permission-prompts',
    '--disable-notifications',
    '--disable-popup-blocking',
    '--disable-background-networking',
    '--disable-component-update',
    '--disable-sync',
    '--disable-domain-reliability',
    '--metrics-recording-only',
    '--safebrowsing-disable-auto-update',
  ];
  if (HEADLESS) args.push('--headless=new');
  // 硬规则：用户必须看得见窗口，绝不设 --window-position=-32000,-32000
  args.push(`--window-size=${WIN_W},${WIN_H}`, START_URL);
  // 实测：EncodedCommand 启的 Chrome 进程在但 DevTools 不绑定；独立 .ps1 文件方式稳定成功。
  // 所以这里调用包内 launch-chrome.ps1，参数用 -File 逐个传，不经字符串拼接。
  const stateDir = path.resolve(path.dirname(PROFILE), '..');
  fs.mkdirSync(stateDir, { recursive: true });
  const launcher = path.join(__dirname, 'launch-chrome.ps1');
  const psArgs = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', launcher,
    '-ChromePath', CHROME, '-Port', String(PORT), '-ProfileDir', PROFILE];
  if (PROXY) psArgs.push('-Proxy', PROXY);
  // 不设 windowsHide：实测该选项会让 Start-Process 起的 Chrome 拿不到正常桌面会话，
  // 进程在但 DevTools 端口不绑定。
  const out = execFileSync('powershell.exe', psArgs,
    { encoding: 'utf8', timeout: 20000 });
  const info = JSON.parse(out.trim().split(/\r?\n/).pop());
  // 保存完整身份（PID + 可执行文件 + 命令行 + 创建时间），供 down 核对后精确停止
  fs.writeFileSync(path.join(stateDir, 'chrome-' + PORT + '.json'),
    JSON.stringify({ ...info, port: PORT, userDataDir: path.resolve(PROFILE), startedAt: new Date().toISOString() }, null, 2), 'utf8');
  log('Chrome 已启动 pid=' + info.pid + ' port=' + PORT + '（PowerShell Start-Process）');
  return { pid: info.pid, kill() {}, identity: info };
}

// CDP HTTP 统一入口：Chrome 可能只绑 [::1]，必须双栈回退。
// 返回 {ok, json}；所有 /json/* 调用都走这里，禁止直接 fetch 127.0.0.1:PORT。
async function cdpHttp(pathname, opts = {}) {
  for (const h of ['127.0.0.1', '[::1]']) {
    try {
      const r = await fetch(`http://${h}:${PORT}${pathname}`, { signal: AbortSignal.timeout(opts.timeout || 3000) });
      if (r.ok) {
        const text = await r.text();
        let json = null; try { json = JSON.parse(text); } catch {}
        return { ok: true, json, text };
      }
    } catch {}
  }
  return { ok: false, json: null, text: '' };
}

// Chrome 136+ 的 DevTools 可能只绑在 IPv6 回环 [::1]，不能只探测 127.0.0.1。
// 实测：DevTools listening on ws://[::1]:PORT 时，127.0.0.1 无监听，导致误判"端口未就绪"。
async function waitPort(retries = 30) {
  for (let i = 0; i < retries; i++) {
    if ((await cdpHttp('/json/version', { timeout: 1500 })).ok) return true;
    await new Promise(r => setTimeout(r, 800));
  }
  return false;
}

function connectWS() {
  return new Promise(async (resolve, reject) => {
    const list = (await cdpHttp('/json/list')).json || [];
    let target = list.find(t => t.type === 'page' && t.url.includes(targetKeyword))
      || list.find(t => t.type === 'page');
    if (!target) return reject(new Error('无页面'));
    currentTargetId = target.id;
    const w = new WebSocket(target.webSocketDebuggerUrl);
    w.addEventListener('open', () => resolve(w));
    w.addEventListener('error', reject);
  });
}

function send(method, params = {}) {
  const id = ++idCounter;
  ws.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    setTimeout(() => { if (pending.has(id)) { pending.delete(id); reject(new Error('timeout ' + method)); } }, 90000);
  });
}

async function ensure() {
  if (ws && ws.readyState === 1) return;
  let ok = false;
  ok = (await cdpHttp('/json/version', { timeout: 1500 })).ok;
  if (!ok) { log('启动 Chrome...'); chrome = spawnChrome(); ok = await waitPort(); if (!ok) throw new Error('Chrome 端口未就绪'); }
  ws = await connectWS();
  ws.addEventListener('message', (ev) => {
    const m = JSON.parse(ev.data);
    if (m.id && pending.has(m.id)) {
      const { resolve, reject } = pending.get(m.id); pending.delete(m.id);
      m.error ? reject(new Error(JSON.stringify(m.error))) : resolve(m.result);
    }
  });
  ws.addEventListener('close', () => { log('WS 断开'); ws = null; });
  await send('Page.enable'); await send('Runtime.enable'); await send('DOM.enable');
}

// 单实例独占一组端口。禁止"静默复用别人的 Chrome"——那会导致本实例 PROFILE 参数
// 被完全忽略，操作落到别的浏览器上, 属高危串台行为。
// 若确需重启后复用自己上次拉起的 Chrome, 显式设 CDP_REUSE=1 (自行承担风险)。
let chrome = null;
let ok0 = false;
ok0 = (await cdpHttp('/json/version', { timeout: 1500 })).ok;
if (ok0) {
  if (process.env.CDP_REUSE !== '1') {
    log(`✗ 端口 ${PORT} 已被占用 —— 已有 CDP 实例在运行, 本实例拒绝接管以避免操作串台。`);
    log(`  请改用其他端口:  CDP_PORT=9223 CDP_API=9334 CDP_PROFILE=<新目录> node cdpserver.mjs`);
    log(`  确要复用请显式设置: CDP_REUSE=1`);
    process.exit(1);
  }
  log(`⚠ CDP_REUSE=1: 复用端口 ${PORT} 上已运行的 Chrome (请确保它是本实例的)`);
} else {
  log(`未检测到占用, 拉起本实例专属 Chrome (profile=${PROFILE})`);
  chrome = spawnChrome();
  if (!(await waitPort())) throw new Error('Chrome 端口未就绪');
}
await ensure();
log('CDP 就绪');

const server = http.createServer(async (req, res) => {
  const setCORS = () => { res.setHeader('Content-Type', 'application/json; charset=utf-8'); };
  if (req.method !== 'POST') { setCORS(); res.end(JSON.stringify({ ok: false, error: 'use POST' })); return; }
  let body = '';
  req.on('data', c => body += c);
  req.on('end', async () => {
    setCORS();
    try {
      const { cmd, args = [] } = JSON.parse(body || '{}');
      await ensure();
      let out;
      switch (cmd) {
        case 'quit': {
          // 优雅关闭浏览器并退出本服务 —— 必须用它而不是 Stop-Process -Force,
          // 强杀会让 Cookie/Session 来不及落盘, 导致下次重新登录
          try { await send('Browser.close'); } catch {}
          out = '浏览器已优雅关闭, 登录态已落盘';
          setTimeout(() => process.exit(0), 300);
          break;
        }
        case 'window': {
          // window show  —— 把离屏窗口拉回屏幕指定位置(需人工登录/验收时)
          // window hide  —— 收回屏幕外(平时不打扰用户)
          // window show x y  —— 自定义位置
          const mode = (args[0] || 'show').toLowerCase();
          if (!currentTargetId) { out = '无目标'; break; }
          const { windowId } = await send('Browser.getWindowForTarget', { targetId: currentTargetId });
          if (mode === 'hide') {
            await send('Browser.setWindowBounds', { windowId, bounds: { left: -32000, top: -32000, width: WIN_W, height: WIN_H } });
            out = '已移出屏幕';
          } else {
            const x = Number(args[1] || 60), y = Number(args[2] || 60);
            await send('Browser.setWindowBounds', { windowId, bounds: { left: x, top: y, width: WIN_W, height: WIN_H } });
            await send('Browser.setWindowBounds', { windowId, bounds: { left: x, top: y, width: WIN_W, height: WIN_H, windowState: 'normal' } });
            out = `已显示在 (${x},${y})`;
          }
          break;
        }
        case 'eval': {
          const r = await send('Runtime.evaluate', { expression: args[0], returnByValue: true, awaitPromise: true });
          out = r.exceptionDetails ? ('异常: ' + r.exceptionDetails.text) : (r.result?.value ?? '(undefined)');
          break;
        }
        case 'shot': {
          const r = await send('Page.captureScreenshot', { format: 'png' });
          fs.writeFileSync(args[0], Buffer.from(r.data, 'base64'));
          out = '已保存 ' + args[0];
          break;
        }
        case 'nav': {
          await send('Page.navigate', { url: args[0] });
          await new Promise(r => setTimeout(r, 2500));
          out = '已导航 ' + args[0];
          break;
        }
        case 'click': {
          const r = await send('Runtime.evaluate', {
            expression: `(function(){var el=document.querySelector(${JSON.stringify(args[0])});if(!el)return 'NOT_FOUND';el.scrollIntoView({block:'center'});var r2=el.getBoundingClientRect();return JSON.stringify({x:r2.x+r2.width/2,y:r2.y+r2.height/2,txt:(el.innerText||el.tagName).slice(0,80)});})()`,
            returnByValue: true });
          const pos = typeof r.result?.value === 'string' ? JSON.parse(r.result.value) : r.result?.value;
          if (!pos || pos === 'NOT_FOUND') { out = 'NOT_FOUND ' + args[0]; break; }
          await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: pos.x, y: pos.y });
          await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: pos.x, y: pos.y, button: 'left', clickCount: 1 });
          await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: pos.x, y: pos.y, button: 'left', clickCount: 1 });
          out = 'CLICKED:' + pos.txt;
          break;
        }
        case 'clickxy': {
          const x = Math.round(args[0]), y = Math.round(args[1]);
          await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
          await send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
          await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
          out = 'CLICKED_XY:' + x + ',' + y;
          break;
        }
        case 'clicktext': {
          const r = await send('Runtime.evaluate', {
            expression: `(function(){var t=${JSON.stringify(args[0])};var els=[...document.querySelectorAll('button,a,div[role=button],span,label')];var el=els.find(e=>e.innerText&&e.innerText.trim().includes(t)&&e.offsetParent!==null);if(!el)return 'NOT_FOUND';el.scrollIntoView({block:'center'});var r2=el.getBoundingClientRect();return JSON.stringify({x:r2.x+r2.width/2,y:r2.y+r2.height/2,txt:el.innerText.trim().slice(0,80)});})()`,
            returnByValue: true });
          const pos = typeof r.result?.value === 'string' ? JSON.parse(r.result.value) : r.result?.value;
          if (!pos || pos === 'NOT_FOUND') { out = 'NOT_FOUND ' + args[0]; break; }
          await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: pos.x, y: pos.y });
          await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: pos.x, y: pos.y, button: 'left', clickCount: 1 });
          await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: pos.x, y: pos.y, button: 'left', clickCount: 1 });
          out = 'CLICKED:' + pos.txt;
          break;
        }
        case 'upload': {
          const { root } = await send('DOM.getDocument', { depth: -1, pierce: true });
          const { nodeId } = await send('DOM.querySelector', { nodeId: root.nodeId, selector: args[0] });
          if (!nodeId) { out = 'NOT_FOUND ' + args[0]; break; }
          await send('DOM.setFileInputFiles', { files: [args[1]], nodeId });
          out = '已设置文件 ' + args[1];
          break;
        }
        case 'inputs': {
          const r = await send('Runtime.evaluate', {
            expression: `JSON.stringify([...document.querySelectorAll('input,button,[role=button],textarea')].map((e,i)=>({i,tag:e.tagName,type:e.type||'',ph:e.placeholder||'',txt:(e.innerText||'').trim().slice(0,50),cls:(e.className||'').toString().slice(0,60)})).slice(0,60))`,
            returnByValue: true });
          out = r.result?.value;
          break;
        }
        case 'url': {
          const r = await send('Runtime.evaluate', { expression: 'location.href', returnByValue: true });
          out = r.result?.value;
          break;
        }
        // 检查 Google 账号登录态：打开 myaccount 页判断是账号页还是登录页
        case 'glogin': {
          await send('Page.navigate', { url: 'https://myaccount.google.com/' });
          await new Promise(r => setTimeout(r, 5000));
          const r = await send('Runtime.evaluate', {
            expression: `(function(){
              var h = location.href;
              var t = (document.title||'').trim();
              var b = (document.body?document.body.innerText:'').slice(0,400);
              var gmail = (b.match(/[\\w.+-]+@[\\w-]+\\.[\\w.]+/)||[])[0] || '';
              return JSON.stringify({url:h, title:t, email:gmail,
                logged: !/\\/v3\\/signin|accounts\\.google\\.com\\/(signin|v3)|ServiceLogin/i.test(h)});
            })()`,
            returnByValue: true, awaitPromise: true });
          out = r.result?.value ?? r.exceptionDetails?.text;
          break;
        }
        case 'wait':
          await new Promise(r => setTimeout(r, Number(args[0])));
          out = 'waited ' + args[0];
          break;
        case 'switch': {
          targetKeyword = args[0];
          if (ws) { try { ws.close(); } catch {} ws = null; }
          await ensure();
          const r = await send('Runtime.evaluate', { expression: 'location.href', returnByValue: true });
          out = '已切换到 ' + r.result?.value;
          break;
        }
        // 清理幽灵/恢复页面: {"cmd":"clean"}
        // 用途：关闭 Chrome 恢复会话产生的错误页（如 http://0.0.3.132/）、
        // 以及所有不含 targetKeyword 的无关标签页，只保留当前操作目标。
        case 'clean': {
          const list = ((await cdpHttp('/json/list')).json || [])
            .filter(t => t.type === 'page');
          const keep = list.find(t => t.id === currentTargetId) || list.find(t => t.url.includes(targetKeyword));
          const junk = list.filter(t => t !== keep);
          const closed = [];
          for (const t of junk) {
            try { await cdpHttp('/json/close/' + t.id); closed.push((t.url || '').slice(0, 60)); } catch {}
          }
          out = JSON.stringify({ kept: keep ? keep.url.slice(0, 80) : '无', closed }, null, 1);
          break;
        }
        case 'tabs': {
          const list = (await cdpHttp('/json/list')).json || [];
          out = JSON.stringify(list.filter(t => t.type === 'page').map(t => ({ title: (t.title || '').slice(0, 40), url: t.url.slice(0, 90) })), null, 1);
          break;
        }
        // 从文件执行 JS，避开 shell 转义问题: {"cmd":"evalfile","args":["D:/x.js"]}
        // 可信输入文本（需先聚焦输入框）: {"cmd":"type","args":["文本"]}
        case 'type': {
          await send('Input.insertText', { text: args[0] });
          out = '已输入 ' + args[0].slice(0, 30);
          break;
        }
        // 模拟组合键（用于 Ctrl+V 粘贴）: {"cmd":"key","args":["ctrl+v"]}
        case 'key': {
          const parts = String(args[0] || '').toLowerCase().split('+');
          const m = { ctrl: parts.includes('ctrl'), alt: parts.includes('alt'), shift: parts.includes('shift') };
          const main = parts[parts.length - 1];
          const keyMap = { v: [86, 'KeyV'], c: [67, 'KeyC'], x: [88, 'KeyX'], a: [65, 'KeyA'], z: [90, 'KeyZ'], enter: [13, 'Enter'], backspace: [8, 'Backspace'] };
          const km = keyMap[main] || [main.toUpperCase().charCodeAt(0), (main[0].toUpperCase() + main.slice(1))];
          const mod = (m.ctrl ? 2 : 0) | (m.alt ? 1 : 0) | (m.shift ? 4 : 0);
          const press = async (vk, code, k, mm) => {
            await send('Input.dispatchKeyEvent', { type: 'keyDown', windowsVirtualKeyCode: vk, code, key: k, modifiers: mm });
            await send('Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode: vk, code, key: k, modifiers: mm });
          };
          if (m.ctrl) await send('Input.dispatchKeyEvent', { type: 'keyDown', windowsVirtualKeyCode: 17, code: 'ControlLeft', key: 'Control', modifiers: 0 });
          if (m.alt) await send('Input.dispatchKeyEvent', { type: 'keyDown', windowsVirtualKeyCode: 18, code: 'AltLeft', key: 'Alt', modifiers: m.ctrl ? 2 : 0 });
          if (m.shift) await send('Input.dispatchKeyEvent', { type: 'keyDown', windowsVirtualKeyCode: 16, code: 'ShiftLeft', key: 'Shift', modifiers: (m.ctrl ? 2 : 0) + (m.alt ? 1 : 0) });
          await press(km[0], km[1], main.length === 1 ? main : main, mod);
          if (m.shift) await send('Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode: 16, code: 'ShiftLeft', key: 'Shift', modifiers: (m.ctrl ? 2 : 0) + (m.alt ? 1 : 0) });
          if (m.alt) await send('Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode: 18, code: 'AltLeft', key: 'Alt', modifiers: m.ctrl ? 2 : 0 });
          if (m.ctrl) await send('Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode: 17, code: 'ControlLeft', key: 'Control', modifiers: 0 });
          out = '已发送 ' + args[0];
          break;
        }
        case 'evalfile': {
          const code = fs.readFileSync(args[0], 'utf8');
          const r = await send('Runtime.evaluate', { expression: code, returnByValue: true, awaitPromise: true });
          out = r.exceptionDetails ? ('异常: ' + JSON.stringify(r.exceptionDetails).slice(0, 500)) : JSON.stringify(r.result?.value ?? null);
          break;
        }
        default:
          out = '未知命令 ' + cmd;
      }
      res.end(JSON.stringify({ ok: true, result: out }));
    } catch (e) {
      res.end(JSON.stringify({ ok: false, error: String(e.message || e) }));
    }
  });
});

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') log('✗ API 端口 ' + API + ' 被占用（EADDRINUSE），启动失败');
  else log('✗ API 服务异常: ' + e.message);
  process.exit(3);
});
server.listen(API, '127.0.0.1', () => log('API 就绪 http://127.0.0.1:' + API));
process.on('SIGTERM', () => { try { chrome?.kill(); } catch {} process.exit(0); });
