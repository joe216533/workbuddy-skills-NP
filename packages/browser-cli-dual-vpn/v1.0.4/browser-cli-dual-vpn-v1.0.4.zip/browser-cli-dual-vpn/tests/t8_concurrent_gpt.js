'use strict';
// T8：两个独立 GPT 浏览器并发发送 + 抓取，验证不串台。
// 判据：A 窗回复只含 A 标记不含 B 标记，B 窗反之。
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const API_A = 9342, API_B = 9343;
const OUT = path.join(__dirname, '..', 't8_result.json');

function cmd(api, name, args = [], timeout = 60000) {
  return new Promise((resolve) => {
    const data = JSON.stringify({ cmd: name, args });
    const req = http.request({ host: '127.0.0.1', port: api, method: 'POST', path: '/cmd', timeout,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } }, (res) => {
      let b = ''; res.on('data', (c) => b += c); res.on('end', () => {
        try { resolve({ ok: true, result: JSON.parse(b).result }); }
        catch { resolve({ ok: false, error: b.slice(0, 300) }); }
      });
    });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'TIMEOUT' }); });
    req.write(data); req.end();
  });
}
const ev = async (api, js) => {
  const r = await cmd(api, 'eval', [js]);
  if (!r.ok) return {};
  try { return JSON.parse(r.result); } catch { return {}; }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 先把两个窗切到新聊天，避免历史上下文干扰标记判定
async function newChat(api) {
  await cmd(api, 'eval', ["(function(){var b=Array.from(document.querySelectorAll('button')).find(x=>/新聊天|New chat/.test(x.getAttribute('aria-label')||x.textContent||''));if(b){b.click();return 'clicked'}return 'no-btn'})()"]);
  await sleep(2500);
}

async function sendAndWait(api, marker, letter) {
  const text = `这是一个并发隔离测试。请只回复一句：${marker} 已收到。不要提任何其他标记。`;
  // 聚焦编辑器
  await ev(api, "(function(){var p=document.querySelector('form div.ProseMirror[contenteditable=\"true\"]')||document.querySelector('.ProseMirror');if(!p)return 'NO_EDITOR';p.focus();return 'OK'})()");
  await cmd(api, 'type', [text]);
  await sleep(800);
  const typed = await ev(api, "(function(){var p=document.querySelector('.ProseMirror');return JSON.stringify({len:p?p.innerText.length:0})})()");
  const before = (await ev(api, "JSON.stringify({len:document.body.innerText.length})")).len || 0;
  // 点发送
  await ev(api, "(function(){var b=Array.from(document.querySelectorAll('button')).find(x=>/发送|Send/.test(x.getAttribute('aria-label')||''));if(!b)return 'NO_BTN';b.click();return 'SENT'})()");
  const t0 = Date.now();
  let final = '';
  while (Date.now() - t0 < 180000) {
    await sleep(4000);
    const s = await ev(api, "(function(){var t=document.body.innerText||'';var done=/回答已完成|ChatGPT can make mistakes|ChatGPT 可能会出错/.test(t.slice(-600));return JSON.stringify({len:t.length,done:done,tail:t.slice(-1500)})})()");
    if (s.done && s.len > before + 50) { final = s.tail || ''; break; }
  }
  // 关键：只检查 GPT 的回复正文（"ChatGPT 说：" 之后），不能把用户消息里的标记算进去
  const cut = final.lastIndexOf('ChatGPT 说：');
  const replyBody = cut >= 0 ? final.slice(cut) : '';
  const hasOwn = replyBody.includes(marker);
  const hasOther = replyBody.includes(letter === 'A' ? 'T8-B-' : 'T8-A-');
  return { letter, marker, typedLen: typed.len, elapsedSec: Math.round((Date.now() - t0) / 1000),
    replyLen: replyBody.length, hasOwn, hasOther, replyBody: replyBody.slice(0, 300) };
}

(async () => {
  const ts = Date.now();
  const mA = 'T8-A-' + ts, mB = 'T8-B-' + ts;
  await Promise.all([newChat(API_A), newChat(API_B)]);
  // 关键：同时发送
  const [a, b] = await Promise.all([
    sendAndWait(API_A, mA, 'A'),
    sendAndWait(API_B, mB, 'B'),
  ]);
  const pass = a.hasOwn && !a.hasOther && b.hasOwn && !b.hasOther;
  const out = { ts, verdict: pass ? 'PASS' : 'FAIL', a, b,
    note: pass ? '两个独立 GPT 浏览器并发运行，回复无串台' : '存在串台或未收到自己的标记' };
  fs.writeFileSync(OUT, JSON.stringify(out, null, 2) + '\n', 'utf8');
  console.log(JSON.stringify(out, null, 2));
  process.exit(pass ? 0 : 4);
})();
