param(
  [string]$ChromePath,
  [int]$Port,
  [string]$ProfileDir,
  [string]$Proxy,
  [string]$WindowSize = "1280,900",
  [switch]$Visible = $true
)

$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Path $ProfileDir -Force | Out-Null

$argLine = "--remote-debugging-port=$Port --remote-debugging-address=127.0.0.1 --user-data-dir=`"$ProfileDir`" --no-first-run --no-default-browser-check --disable-features=Translate,OptimizationHints,MediaRouter --disable-session-crashed-bubble --disable-crash-reporter --disable-breakpad --noerrdialogs --deny-permission-prompts --disable-notifications --disable-popup-blocking --disable-background-networking --disable-component-update --disable-sync --disable-domain-reliability --metrics-recording-only --safebrowsing-disable-auto-update --window-size=$WindowSize"

if ($Proxy -and $Proxy.Trim().Length -gt 0) {
  $argLine = $argLine + " --proxy-server=$Proxy"
}

$argLine = $argLine + " about:blank"

$p = Start-Process -FilePath $ChromePath -ArgumentList $argLine -PassThru
# Windows Chrome may hand off to another main process; the launcher PID ($p.Id) can exit
# while the real browser keeps running. Resolve the real main process by CDP port + profile.
# Fail closed: zero or multiple matches are both errors — never register a guessed process.
$matches = @()
for ($i = 0; $i -lt 50 -and $matches.Count -eq 0; $i++) {
  Start-Sleep -Milliseconds 200
  $matches = @(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | Where-Object {
    $_.CommandLine -and
    $_.CommandLine.Contains("--remote-debugging-port=$Port") -and
    $_.CommandLine.Contains($ProfileDir) -and
    $_.CommandLine -notmatch '--type=(renderer|extension|gpu|utility|zygote)'
  })
}
if ($matches.Count -eq 0) { throw "Chrome process not found (port=$Port profile=$ProfileDir)" }
if ($matches.Count -gt 1) { throw "Chrome main process AMBIGUOUS: $($matches.Count) matches (port=$Port profile=$ProfileDir)" }
$w = $matches[0]

[pscustomobject]@{
  pid = [int]$w.ProcessId
  launcherPid = [int]$p.Id
  executablePath = $w.ExecutablePath
  commandLine = $w.CommandLine
  creationDate = $w.CreationDate.ToString('o')
} | ConvertTo-Json -Compress
