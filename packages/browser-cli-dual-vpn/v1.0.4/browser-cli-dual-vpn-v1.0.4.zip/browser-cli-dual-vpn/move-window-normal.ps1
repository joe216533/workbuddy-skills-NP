﻿param([int]$TargetPid, [int]$X, [int]$Y, [int]$W, [int]$WinHeight)

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class Win {
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
}
'@

$proc = Get-Process -Id $TargetPid -ErrorAction Stop
$h = $proc.MainWindowHandle
if ($h -eq [IntPtr]::Zero) { Write-Output "NO_WINDOW pid=$TargetPid"; exit 1 }
[Win]::ShowWindow($h, 9) | Out-Null
Start-Sleep -Milliseconds 200
[Win]::ShowWindow($h, 5) | Out-Null
[Win]::SetWindowPos($h, [IntPtr]::Zero, $X, $Y, $W, $WinHeight, 0x0040) | Out-Null
[Win]::SetForegroundWindow($h) | Out-Null
Write-Output "MOVED pid=$TargetPid hwnd=$h to ($X,$Y) ${W}x${WinHeight}"

