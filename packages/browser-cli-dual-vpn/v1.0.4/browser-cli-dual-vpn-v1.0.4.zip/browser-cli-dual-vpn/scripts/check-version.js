#!/usr/bin/env node
/**
 * check-version.js v3（哈希校验版）— 五技能统一
 *
 * L0 本机安装验证：版本比对 + 文件级 SHA256 校验 + 本地修改登记。
 * 只读：不安装、不升级、不覆盖、不修改技能文件。
 *
 * 状态：VERIFIED / MODIFIED_LOCAL / MISSING / HASH_MISMATCH / 待核验 / 无法校验
 * 退出码：0=符合或仅合法登记修改；1=缺失/版本错/哈希异常；2=证据不足/检查器错误
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const https = require('node:https');
const crypto = require('node:crypto');

const AS_JSON = process.argv.includes('--json');
const TIMEOUT_MS = 8000;
const RAW_INDEX = 'https://raw.githubusercontent.com/joe216533/workbuddy-skills-NP/main/release-index.json';
const REG_DIR = path.join(os.homedir(), '.workbuddy', 'skill-registry');
const LOCAL_MODS = path.join(REG_DIR, 'local-modifications.json');

const lines = [];
function say(s) { lines.push(s); if (!AS_JSON) console.log(s); }
function sha(p) {
  try { return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'); }
  catch (_) { return null; }
}
function stripV(v) { return String(v || '').trim().replace(/^v/, ''); }
function cmp(a, b) {
  const pa = stripV(a).split(/[.-]/).map((x) => parseInt(x, 10) || 0);
  const pb = stripV(b).split(/[.-]/).map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d; }
  return 0;
}
function get(url) {
  return new Promise((resolve) => {
    const done = (v) => resolve(v);
    const req = https.get(url, { timeout: TIMEOUT_MS, headers: { 'User-Agent': 'skill-check-v3' } }, (res) => {
      if (res.statusCode !== 200) { res.resume(); return done({ ok: false, error: 'HTTP_' + res.statusCode }); }
      let buf = ''; res.setEncoding('utf8');
      res.on('data', (c) => { buf += c; if (buf.length > 3e6) req.destroy(); });
      res.on('end', () => done({ ok: true, text: buf }));
    });
    req.on('timeout', () => { req.destroy(); done({ ok: false, error: 'TIMEOUT' }); });
    req.on('error', (e) => done({ ok: false, error: String(e.code || e.message) }));
  });
}
function frontmatterVersion(md) {
  const m = md.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!m) return null;
  const v = m[1].match(/^version:\s*"?([^"\r\n]+)"?\s*$/m);
  return v ? v[1].trim() : null;
}
function parseChecksums(text) {
  const out = {};
  for (const line of String(text).split(/\r?\n/)) {
    const m = line.match(/^([0-9a-f]{64})\s{2}(.+)$/);
    if (m) out[m[2].trim()] = m[1];
  }
  return out;
}
function loadLocalMods(sid, ver) {
  try {
    const d = JSON.parse(fs.readFileSync(LOCAL_MODS, 'utf8'));
    return (d.records || []).filter((r) => r.skill_id === sid && (!ver || r.version === ver) && r.status === 'ACTIVE');
  } catch (_) { return []; }
}

(async () => {
  const R = { checker_version: '3.0-hash', layer: 'L0', readonly: true,
    integrity: '待核验', version_status: '待核验', execution_allowed: false, evidence: {} };
  let exit = 0;
  try {
    const here = __dirname;
    const root = fs.existsSync(path.join(here, '..', 'manifest.json')) ? path.resolve(here, '..') : process.cwd();
    say('================================');
    say('技能版本与完整性检查 v3（L0 本机安装）');
    say('================================');

    // manifest / SKILL.md
    const mfPath = path.join(root, 'manifest.json');
    const skPath = path.join(root, 'SKILL.md');
    let mf = null, skillV = null;
    try { mf = JSON.parse(fs.readFileSync(mfPath, 'utf8')); }
    catch (_) { say('[FAIL] manifest.json 缺失或格式错误'); R.integrity = 'MISSING'; exit = 2; }
    try { skillV = frontmatterVersion(fs.readFileSync(skPath, 'utf8')); if (!skillV) throw 0; }
    catch (_) { say('[FAIL] SKILL.md 版本字段缺失'); R.integrity = 'MISSING'; exit = 2; }
    const sid = mf && (mf.skill_id || mf.id || mf.name);
    const localV = mf && mf.version;
    R.skill_id = sid || null; R.local_version = localV || null;
    say('技能：' + (sid || 'UNKNOWN') + '  本机版本：' + stripV(localV || '?'));

    // 本地版本一致性
    if (localV && skillV) {
      if (stripV(localV) !== stripV(skillV)) {
        say('[FAIL] manifest 与 SKILL.md 版本不一致：' + stripV(localV) + ' vs ' + stripV(skillV));
        R.version_status = 'MISMATCH'; exit = 1;
      } else say('[PASS] manifest 与 SKILL.md 版本一致');
    }

    // 官方索引（远程，可失败降级）
    let index = null, remoteOk = false;
    const idx = await get(RAW_INDEX);
    if (idx.ok) {
      try { index = JSON.parse(idx.text); remoteOk = true; }
      catch (_) { say('[WARN] release-index 解析失败'); }
    } else say('[WARN] release-index 不可用：' + idx.error + '（远端版本待核验，不视为最新）');

    let targetVersion = null, targetSha = null, checksumsSha = null;
    let entry = null;
    if (index && sid) {
      const skills = Array.isArray(index.skills) ? index.skills : null;
      if (skills) entry = skills.find((e) => (e.id || e.skill_id) === sid);
      else if (index.skills && index.skills[sid]) entry = index.skills[sid];
      if (entry) {
        targetVersion = entry.version || null;
        targetSha = entry.sha256 || null;
        checksumsSha = entry.checksums_sha256 || null;
      }
    }
    R.target_version = targetVersion || null;
    R.evidence.remote_available = remoteOk;

    // 版本比对（远端可用时）
    if (remoteOk && targetVersion && localV) {
      const d = cmp(localV, targetVersion);
      if (d < 0) { R.version_status = 'OUTDATED'; exit = 1; say('[FAIL] 本机版本落后：' + stripV(localV) + ' < ' + stripV(targetVersion)); }
      else if (d > 0) { R.version_status = 'AHEAD_ABNORMAL'; exit = 1; say('[FAIL] 本机版本高于官方目标，版本异常'); }
      else { R.version_status = 'CURRENT'; say('[PASS] 本机版本 = 官方目标 ' + stripV(targetVersion)); }
    } else if (!remoteOk) {
      say('[WARN] 远端版本待核验（离线不等于最新）');
      if (R.version_status === '待核验') R.version_status = '待核验';
    }

    // 文件级哈希校验
    const csPath = path.join(root, 'checksums.sha256');
    if (!fs.existsSync(csPath)) {
      say('[FAIL] checksums.sha256 缺失（无法做文件级完整性校验）');
      R.integrity = '待核验'; exit = 1;
    } else {
      const csText = fs.readFileSync(csPath, 'utf8');
      const csActual = sha(csPath);
      if (checksumsSha && csActual !== checksumsSha) {
        say('[FAIL] checksums.sha256 本身哈希与官方索引不一致');
        R.integrity = 'HASH_MISMATCH'; exit = 1;
      }
      const official = parseChecksums(csText);
      const mods = loadLocalMods(sid, localV);
      const modMap = {};
      for (const m of mods) modMap[m.file] = m;
      let status = 'VERIFIED';
      const fileResults = [];
      for (const [rel, exp] of Object.entries(official)) {
        const fp = path.join(root, rel.replace(/\//g, path.sep));
        if (!fs.existsSync(fp)) {
          fileResults.push({ file: rel, status: 'MISSING' });
          status = 'MISSING'; exit = 1; continue;
        }
        const actual = sha(fp);
        if (actual === exp) { fileResults.push({ file: rel, status: 'VERIFIED' }); continue; }
        const reg = modMap[rel];
        if (reg && reg.local_sha256 === actual) {
          fileResults.push({ file: rel, status: 'MODIFIED_LOCAL', reason: reg.reason || '' });
          if (status === 'VERIFIED') status = 'MODIFIED_LOCAL';
        } else {
          fileResults.push({ file: rel, status: 'HASH_MISMATCH', expected: exp.slice(0, 12), actual: (actual || '').slice(0, 12) });
          status = 'HASH_MISMATCH'; exit = 1;
        }
      }
      R.integrity = status;
      R.evidence.files = fileResults;
      say('[INFO] 文件完整性状态：' + status);
      for (const f of fileResults) if (f.status !== 'VERIFIED') say('   ' + f.file + ' → ' + f.status + (f.reason ? '（' + f.reason + '）' : ''));
    }

    // 最终门禁
    R.execution_allowed = (exit === 0) && (R.integrity === 'VERIFIED' || R.integrity === 'MODIFIED_LOCAL');
    say('');
    say('SKILL_ID: ' + (sid || 'UNKNOWN'));
    say('LOCAL_VERSION: ' + stripV(localV || '?'));
    say('TARGET_VERSION: ' + stripV(targetVersion || '待核验'));
    say('VERSION_STATUS: ' + R.version_status);
    say('INTEGRITY_STATUS: ' + R.integrity);
    say('EXECUTION_ALLOWED: ' + (R.execution_allowed ? 'YES' : 'NO'));
    say('只读：未安装、未升级、未覆盖、未修改任何文件');
    say('================================');
  } catch (e) {
    R.integrity = '无法校验'; R.execution_allowed = false; exit = 2;
    say('[ERROR] 检查器异常：' + String(e && e.message || e));
  }
  R.exit_code = exit;
  if (AS_JSON) console.log(JSON.stringify(R, null, 2));
  process.exitCode = exit;
})();
