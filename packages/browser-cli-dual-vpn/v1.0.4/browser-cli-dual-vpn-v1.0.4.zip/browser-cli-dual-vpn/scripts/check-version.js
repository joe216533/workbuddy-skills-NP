#!/usr/bin/env node
/**
 * 统一只读版本检查器 v1.0（四技能共用）
 *
 * 职责：读取本地版本、查询远程正式版本、比较并报告。
 * 绝对禁止：修改文件、下载文件、覆盖安装、启动 VPN、修改代理。
 *
 * 用法：
 *   node scripts/check-version.js             # 本地 + 远程（网络失败自动降级）
 *   node scripts/check-version.js --offline    # 仅本地，主动离线，不返回退出码 3
 *   node scripts/check-version.js --json       # JSON 输出
 *
 * 退出码：
 *   0 检查通过（且联网时远程也通过）
 *   1 版本不一致或本地版本落后
 *   2 本地文件缺失/格式错误
 *   3 本地通过但远程不可用（主动离线不返回 3）
 *   4 检查器自身异常
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const https = require('node:https');

const OFFLINE = process.argv.includes('--offline') || process.argv.includes('--local-only');
const AS_JSON = process.argv.includes('--json');
const TIMEOUT_MS = 6000;

const REPO_RAW = 'https://raw.githubusercontent.com/joe216533/workbuddy-skills-NP/main/release-index.json';
const REPO_API = 'https://api.github.com/repos/joe216533/workbuddy-skills-NP/git/refs/tags';

const lines = [];
function say(s) { lines.push(s); if (!AS_JSON) console.log(s); }
function stripV(v) { return String(v || '').trim().replace(/^v/, ''); }
function cmp(a, b) {
  const pa = stripV(a).split(/[.-]/).map((x) => parseInt(x, 10) || 0);
  const pb = stripV(b).split(/[.-]/).map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

function get(url) {
  return new Promise((resolve) => {
    const done = (v) => resolve(v);
    const req = https.get(url, { timeout: TIMEOUT_MS, headers: { 'User-Agent': 'skill-version-check/1.0' } }, (res) => {
      if (res.statusCode !== 200) { res.resume(); return done({ ok: false, error: 'HTTP_' + res.statusCode }); }
      let buf = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { buf += c; if (buf.length > 2e6) req.destroy(); });
      res.on('end', () => done({ ok: true, text: buf }));
    });
    req.on('timeout', () => { req.destroy(); done({ ok: false, error: 'TIMEOUT' }); });
    req.on('error', (e) => done({ ok: false, error: String(e.code || e.message) }));
  });
}

function frontmatterVersion(md) {
  const m = md.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!m) return null;
  const v = m[1].match(/^version:\s*"?([^"\r\n]+)"?\s*$/m);
  return v ? v[1].trim() : null;
}

(async () => {
  const result = { checker_version: '1.0', authority: 'github_release_tag', offline: OFFLINE, checks: [] };
  let exit = 0;
  try {
    // 定位技能根目录：脚本在 <skill>/scripts/ 下；也从 cwd 兜底
    const here = __dirname;
    const root = fs.existsSync(path.join(here, '..', 'manifest.json')) ? path.resolve(here, '..') : process.cwd();
    result.skill_root = root;

    say('================================');
    say('技能版本检查（只读）');
    say('================================');

    // ---- 本地检查（必须可用）----
    const mfPath = path.join(root, 'manifest.json');
    const skPath = path.join(root, 'SKILL.md');
    let manifest = null, skillV = null;
    try {
      manifest = JSON.parse(fs.readFileSync(mfPath, 'utf8'));
      result.checks.push({ item: '本地 manifest.json', status: 'PASS' });
      say('[PASS] 本地 manifest.json 可读取');
    } catch (e) {
      result.checks.push({ item: '本地 manifest.json', status: 'FAIL', reason: String(e.code || e.message) });
      say('[FAIL] 本地 manifest.json 缺失或格式错误：' + String(e.code || e.message));
      exit = 2;
    }
    try {
      skillV = frontmatterVersion(fs.readFileSync(skPath, 'utf8'));
      if (!skillV) throw new Error('NO_VERSION_IN_FRONTMATTER');
      result.checks.push({ item: '本地 SKILL.md', status: 'PASS' });
      say('[PASS] 本地 SKILL.md frontmatter 可读取');
    } catch (e) {
      result.checks.push({ item: '本地 SKILL.md', status: 'FAIL', reason: String(e.message) });
      say('[FAIL] 本地 SKILL.md 版本字段缺失：' + String(e.message));
      exit = 2;
    }

    const sid = manifest && (manifest.skill_id || manifest.id || manifest.name);
    const localV = manifest && manifest.version;
    result.skill_id = sid || null;
    result.local = { manifest: localV || null, skill_md: skillV };

    if (localV && skillV) {
      const consistent = stripV(localV) === stripV(skillV);
      result.checks.push({ item: '本地版本一致性', status: consistent ? 'PASS' : 'FAIL' });
      if (consistent) say('[PASS] 本地版本一致：' + stripV(localV));
      else {
        say('[FAIL] 本地包内部版本不一致');
        say('  manifest.json：' + stripV(localV));
        say('  SKILL.md     ：' + stripV(skillV));
        exit = 1;
      }
    }
    say('技能：' + (sid || '未识别'));

    // ---- 远程检查（可选）----
    let remoteV = null, indexV = null, remoteOk = false, indexOk = false;
    if (!OFFLINE) {
      const idx = await get(REPO_RAW);
      if (idx.ok) {
        try {
          const data = JSON.parse(idx.text);
          const entry = sid && data.skills && data.skills[sid];
          if (entry) { indexV = entry.version; indexOk = true; }
        } catch (_) {}
      }
      result.checks.push({ item: '版本索引查询', status: indexOk ? 'PASS' : 'WARN' });
      say(indexOk ? '[PASS] 版本索引可读取' : '[WARN] 版本索引不可用：' + (idx.error || '条目缺失'));

      const tags = await get(REPO_API);
      if (tags.ok) {
        try {
          const arr = JSON.parse(tags.text);
          const re = new RegExp('^' + String(sid).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '-v(\\d+\\.\\d+\\.\\d+)$');
          let best = null;
          for (const t of (arr || [])) {
            const m = String(t.ref || '').replace(/^refs\/tags\//, '').match(re);
            if (m && (!best || cmp(m[1], best) > 0)) best = m[1];
          }
          if (best) { remoteV = best; remoteOk = true; }
        } catch (_) {}
      }
      result.checks.push({ item: 'GitHub Tag 查询', status: remoteOk ? 'PASS' : 'WARN' });
      say(remoteOk ? '[PASS] GitHub 最新正式 Tag 可读取' : '[WARN] GitHub 远程查询不可用：' + (tags.error || '无匹配 Tag'));

      if (remoteOk && indexOk) {
        const agree = cmp(remoteV, indexV) === 0;
        result.checks.push({ item: '远程权威与索引一致', status: agree ? 'PASS' : 'FAIL' });
        if (agree) say('[PASS] 版本索引与正式 Tag 一致：' + remoteV);
        else { say('[FAIL] 版本索引与正式 Tag 不一致，以 Tag 为准'); exit = 1; }
      }
      if (!remoteOk && !indexOk) {
        say('[WARN] 远程检查全部不可用；仅完成本地检查。');
        if (exit === 0) exit = 3;
      }
    } else {
      say('[INFO] 主动离线模式，跳过远程检查');
    }

    result.remote = { tag: remoteV || null, index: indexV || null };

    if (localV && remoteV) {
      const d = cmp(localV, remoteV);
      result.comparison = { local: stripV(localV), latest: stripV(remoteV), behind: d < 0 };
      if (d < 0) {
        say('');
        say('检查结果：发现新版');
        say('  本机版本：' + stripV(localV));
        say('  最新版本：' + stripV(remoteV));
        say('  建议：按正式升级 SOP 操作；本检查器不会自动升级。');
        if (exit === 0) exit = 1;
      } else if (d > 0) {
        say('');
        say('检查结果：本机版本高于最新正式 Tag（可能是测试版或本地修改）');
        say('  本机版本：' + stripV(localV));
        say('  最新正式：' + stripV(remoteV));
      } else {
        say('');
        say('检查结果：已是最新正式版本 ' + stripV(remoteV));
      }
    } else if (localV && !remoteOk && !OFFLINE) {
      say('');
      say('检查结果：无法确认是否为最新版（远程不可用）');
    }

    say('');
    say('安全状态：');
    say('[PASS] 未修改任何文件');
    say('[PASS] 未下载任何文件');
    say('[PASS] 未修改用户数据 / 登录态');
    say('[PASS] 未启动 VPN、未修改代理');
    say('================================');
  } catch (e) {
    result.checks.push({ item: '检查器自身', status: 'ERROR', reason: String(e.stack || e.message) });
    say('[ERROR] 检查器异常：' + String(e.stack || e.message));
    exit = 4;
  }
  result.exit_code = exit;
  result.verdict = exit === 0 ? 'PASS' : exit === 1 ? 'OUTDATED' : exit === 2 ? 'LOCAL_ERROR' : exit === 3 ? 'REMOTE_UNAVAILABLE' : 'ERROR';
  if (AS_JSON) console.log(JSON.stringify(result, null, 2));
  process.exitCode = exit;
})();
