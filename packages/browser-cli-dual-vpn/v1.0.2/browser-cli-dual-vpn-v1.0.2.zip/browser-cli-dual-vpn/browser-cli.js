'use strict';
// browser-cli-dual-vpn —— 双浏览器网络隔离控制 CLI
// 核心：国内直连窗 + 境外代理窗（可扩到多个境外窗并发），同时运行、网络出口隔离。
// 边界：只读 VPN/TUN 状态；不擅自修改 GLOBAL/TUN；down 只停本轮登记启动的进程。
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const http = require('node:http');
const { spawn } = require('node:child_process');

const NODE = process.execPath;
const PKG_ROOT = path.join(__dirname, '..');
const SERVER = path.join(__dirname, 'cdpserver.mjs');
// 默认用户数据目录；BROWSER_CLI_HOME 仅用于隔离测试，不改变默认行为。
const HOME_DIR = process.env.BROWSER_CLI_HOME || path.join(os.homedir(), '.workbuddy', 'browser-cli-dual-vpn');
const STATE_FILE = path.join(HOME_DIR, 'state.json');
const BASELINE_FILE = path.join(HOME_DIR, 'baseline.json');
const STATE_SCHEMA = 2;
const MAX_INSTANCES = 2;
const ROUTING_FILE = path.join(__dirname, 'domain-routing.json');

const STATUS = {
  PASS: 'PASS', WARN: 'WARN', NEEDS_CONFIG: 'NEEDS_CONFIG', CLI_MISSING: 'CLI_MISSING',
  PORT_CONFLICT: 'PORT_CONFLICT', PROXY_UNAVAILABLE: 'PROXY_UNAVAILABLE', ERROR: 'ERROR',
};

// v1.0.2：按需双实例模型。最多两个槽位——一个 VPN 出口、一个 DIRECT 出口。
// 同出口复用，不同出口才新开；禁止第三个实例。旧三窗(9234/overseas2)退出正常实例池。
const DEFAULT_PROFILES = {
  direct: { cdp: 9231, api: 9341, profile: 'chrome-xhs-profile', proxy: '', egress: 'direct' },
  vpn: { cdp: 9233, api: 9342, profile: 'chrome-gpt-profile', proxy: 'http://127.0.0.1:11719', egress: 'vpn' },
};
// 兼容旧名：old domestic->direct, old overseas->vpn；overseas2 不再可用。
const LEGACY_ALIAS = { domestic: 'direct', overseas: 'vpn' };
function resolveName(name) {
  if (DEFAULT_PROFILES[name]) return name;
  if (LEGACY_ALIAS[name]) return LEGACY_ALIAS[name];
  return null;
}
const PROXY_CONTROL = 'http://127.0.0.1:11720';

function log(m) { console.log(m); }
function die(code, msg) { console.error('[ERR] ' + msg); process.exit(code); }

function ensureDir() { try { fs.mkdirSync(HOME_DIR, { recursive: true }); } catch {} }
function readJson(p) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } }
function writeJson(p, obj) { ensureDir(); fs.writeFileSync(p, JSON.stringify(obj, null, 2) + '\n', 'utf8'); }

function get(url, timeout = 4000) {
  return new Promise((resolve) => {
    const req = http.get(url, { timeout }, (res) => {
      let b = ''; res.on('data', (c) => b += c); res.on('end', () => {
        try { resolve({ ok: true, status: res.statusCode, json: JSON.parse(b) }); }
        catch { resolve({ ok: true, status: res.statusCode, text: b.slice(0, 500) }); }
      });
    });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'TIMEOUT' }); });
  });
}

async function postJson(url, body, timeout = 4000) {
  return new Promise((resolve) => {
    const data = JSON.stringify(body);
    const req = http.request(url, {
      method: 'POST', timeout,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    }, (res) => {
      let b = ''; res.on('data', (c) => b += c); res.on('end', () => {
        try { resolve({ ok: true, json: JSON.parse(b) }); } catch { resolve({ ok: true, text: b.slice(0, 500) }); }
      });
    });
    req.on('error', (e) => resolve({ ok: false, error: e.message }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'TIMEOUT' }); });
    req.write(data); req.end();
  });
}

// VPN 只读：GLOBAL 当前节点 + TUN 开关。禁止写。
async function vpnRead() {
  const g = await get(PROXY_CONTROL + '/proxies/GLOBAL');
  const c = await get(PROXY_CONTROL + '/configs');
  return {
    reachable: Boolean(g.ok || c.ok),
    global: g.ok && g.json ? g.json.now || g.json.name || null : null,
    tun: c.ok && c.json ? Boolean(c.json.tun && c.json.tun.enable) : null,
  };
}

async function portFree(port) {
  const r = await get('http://127.0.0.1:' + port + '/json/version', 1500);
  return !r.ok;
}

async function aliveCdp(port) {
  for (const h of ['127.0.0.1', '[::1]']) {
    const r = await get('http://' + h + ':' + port + '/json/version', 2000);
    if (r.ok && r.json && r.json.Browser) return r.json.Browser;
  }
  return null;
}

// ---- v1.0.2 域名出口路由 ----
function loadRouting() {
  const fallback = { version: 1, rules: {
    vpn: ['chatgpt.com', 'openai.com', 'gemini.google.com', 'google.com', 'github.com', 'githubusercontent.com'],
    direct: ['xiaohongshu.com', 'xhslink.com', 'quark.cn', 'pan.quark.cn', 'baidu.com'],
  }, unknown: 'ask' };
  try { return JSON.parse(fs.readFileSync(ROUTING_FILE, 'utf8')); } catch { return fallback; }
}
// 严格域名边界：host 等于规则或以其 "." + 规则结尾，避免 github.com.evil.example 误匹配
function hostMatches(host, rule) {
  const h = String(host || '').toLowerCase().replace(/^www\./, '');
  const r = String(rule || '').toLowerCase().replace(/^www\./, '');
  return h === r || h.endsWith('.' + r);
}
function routeHost(rawUrlOrHost) {
  let host = String(rawUrlOrHost || '');
  try { host = new URL(host).hostname; } catch { host = host.replace(/^https?:\/\//, '').split('/')[0].split(':')[0]; }
  const cfg = loadRouting();
  for (const [egress, rules] of Object.entries(cfg.rules || {})) {
    if ((rules || []).some((r) => hostMatches(host, r))) return { host, egress, known: true };
  }
  return { host, egress: null, known: false, action: cfg.unknown || 'ask' };
}
// v1.0.2 状态迁移：旧 state({started:{domestic,overseas,overseas2}}) 不直接复用；
// 备份旧文件，重建 schema 2 空实例池，旧 profile 作为 legacy_profiles 保留。
function migrateStateIfNeeded() {
  const raw = readJson(STATE_FILE);
  if (raw && raw.schema_version === STATE_SCHEMA) return { state: raw, migrated: false };
  const backup = path.join(HOME_DIR, 'state.legacy-' + Date.now() + '.json');
  if (raw) { try { fs.copyFileSync(STATE_FILE, backup); } catch {} }
  const legacy = Object.keys((raw && raw.started) || {}).map((k) => ({
    old_name: k, slot: resolveName(k) || 'unknown',
  }));
  const fresh = {
    schema_version: STATE_SCHEMA, max_instances: MAX_INSTANCES,
    instances: {}, legacy_profiles: legacy,
    migrated_from: raw ? (raw.version || 'legacy') : null,
    backup: raw ? backup : null,
    created_at: new Date().toISOString(),
  };
  writeJson(STATE_FILE, fresh);
  return { state: fresh, migrated: Boolean(raw) };
}

function profilePath(name) {
  // 存到技能私有目录，不写死 D:\Tools\whitemodel。
  return path.join(HOME_DIR, 'profiles', name);
}

function spawnServer(cfg) {
  const env = {
    ...process.env,
    CDP_PORT: String(cfg.cdp),
    CDP_API: String(cfg.api),
    CDP_PROFILE: profilePath(cfg.profile),
    CDP_PROXY: cfg.proxy || '',
    CDP_KEYWORD: cfg.profile,
    CDP_REUSE: '0',
    // 硬规则：本技能的浏览器必须让用户看得见（需要扫码登录、人工确认）。
    // 绝不能设 CDP_OFFSCREEN=1，那会把窗口放到 -32000,-32000，用户永远看不到。
    CDP_OFFSCREEN: '0',
    CDP_URL: 'about:blank',
  };
  ensureDir();
  const logFd = fs.openSync(path.join(HOME_DIR, 'server-' + cfg.cdp + '.log'), 'a');
  fs.writeSync(logFd, '\n=== ' + new Date().toISOString() + ' cdp=' + cfg.cdp + ' api=' + cfg.api + ' proxy=' + (cfg.proxy || 'none') + ' ===\n');
  const child = spawn(NODE, [SERVER], { env, detached: true, stdio: ['ignore', logFd, logFd] });
  child.unref();
  fs.closeSync(logFd);
  return child.pid;
}

// 在 Windows 上用临时 ps1 文件执行，避免 -Command 引号转义把 $() 吃掉。
// 输出格式：PID|CommandLine，逐行解析；这是只读操作，不修改任何进程。
function psProcessLines(exe) {
  const cp = require('node:child_process');
  if (process.platform !== 'win32') return cp.execSync('ps -eo pid,args', { encoding: 'utf8', timeout: 10000 }).toString();
  ensureDir();
  const script = path.join(HOME_DIR, '_ps_processes.ps1');
  fs.writeFileSync(script,
    'Get-CimInstance Win32_Process -Filter "Name=\'' + exe + '\'" | ForEach-Object { "$($_.ProcessId)|$($_.CommandLine)" }\n',
    'utf8');
  try {
    return cp.execSync('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + script + '"',
      { encoding: 'utf8', timeout: 15000 }).toString();
  } finally { try { fs.unlinkSync(script); } catch {} }
}

// 找出占用本技能专属 API 端口的孤儿 Node 服务；只按本技能脚本路径匹配，绝不误杀其它服务。
function findOwnServerPid(api) {
  const out = [];
  try {
    const cp = require('node:child_process');
    let text = '';
    text = psProcessLines('node.exe');
    const marker = 'CDP_API=' + api;
    for (const line of text.split('\n')) {
      if (!line.includes(marker)) continue;
      if (!line.toLowerCase().includes('browser-cli-dual-vpn')) continue;
      const m = line.match(/^(\d+)\|/) || line.match(/^\s*(\d+)\s/);
      if (m) out.push(Number(m[1]));
    }
  } catch {}
  return out;
}

// 找出本技能启动的 Chrome 主进程 PID：按 CDP 端口 + profile 精确匹配，
// 且排除 renderer / extension / gpu 子进程。绝不按进程名或数量杀，避免误伤老板在用的浏览器。
function findChromePids(cfg) {
  const out = [];
  try {
    const cp = require('node:child_process');
    let text = '';
    text = psProcessLines('chrome.exe');
    const prof = profilePath(cfg.profile).toLowerCase();
    for (const line of text.split('\n')) {
      if (!line.includes('remote-debugging-port=' + cfg.cdp)) continue;
      if (/--type=(renderer|extension|gpu|utility|zygote)/.test(line)) continue;
      if (!line.toLowerCase().includes(prof)) continue;
      const m = line.match(/^(\d+)\|/) || line.match(/^\s*(\d+)\s/);
      if (m) out.push(Number(m[1]));
    }
  } catch {}
  return out;
}

// v1.0.2：按 CDP 端口 + profile 精确解析真实 Chrome 主进程身份（PID / 路径 / 命令行 / 创建时间）。
// 必须唯一匹配：0 个或多个都 fail closed，不登记、不猜测。
function chromeIdentity(cfg, pids) {
  const list = (pids || []).length ? pids : findChromePids(cfg);
  if (!Array.isArray(list) || list.length !== 1) {
    return { ok: false, reason: list && list.length === 0 ? 'NO_MATCH' : 'AMBIGUOUS_MATCH', matches: list };
  }
  const pid = list[0];
  try {
    const cp = require('node:child_process');
    ensureDir();
    const script = path.join(HOME_DIR, '_ps_identity.ps1');
    fs.writeFileSync(script,
      '$p = Get-CimInstance Win32_Process -Filter "ProcessId=' + pid + '"; ' +
      'if ($p) { "$($p.ProcessId)|$($p.ExecutablePath)|$($p.CreationDate.ToString(\'o\'))|$($p.CommandLine)" }\n', 'utf8');
    try {
      const raw = cp.execSync('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' + script + '"',
        { encoding: 'utf8', timeout: 15000 }).toString().trim();
      const parts = raw.split('|');
      if (parts.length < 4) return { ok: false, reason: 'IDENTITY_READ_FAILED', pid };
      return { ok: true, pid: Number(parts[0]), executablePath: parts[1], creationDate: parts[2], commandLine: parts.slice(3).join('|') };
    } finally { try { fs.unlinkSync(script); } catch {} }
  } catch (e) { return { ok: false, reason: 'IDENTITY_READ_ERROR', pid, error: String(e.message || e) }; }
}
// down 前核验：登记身份与当前进程身份必须逐项一致，防止 PID 复用误杀。
function verifyIdentity(rec, cfg) {
  if (!rec || !rec.pidIdentity || !rec.pidIdentity.ok) return { ok: false, reason: 'NO_REGISTERED_IDENTITY' };
  const cur = chromeIdentity(cfg, [rec.pidIdentity.pid]);
  if (!cur.ok) return { ok: false, reason: 'CURRENT_IDENTITY_UNREADABLE', detail: cur.reason };
  const id = rec.pidIdentity;
  if (cur.pid !== id.pid) return { ok: false, reason: 'PID_MISMATCH' };
  if (cur.executablePath !== id.executablePath) return { ok: false, reason: 'PATH_MISMATCH' };
  if (cur.creationDate !== id.creationDate) return { ok: false, reason: 'CREATION_DATE_MISMATCH' };
  if (!cur.commandLine.includes('--remote-debugging-port=' + cfg.cdp)) return { ok: false, reason: 'CDP_PORT_MISMATCH' };
  if (!cur.commandLine.toLowerCase().includes(profilePath(cfg.profile).toLowerCase())) return { ok: false, reason: 'PROFILE_MISMATCH' };
  return { ok: true, identity: cur };
}

// 从进程命令行取 --proxy-server，作为硬证据（不能只看能否打开网页）
function proxyEvidence(cfg) {
  let out = '';
  try {
    if (process.platform === 'win32') {
      const cp = require('node:child_process');
      const ps = 'Get-CimInstance Win32_Process -Filter "Name=\'chrome.exe\'" | ForEach-Object { $_.CommandLine }';
      out = cp.execSync('powershell.exe -NoProfile -Command "' + ps.replace(/"/g, '\\"') + '"',
        { encoding: 'utf8', timeout: 15000 }).toString();
    } else {
      const cp = require('node:child_process');
      out = cp.execSync('ps -eo args', { encoding: 'utf8', timeout: 10000 }).toString();
    }
  } catch (e) { return { checked: false, error: String(e.message || e) }; }
  const lines = out.split('\n').filter((l) => l.includes('remote-debugging-port=' + cfg.cdp) && l.includes('--user-data-dir='));
  const main = lines.find((l) => !l.includes('--type=renderer')) || lines[0] || '';
  const hasProxy = main.includes('--proxy-server=');
  const proxyMatches = hasProxy && !!cfg.proxy && main.includes('--proxy-server=' + cfg.proxy);
  return { checked: true, found: Boolean(main), hasProxy, proxyMatches, line: main.slice(0, 260) };
}

// 国内窗用境内可达的 IP 检测站，境外窗用 ipify；不能用同一个站，否则国内窗必然失败。
async function ipExit(cfg) {
  const url = cfg.proxy ? 'https://api.ipify.org?format=json' : 'https://myip.ipip.net';
  const r = await postJson('http://127.0.0.1:' + cfg.api + '/cmd', {
    cmd: 'nav', args: [url],
  }, 10000);
  if (!r.ok) return { ok: false, error: r.error };
  await new Promise((res) => setTimeout(res, 3000));
  const e = await postJson('http://127.0.0.1:' + cfg.api + '/cmd', {
    cmd: 'eval', args: ["document.body.innerText.slice(0,300)"],
  }, 10000);
  if (!e.ok) return { ok: false, error: e.error };
  const body = String(e.json && e.json.result ? e.json.result : e.text || '').slice(0, 300);
  const ipMatch = body.match(/(\d{1,3}\.){3}\d{1,3}/);
  return { ok: true, url, ip: ipMatch ? ipMatch[0] : null, body };
}

async function cmdUp(names) {
  const mig = migrateStateIfNeeded();
  const state = mig.state;
  if (!state.instances) state.instances = {};
  const results = [];
  for (const rawName of names) {
    const name = resolveName(rawName);
    if (!name || rawName === 'overseas2') {
      results.push({ name: rawName, status: STATUS.ERROR, reason: rawName === 'overseas2' ? 'SLOT_RETIRED_IN_V1_0_2' : 'UNKNOWN_PROFILE' });
      continue;
    }
    const cfg = DEFAULT_PROFILES[name];
    // 硬约束：总数不得超过 MAX_INSTANCES，且每个出口最多一个
    const active = Object.keys(state.instances).filter((k) => state.instances[k] && state.instances[k].status !== 'STOPPED');
    if (!state.instances[name] && active.length >= MAX_INSTANCES) {
      results.push({ name, status: STATUS.ERROR, reason: 'MAX_INSTANCES_REACHED', active });
      continue;
    }
    const alive = await aliveCdp(cfg.cdp);
    if (alive) {
      // 复用：登记为 reused，down 时不得停止
      state.instances[name] = { status: 'STARTED', reused: true, egress: cfg.egress, cdp: cfg.cdp, api: cfg.api, profile: cfg.profile, at: new Date().toISOString() };
      results.push({ name, status: STATUS.PASS, reason: 'REUSED', browser: alive });
      continue;
    }
    const cdpFree = await portFree(cfg.cdp);
    const apiAlive = await get('http://127.0.0.1:' + cfg.api + '/json/version', 1200);
    // 每个 profile 有专属 API 端口（934x），只可能是本技能自己的孤儿服务，可安全回收。
    if (!cdpFree) { results.push({ name, status: STATUS.PORT_CONFLICT, reason: 'CDP_PORT_IN_USE' }); continue; }
    if (apiAlive.ok) {
      const orphan = findOwnServerPid(cfg.api);
      if (orphan.length === 0) {
        // API 专属端口被非本技能进程占用 —— 绝不回收它，也不能静默继续（会假 PASS）。
        results.push({ name, status: STATUS.PORT_CONFLICT, reason: 'API_PORT_HELD_BY_OTHER', api: cfg.api });
        continue;
      }
      for (const op of orphan) { try { process.kill(op, 'SIGTERM'); } catch {} }
      await new Promise((r) => setTimeout(r, 800));
    }
    const pid = spawnServer(cfg);
    let browser = null;
    for (let i = 0; i < 20; i++) {
      await new Promise((r) => setTimeout(r, 1000));
      browser = await aliveCdp(cfg.cdp);
      if (browser) break;
    }
    if (!browser) { results.push({ name, status: STATUS.ERROR, reason: 'START_TIMEOUT', pid }); continue; }
    // 不能只看 CDP 通了就算成功：API 服务可能因端口占用 while 启动失败（exit 3），
    // 此时必须报 PORT_CONFLICT，绝不能假 PASS。
    let apiReady = null;
    for (let i = 0; i < 8; i++) {
      apiReady = await postJson('http://127.0.0.1:' + cfg.api + '/cmd', { cmd: 'eval', args: ['1+1'] }, 2000);
      if (apiReady.ok) break;
      await new Promise((r) => setTimeout(r, 600));
    }
    const apiValid = apiReady && apiReady.ok && apiReady.json && apiReady.json.ok === true;
    if (!apiValid) {
      const cp = findChromePids(cfg);
      for (const p of cp) { try { process.kill(p, 'SIGTERM'); } catch {} }
      results.push({ name, status: STATUS.PORT_CONFLICT, reason: 'API_PORT_NOT_SERVING', pid, chromePids: cp });
      continue;
    }
    await new Promise((r) => setTimeout(r, 1500));
    const chromePids = findChromePids(cfg); // Chrome 是 detached 的，必须单独登记，down 才能精确停
    state.instances[name] = { status: 'STARTED', reused: false, egress: cfg.egress, cdp: cfg.cdp, api: cfg.api, profile: cfg.profile, pid, chromePids, pidIdentity: chromeIdentity(cfg, chromePids), at: new Date().toISOString() };
    results.push({ name, status: STATUS.PASS, reason: 'STARTED', browser, pid, chromePids });
  }
  writeJson(STATE_FILE, state);
  return results;
}

async function cmdCheck(names) {
  const out = [];
  for (const name of names) {
    const cfg = DEFAULT_PROFILES[name];
    if (!cfg) { out.push({ name, status: STATUS.ERROR, reason: 'UNKNOWN_PROFILE' }); continue; }
    const browser = await aliveCdp(cfg.cdp);
    const pe = proxyEvidence(cfg);
    let status = STATUS.PASS;
    const reasons = [];
    if (!browser) { status = STATUS.CLI_MISSING; reasons.push('CDP_NOT_REACHABLE'); }
    if (!pe.checked) { if (status === STATUS.PASS) status = STATUS.WARN; reasons.push('PROXY_EVIDENCE_UNAVAILABLE'); }
    else {
      if (cfg.proxy && !pe.proxyMatches) { status = STATUS.PROXY_UNAVAILABLE; reasons.push('PROXY_PARAM_MISMATCH'); }
      if (!cfg.proxy && pe.hasProxy) { status = STATUS.PROXY_UNAVAILABLE; reasons.push('DOMESTIC_HAS_PROXY'); }
    }
    out.push({ name, status, reasons, browser, proxy: pe });
  }
  return out;
}

async function cmdDown(names) {
  const state = (readJson(STATE_FILE) && readJson(STATE_FILE).schema_version === STATE_SCHEMA) ? readJson(STATE_FILE) : migrateStateIfNeeded().state;
  const targets = (names && names.length ? names : Object.keys(state.instances || {})).map(resolveName).filter(Boolean);
  const out = [];
  for (const name of targets) {
    const rec = (state.instances || {})[name];
    if (!rec) { out.push({ name, status: STATUS.WARN, reason: 'NOT_REGISTERED' }); continue; }
    if (rec.reused) {
      out.push({ name, status: STATUS.PASS, reason: 'KEPT_REUSED_BROWSER' });
      delete state.instances[name];
      continue;
    }
    const stopped = [];
    const failed = [];
    const cfg = DEFAULT_PROFILES[name];
    // v1.0.2：down 前必须核验登记身份，PID 存在但身份不符 = SAFETY BLOCK，绝不终止。
    const ident = cfg ? verifyIdentity(rec, cfg) : { ok: false, reason: 'NO_CONFIG' };
    if (!ident.ok) {
      out.push({ name, status: STATUS.WARN, reason: 'SAFETY_BLOCK', detail: ident.reason,
        note: '登记进程身份不匹配或不可读，拒绝终止；未执行任何 kill' });
      delete state.instances[name];
      continue;
    }
    // 先停 Chrome 主进程（按已核验的登记 PID，绝不按进程名/数量），再停 Node 服务
    for (const cp of (rec.chromePids || [])) {
      try { process.kill(cp, 'SIGTERM'); stopped.push(cp); } catch (e) { failed.push({ pid: cp, error: e.message }); }
    }
    let nodeGone = false;
    try { process.kill(rec.pid, 'SIGTERM'); stopped.push(rec.pid); }
    catch (e) {
      // ESRCH = 进程已不存在（服务自行退出），属于预期，不算失败
      if (e.code === 'ESRCH') nodeGone = true;
      else failed.push({ pid: rec.pid, error: e.message });
    }
    const chromeStopped = (rec.chromePids || []).length > 0 && stopped.some((p) => (rec.chromePids || []).includes(p));
    out.push({ name, status: failed.length ? STATUS.WARN : STATUS.PASS,
      reason: failed.length ? 'PARTIAL_STOP' : (nodeGone ? 'STOPPED_SERVICE_ALREADY_GONE' : 'STOPPED'),
      stopped, nodeGone, failed });
    delete state.instances[name];
  }
  writeJson(STATE_FILE, state);
  return out;
}

async function cmdBaseline(action) {
  const vpn = await vpnRead();
  if (action === 'show') return { vpn, baseline: readJson(BASELINE_FILE) };
  const b = { vpn, at: new Date().toISOString() };
  writeJson(BASELINE_FILE, b);
  return { written: true, baseline: b };
}

function usage() {
  console.log(`browser-cli —— 浏览器CLI双开VPN v1.0.2（按需双实例）

用法：
  node browser-cli.js route <url|host>                       查询域名出口（vpn/direct/未知拦截）
  node browser-cli.js open <url>                             按出口按需启动或复用实例，并在对应实例打开 URL
  node browser-cli.js up [vpn|direct]                        启动/复用指定实例（不传则按需为空，不自动全开）
  node browser-cli.js check [vpn|direct]                     检查 CDP、代理参数硬证据
  node browser-cli.js down [vpn|direct|all]                  核验身份后仅停本技能登记的实例
  node browser-cli.js baseline [save|show]                   只读保存/显示 VPN 基线
  node browser-cli.js exit-ip [vpn|direct]                   检查各实例公网出口
  node browser-cli.js status                                 显示实例池登记状态
  node browser-cli.js selfcheck                              按需双实例自检（初始0→VPN→DIRECT→最多2）

模型：一个出口类型最多一个实例（vpn=境外, direct=直连），总数 0–2，同出口复用。
未知域名不猜测、不导航，必须询问老板。旧三窗 overseas2/9234 已退出实例池。

边界：不修改 GLOBAL/TUN；不停止复用的浏览器；down 身份不符一律 SAFETY BLOCK。`);
}

(async () => {
  const [cmd, ...args] = process.argv.slice(2);
  try {
    let out;
    switch (cmd) {
      case 'route': out = routeHost(args[0]); break;
      case 'open': {
        const url = args[0];
        const r = routeHost(url);
        if (!r.known) { out = { url, ...r, status: STATUS.WARN, reason: 'UNKNOWN_DOMAIN_ASK_USER', note: '未知出口，未导航，等待老板确认' }; break; }
        const up = await cmdUp([r.egress]);
        const started = up.find((x) => x.status === STATUS.PASS || x.reason === 'REUSED');
        if (!started) { out = { url, ...r, status: STATUS.ERROR, reason: 'INSTANCE_NOT_READY', up }; break; }
        const cfg = DEFAULT_PROFILES[r.egress];
        const nav = await postJson('http://127.0.0.1:' + cfg.api + '/cmd', { cmd: 'nav', args: [url] }, 10000);
        out = { url, ...r, instance: r.egress, nav: nav.ok, up, status: nav.ok ? STATUS.PASS : STATUS.ERROR };
        break;
      }
      case 'up': out = await cmdUp(args.length ? args : []); break;
      case 'check': out = await cmdCheck((args.length ? args : Object.keys(DEFAULT_PROFILES))); break;
      case 'down': out = await cmdDown(args[0] === 'all' ? undefined : args); break;
      case 'baseline': out = await cmdBaseline(args[0] || 'save'); break;
      case 'exit-ip': out = []; for (const n of (args.length ? args.map(resolveName).filter(Boolean) : Object.keys(DEFAULT_PROFILES))) out.push({ name: n, ...(await ipExit(DEFAULT_PROFILES[n])) }); break;
      case 'status': out = migrateStateIfNeeded().state; break;
      case 'selfcheck': {
        // 按需模型：初始0 → 只开 VPN → 再开 DIRECT → 最终恰好 2 个；不启动第三个。
        const mig = migrateStateIfNeeded();
        // 确保从干净状态开始（自检不复用用户既有实例，避免污染）
        const fresh = { schema_version: STATE_SCHEMA, max_instances: MAX_INSTANCES, instances: {}, legacy_profiles: mig.state.legacy_profiles || [], migrated_from: mig.state.migrated_from || null, created_at: new Date().toISOString() };
        writeJson(STATE_FILE, fresh);
        const upVpn = await cmdUp(['vpn']);
        const upDirect = await cmdUp(['direct']);
        const third = await cmdUp(['overseas2']); // 必须被拒绝
        const ck = await cmdCheck(['vpn', 'direct']);
        const vpn = await vpnRead();
        const st = readJson(STATE_FILE);
        const count = Object.keys(st.instances || {}).length;
        const thirdBlocked = third.every((x) => x.status === STATUS.ERROR && x.reason === 'SLOT_RETIRED_IN_V1_0_2');
        out = { initial: 0, upVpn, upDirect, thirdBlocked, instanceCount: count, check: ck, vpn,
          verdict: (ck.every((x) => x.status === STATUS.PASS) && count === 2 && thirdBlocked) ? STATUS.PASS : STATUS.WARN };
        break;
      }
      default: usage(); return;
    }
    console.log(JSON.stringify(out, null, 2));
    if (out && out.verdict && out.verdict !== STATUS.PASS) process.exitCode = 4;
    else if (Array.isArray(out) && out.some((x) => x.status && ![STATUS.PASS, STATUS.WARN].includes(x.status))) process.exitCode = 4;
  } catch (e) { die(1, String(e.stack || e.message || e)); }
})();
