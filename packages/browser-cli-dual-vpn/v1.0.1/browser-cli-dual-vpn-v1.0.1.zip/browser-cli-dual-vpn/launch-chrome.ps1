param(
  [string]$ChromePath,
  [int]$Port,
  [string]$ProfileDir,
  [string]$Proxy,
  [string]$WindowSize = "1280,900",
  [switch]$Visible = $true
)

$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Path $ProfileDir -Force | Out-Null

$argLine = "--remote-debugging-port=$Port --remote-debugging-address=127.0.0.1 --user-data-dir=`"$ProfileDir`" --no-first-run --no-default-browser-check --disable-features=Translate,OptimizationHints,MediaRouter --disable-session-crashed-bubble --disable-crash-reporter --disable-breakpad --noerrdialogs --deny-permission-prompts --disable-notifications --disable-popup-blocking --disable-background-networking --disable-component-update --disable-sync --disable-domain-reliability --metrics-recording-only --safebrowsing-disable-auto-update --window-size=$WindowSize"

if ($Proxy -and $Proxy.Trim().Length -gt 0) {
  $argLine = $argLine + " --proxy-server=$Proxy"
}

$argLine = $argLine + " about:blank"

$p = Start-Process -FilePath $ChromePath -ArgumentList $argLine -PassThru
$w = $null
for ($i = 0; $i -lt 20 -and -not $w; $i++) {
  Start-Sleep -Milliseconds 100
  $w = Get-CimInstance Win32_Process -Filter "ProcessId=$($p.Id)"
}
if (-not $w) { throw "Chrome process not found" }

[pscustomobject]@{
  pid = $p.Id
  executablePath = $w.ExecutablePath
  commandLine = $w.CommandLine
  creationDate = $w.CreationDate.ToString('o')
} | ConvertTo-Json -Compress
