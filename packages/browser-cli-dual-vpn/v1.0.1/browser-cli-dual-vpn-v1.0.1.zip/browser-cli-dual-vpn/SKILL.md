---
name: browser-cli-dual-vpn
description: 浏览器CLI双开VPN。以国内直连浏览器与境外代理浏览器双实例并行为核心能力，负责双窗启动、独立 Profile、网络出口隔离检查、状态管理与基线恢复；同时提供基于 CDP 的浏览器控制能力，支持 GPT/Gemini 信息包发送、回复抓取及协作闭环。普通浏览器控制是附属能力，不改变本技能以双开网络隔离为主体的定位。当需要两个工作流在同一台电脑各自开一个 GPT 浏览器并发运行时，使用本技能的双境外窗模式。
display_name: "浏览器CLI双开VPN"
display_name_en: "Browser CLI Dual VPN"
description_zh: "以国内直连浏览器与境外代理浏览器双实例并行为核心能力，负责双窗启动、网络出口隔离检查、状态管理与基线恢复；并提供基于 CDP 的浏览器控制与 GPT/Gemini 信息包发送、回复抓取。"
description_en: "Dual-browser network isolation: run a direct domestic Chrome and a proxied overseas Chrome in parallel, verify egress isolation, manage state and baseline restore; includes CDP browser control and GPT/Gemini packet send/reply capture."
version: 1.0.1
---

# 浏览器CLI双开VPN

## 定位

主体：**双开浏览器 + 网络隔离**。一个国内直连窗、一个或多个境外代理窗，同时运行、出口互不干扰。
附属：CDP 浏览器控制（打开网页、点击、输入、上传、截图）、GPT/Gemini 信息包发送与回复抓取。

默认规格（可用环境变量覆盖，但不静默改变）：

| 实例 | CDP | API | Profile | 代理 |
|-|-|-|-|-|
| domestic | 9231 | 9341 | chrome-xhs-profile | 无（直连） |
| overseas | 9233 | 9342 | chrome-gpt-profile | `127.0.0.1:11719` |
| overseas2 | 9234 | 9343 | chrome-gpt-profile-b | `127.0.0.1:11719` |

## 硬规则（违反即失败）

1. **浏览器必须让用户看得见。** 启动参数永远 `CDP_OFFSCREEN=0`，禁止 `--window-position=-32000,-32000`。用户需要扫码登录、人工确认；看不见窗口等于功能不可用。启动后应确认窗口在可视区，不能只靠 CDP 能连通就算成功。
2. **只读 VPN 状态，不擅自改。** 当前基线 `GLOBAL=Pioneer`、`tun.enable=true`。技能启动和退出都不能改；切换 VPN 必须先经老板批准。
3. **不杀复用的浏览器。** `down` 只停本轮启动并登记 PID 的进程；复用（老板原本在用的，如 9250）必须保留。禁止按进程名或数量杀 Chrome。
4. **`--no-proxy-server` ≠ 绕过 TUN。** 必须实测公网出口 IP 才能判定隔离，不能只看 Chrome 启动参数。
5. **不把没测的写成已测。** 13.5.1 上下文接续在本技能首次封装时未真实触发，只能写"继承规程"。
6. **自检只用本包内代码**，禁止运行时依赖其他技能目录或 `work/` 下的临时脚本。

## 命令

```bash
node browser-cli.js up [domestic|overseas|overseas2 ...]   # 启动/复用（默认全部三个）
node browser-cli.js check [names...]                        # 检查 CDP + 代理参数硬证据
node browser-cli.js exit-ip [names...]                      # 检查公网出口（国内用 myip.ipip.net，境外用 ipify）
node browser-cli.js baseline [save|show]                    # 只读保存/显示 VPN 基线
node browser-cli.js down [names...]                         # 仅停止本轮登记启动的进程
node browser-cli.js status                                  # 显示登记状态
node browser-cli.js selfcheck                               # up + check + 出口，输出状态机
```

## 状态机

`PASS / WARN / NEEDS_CONFIG / CLI_MISSING / PORT_CONFLICT / PROXY_UNAVAILABLE / ERROR`

退出码：有非 PASS/WARN 状态 → 4；正常 → 0。

## 协作规则（写在这里，不伪装成程序功能）

- **S3 信息包六块**：背景与前置、本轮做了什么（含真实数字）、没做到什么、自曝、反对至少 1 条（无实质反对就写"本轮未发现"，不许编造）、提问。由大模型结合上下文填写，脚本只提供模板。
- **S6 终态判定**：只有设计方明确输出"验收通过"才算；"有条件通过/待验收/先做这几项"一律未到终态。语义由大模型判断，脚本只提供清单。
- **S8 回报四块**：做了什么、没做到什么、反对、提问。顺序固定，内容由执行方填写，脚本不得编造。
- **A/B/C/D 任务路由**：模型判断任务类型，脚本执行路由结果；不让代码仅凭 URL 决定开几个窗。
- **GPT 是唯一主设计方**（能宣布验收）；Gemini 副审只在方案成型前、连续 3 轮不收敛、终态认定前三个节点介入，不能宣布验收。
- **13.5.1 上下文接续**：GPT 达上下文上限时，点页面内「新聊天」，确认出现"接续自 <原对话名>"，重发自包含信息包；不得新开窗口/普通空白对话冒充。

## 本对话踩过的坑（已纳入容错）

- ChatGPT 页面选择器会变：`.ProseMirror`、aria-label「发送」集中配置，失效时报明确错误，不要静默改用旧选择器。
- 中文长文本不要走 shell 参数，用文件传递。
- Python 调 bash 包装的 CLI（lark-cli）会失败，要明确运行环境和退出码。
- 文本长度稳定判回复完成会误判长停顿，必须结合"回答已完成"标记 + 停止按钮 + 角色 + 尾部指纹。
- 发送成功 ≠ 已回复 ≠ 验收通过。
- `down` 必须登记 Chrome 主进程 PID（按 profile + CDP 端口精确匹配），否则只停 Node 服务、Chrome 留着占端口。

## 顾问协作自动化（老板 2026-11-27 规则）

GPT 不是"老板叫才问"。有两个场景，必须分清：

| 场景 | 流程 | 要不要请示老板 |
|-|-|-|
| 场景 1 · 老板发起 | 老板给任务 → 执行方整理信息问 GPT → 回复老板 → 老板批准 → 执行 | 问之前不用，执行前必须批准 |
| 场景 2 · 失败触发 | 老板已批准执行 → 执行反复失败达 3 次 → **执行方自动开浏览器问 GPT** → 带方案继续执行成功 → 回复老板 | **自动问 GPT 不用再请示**（已授权） |

### "失败 3 次"的可执行定义

- **同一方法重试不重复计数**（第一次失败后同一方法再试 2 次，仍算 1 次尝试）
- **换一种实质不同的方法才算新的一次尝试**
- 由代码计数，不让执行方凭感觉判断：`node runtime/consultant.js fail <taskId> <method> <reason>`
- 计数存 `~/.workbuddy/browser-cli-dual-vpn/failures.json`
- 返回 `shouldConsult: true` 时，**必须**自动进入下面的咨询流程，不得跳过

### 自动咨询流程（场景 2）

1. 写自包含信息包到文件（背景 / 已批准的方案 / 做了什么 / **三次失败的真实报错与已排除项** / 需要 GPT 裁决什么）。中文长文本走文件，不走 shell 参数。
2. 若上下文已满 → 执行 `node runtime/consultant.js continuation-check`：
   - 它点页面内「新聊天」并硬判据检查是否出现 **"接续自 <原对话名>"**
   - `ok:false` 时**禁止声称接续成功**，如实报告并停止（不得用普通空白对话冒充）
3. `node runtime/consultant.js ask <信息包文件> [超时秒]`
   - 精确锁定 `form div.ProseMirror[contenteditable="true"]`（页面上可能有历史消息编辑框，选错就发不出去）
   - 输入字数 ≥ 信息包 90% 才点 form 内的「发送」按钮
   - 轮询"回答已完成"标记 + 停止按钮 + 尾部指纹
   - 页面报"未收到 ChatGPT 的回复"立即判失败，不假装成功
4. 拿 GPT 方案后继续执行；**若方案涉及改代码/删文件/外部写操作，仍回到老板批准**（自动授权只覆盖"问 GPT"这个动作本身）
5. 成功后回复老板，附证据路径

### 可回读证据（防假阳性）

每次咨询自动在 `~/.workbuddy/browser-cli-dual-vpn/consult-evidence/` 留下：
- `<id>-packet.md` 信息包原文
- `<id>-reply.md` GPT 回复原文
- `<id>-evidence.json` 时间戳 / 输入字数 / 发送结果 / 回复字数 / 耗时 / 是否报错

**没有这三份文件，不得说"已问过 GPT"。** 执行方写一句"已咨询"不算证据。

### 命令速查（补充）

```bash
node runtime/consultant.js fail <taskId> <method> <reason>   # 记一次失败，返回 shouldConsult
node runtime/consultant.js continuation-check                # 上下文接续检查（硬判据）
node runtime/consultant.js ask <信息包文件> [超时秒]          # 问GPT并留证据
node runtime/consultant.js evidence                          # 列出所有证据文件
```
