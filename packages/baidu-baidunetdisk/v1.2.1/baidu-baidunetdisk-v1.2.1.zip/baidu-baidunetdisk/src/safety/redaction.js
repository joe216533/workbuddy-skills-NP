'use strict';
// 日志敏感信息脱敏：任何写进日志或输出的字符串都必须先过这里

// 需要整体打码的字段：只包含"泄露即等于交出账号"的真机密。
// 注意：分享提取码（pwd / password）故意不在此列——它本来就是要发给接收方的公开信息，
// 打码会让 full_url 变成 ?pwd=***，对方永远打不开。这是实测踩过的坑。
const SECRET_KEYS = /^(bduss|stoken|randsk|bdclnd|sekey|cookie|authorization)$/i;

// BDUSS/STOKEN 的值形态：长串 base64url 或十六进制
const TOKEN_LIKE = /\b[A-Za-z0-9_\-+=]{24,}\b/g;

function maskValue(v) {
  const s = String(v == null ? '' : v);
  if (s.length <= 4) return '***';
  return `***(${s.length})`;
}

// 字符串级脱敏：抹掉 key=value 形式的真机密与疑似 token 长串
function redact(input) {
  if (input == null) return input;
  let s = typeof input === 'string' ? input : String(input);
  // 只处理鉴权类字段，不碰 pwd/password（分享提取码必须原样呈现）
  s = s.replace(/\b(BDUSS|STOKEN|BDCLND|sekey|randsk)=([^;\s&"']+)/gi, (_m, k) => `${k}=***`);
  // 只对"像凭据"的长串打码，避免误伤路径、文件名与哈希
  s = s.replace(TOKEN_LIKE, (m) => {
    // 纯十六进制一律保留：那是 MD5/SHA256 之类的校验值，不是机密，而且必须让人看见
    if (/^[0-9a-f]+$/i.test(m)) return m;
    // 纯字母或纯数字的串也不是凭据（凭据都是字母数字混合）
    if (!/\d/.test(m) || !/[A-Za-z]/.test(m)) return m;
    return `***(${m.length})`;
  });
  return s;
}

// 对象级脱敏：深拷贝并把敏感键整体替换
function redactObject(obj, depth = 0) {
  if (obj == null || depth > 6) return obj;
  if (typeof obj === 'string') return redact(obj);
  if (typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map((x) => redactObject(x, depth + 1));
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    if (SECRET_KEYS.test(k)) out[k] = maskValue(v);
    else out[k] = redactObject(v, depth + 1);
  }
  return out;
}

// 只保留白名单字段，用于对外输出（宁可少给，不可多给）
function pick(obj, keys) {
  const out = {};
  for (const k of keys) if (obj && Object.prototype.hasOwnProperty.call(obj, k)) out[k] = obj[k];
  return out;
}

module.exports = { redact, redactObject, maskValue, pick, SECRET_KEYS };
