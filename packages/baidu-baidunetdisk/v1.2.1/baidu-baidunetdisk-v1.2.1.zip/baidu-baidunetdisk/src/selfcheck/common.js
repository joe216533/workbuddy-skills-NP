'use strict';
// 自检核心：配置合并、日期/锁/状态/历史/状态机/错误码
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const ROOT = path.join(os.homedir(), '.workbuddy', 'keep-agent');
const DIR_STATE = path.join(ROOT, 'state');
const DIR_HISTORY = path.join(ROOT, 'history');
const DIR_LOCK = path.join(ROOT, 'locks');

// 错误码（两平台共用）
const E = {
  CONFIG_MISSING: 'CONFIG_MISSING',
  CLI_MISSING: 'CLI_MISSING',
  AUTH_MISSING: 'AUTH_MISSING',
  AUTH_EXPIRED: 'AUTH_EXPIRED',
  AUTH_INVALID: 'AUTH_INVALID',
  SPACE_INSUFFICIENT: 'SPACE_INSUFFICIENT',
  LINK_INVALID: 'LINK_INVALID',
  PASSCODE_INVALID: 'PASSCODE_INVALID',
  PERMISSION_DENIED: 'PERMISSION_DENIED',
  RATE_LIMITED: 'RATE_LIMITED',
  QUOTA_EXCEEDED: 'QUOTA_EXCEEDED',
  NETWORK_ERROR: 'NETWORK_ERROR',
  PLATFORM_ERROR: 'PLATFORM_ERROR',
  NAME_CONFLICT: 'NAME_CONFLICT',
  CREATOR_SAVE_BLOCKED: 'CREATOR_SAVE_BLOCKED',
  SAVE_FAILED: 'SAVE_FAILED',
  RESULT_NOT_FOUND: 'RESULT_NOT_FOUND',
  UNKNOWN_ERROR: 'UNKNOWN_ERROR',
};

// 自检最终状态（按顾问第 43 轮裁决）
const STATUS = {
  PASS: 'PASS',
  FAIL: 'FAIL',
  BLOCKED: 'BLOCKED',
  NEEDS_AUTH: 'NEEDS_AUTH',
  NEEDS_CONFIG: 'NEEDS_CONFIG',
  ERROR: 'ERROR',
  NOT_RUN: 'NOT_RUN',
};

// 兼容旧版 kind 字段
const KIND = {
  OK: 'ok',
  CLEAR_FAULT: 'clear_fault',
  SUSPECT_SKILL: 'suspect_skill',
};

const HINT = {
  [E.CONFIG_MISSING]: '包内默认配置缺失，请重新安装技能包',
  [E.CLI_MISSING]: '保存方命令行脚本缺失，请重新安装对应技能',
  [E.AUTH_MISSING]: '当前没有可用的授权账号，请先完成网盘授权',
  [E.AUTH_EXPIRED]: '保存方账号登录已过期，请重新授权',
  [E.AUTH_INVALID]: '保存方账号凭据无效，请检查授权状态',
  [E.SPACE_INSUFFICIENT]: '保存方网盘空间不足，请清理空间',
  [E.LINK_INVALID]: '测试分享链接已失效，请更新技能包或测试资源',
  [E.PASSCODE_INVALID]: '测试分享提取码错误，请更新技能包或测试资源',
  [E.PERMISSION_DENIED]: '当前账号无权保存该测试分享，请检查账号权限',
  [E.RATE_LIMITED]: '平台频率限制，请稍后重试',
  [E.QUOTA_EXCEEDED]: '平台配额限制，请检查账号配额',
  [E.NETWORK_ERROR]: '网络连接失败，请检查网络',
  [E.PLATFORM_ERROR]: '平台服务异常，请稍后重试',
  [E.NAME_CONFLICT]: '目标目录存在同名文件，服务端已自动改名',
  [E.CREATOR_SAVE_BLOCKED]: '平台禁止创建者转存自己的分享；测试资源账号关系需调整',
  [E.SAVE_FAILED]: '保存失败，请查看诊断信息',
  [E.RESULT_NOT_FOUND]: '命令返回成功但未核验到本次云端文件，需进一步排查',
  [E.UNKNOWN_ERROR]: '未知错误，请保留诊断信息',
};

function ensureDirs() {
  for (const d of [ROOT, DIR_STATE, DIR_HISTORY, DIR_LOCK]) {
    fs.mkdirSync(d, { recursive: true });
  }
}

function todayStamp(tz) {
  const now = new Date();
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz || 'Asia/Shanghai',
    year: 'numeric', month: '2-digit', day: '2-digit',
  });
  return fmt.format(now);
}

function nowISO(tz) {
  const now = new Date();
  const parts = new Intl.DateTimeFormat('sv-SE', {
    timeZone: tz || 'Asia/Shanghai',
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).format(now);
  return parts.replace(' ', 'T');
}

function executionId(platform) {
  const d = new Date();
  return `${d.getTime().toString(36)}-${platform}-${Math.random().toString(36).slice(2, 8)}`;
}

function isPlainObject(v) {
  return v && typeof v === 'object' && !Array.isArray(v);
}

function deepMerge(base, override) {
  const out = isPlainObject(base) ? { ...base } : {};
  if (!isPlainObject(override)) return out;
  for (const [k, v] of Object.entries(override)) {
    out[k] = isPlainObject(v) && isPlainObject(out[k]) ? deepMerge(out[k], v) : v;
  }
  return out;
}

// 默认配置随包分发；本机私有配置只覆盖账号/脚本/目录等机器相关字段
function loadMergedConfig(defaultPath, privatePath) {
  let defaults = null;
  try {
    defaults = JSON.parse(fs.readFileSync(defaultPath, 'utf8'));
  } catch {
    return { ok: false, cfg: null, hasPrivate: false, error: E.CONFIG_MISSING };
  }
  let local = null;
  try {
    if (privatePath && fs.existsSync(privatePath)) {
      local = JSON.parse(fs.readFileSync(privatePath, 'utf8'));
    }
  } catch {
    local = null;
  }
  return { ok: true, cfg: deepMerge(defaults, local), hasPrivate: Boolean(local), error: null };
}

function fallbackCli(platform, moduleDir) {
  if (platform === 'baidu') {
    return path.join(moduleDir, '..', '..', 'scripts', 'baidu-baidunetdisk.cjs');
  }
  if (platform === 'quark') {
    const packaged = path.join(moduleDir, '..', 'runtime', 'quark-drive.cjs');
    if (fs.existsSync(packaged)) return packaged;
    return process.env.QUARK_DRIVE_CLI ||
      path.join(os.homedir(), '.workbuddy', 'skills', 'quarkclouddrive', 'scripts', 'quark-drive.cjs');
  }
  return null;
}

function resolvePlatformConfig(merged, platform, moduleDir) {
  const all = merged || {};
  const pub = (all.providers && all.providers[platform]) || {};
  const loc = (all.platforms && all.platforms[platform]) || {};
  return {
    // 公开测试资源只从包内默认配置读取；本机私有配置不得覆盖分享链接或提取码。
    share_url: pub.share_url || '',
    passcode: pub.share_code ?? '',
    saver_cli: loc.saver_cli || pub.saver_cli || fallbackCli(platform, moduleDir),
    saver_alias: loc.saver_alias || pub.saver_alias || null,
    archive_path: loc.archive_path || pub.archive_path || null,
    archive_fid: loc.archive_fid || pub.archive_fid || null,
    expected_name: (all.probe && all.probe.filename) || pub.expected_name || 'skill-self-check.txt',
    expected_size: (all.probe && all.probe.expected_size) || pub.expected_size || 1024,
    expected_sha256: (all.probe && all.probe.expected_sha256) || pub.expected_sha256 || null,
    resource_version: (all.self_check && all.self_check.resource_version) || pub.resource_version || 'v1',
  };
}

function statusForError(error) {
  if ([E.AUTH_MISSING, E.AUTH_EXPIRED, E.AUTH_INVALID].includes(error)) return STATUS.NEEDS_AUTH;
  if ([E.CONFIG_MISSING, E.CLI_MISSING].includes(error)) return STATUS.NEEDS_CONFIG;
  if ([E.CREATOR_SAVE_BLOCKED].includes(error)) return STATUS.BLOCKED;
  if ([E.UNKNOWN_ERROR].includes(error)) return STATUS.ERROR;
  return STATUS.FAIL;
}

function statusToKind(status) {
  if (status === STATUS.PASS) return KIND.OK;
  if ([STATUS.NEEDS_AUTH, STATUS.NEEDS_CONFIG, STATUS.BLOCKED].includes(status)) return KIND.CLEAR_FAULT;
  return KIND.SUSPECT_SKILL;
}

function statePath(platform) {
  return path.join(DIR_STATE, `${platform}.json`);
}

function readState(platform) {
  try {
    return JSON.parse(fs.readFileSync(statePath(platform), 'utf8'));
  } catch {
    return null;
  }
}

function writeState(platform, obj) {
  ensureDirs();
  const p = statePath(platform);
  const tmp = p + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), 'utf8');
  fs.renameSync(tmp, p);
}

function appendHistory(platform, rec) {
  ensureDirs();
  fs.appendFileSync(path.join(DIR_HISTORY, `${platform}.jsonl`), JSON.stringify(rec) + '\n', 'utf8');
}

function readHistory(platform, limit = 90) {
  const p = path.join(DIR_HISTORY, `${platform}.jsonl`);
  if (!fs.existsSync(p)) return [];
  const lines = fs.readFileSync(p, 'utf8').split('\n').filter(Boolean);
  return lines.slice(-limit).map((l) => {
    try { return JSON.parse(l); } catch { return null; }
  }).filter(Boolean);
}

function acquireLock(platform) {
  ensureDirs();
  const p = path.join(DIR_LOCK, `${platform}.lock`);
  try {
    const fd = fs.openSync(p, 'wx');
    fs.writeSync(fd, String(process.pid));
    fs.closeSync(fd);
    return { release() { try { fs.unlinkSync(p); } catch {} } };
  } catch (e) {
    if (e.code === 'EEXIST') {
      try {
        const st = fs.statSync(p);
        if (Date.now() - st.mtimeMs > 10 * 60 * 1000) {
          fs.unlinkSync(p);
          const fd = fs.openSync(p, 'wx');
          fs.writeSync(fd, String(process.pid));
          fs.closeSync(fd);
          return { release() { try { fs.unlinkSync(p); } catch {} } };
        }
      } catch {}
      return null;
    }
    throw e;
  }
}

function humanSize(n) {
  if (!Number.isFinite(n) || n < 0) return '-';
  if (n < 1024) return `${n} B`;
  const u = ['KB', 'MB', 'GB', 'TB'];
  let v = n / 1024;
  let i = 0;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(2)} ${u[i]}`;
}

function classifySpace(freeBytes, th) {
  const t = th || {};
  if (!Number.isFinite(freeBytes)) return { status: 'UNKNOWN', level: 'unknown' };
  const deny = t.deny_free_bytes ?? 20971520;
  const warn = t.warn_free_bytes ?? 104857600;
  if (freeBytes <= deny) return { status: 'CRITICAL', level: 'deny' };
  if (freeBytes < warn) return { status: 'WARNING', level: 'warn' };
  return { status: 'NORMAL', level: 'ok' };
}

module.exports = {
  ROOT, E, STATUS, KIND, HINT,
  ensureDirs, todayStamp, nowISO, executionId,
  isPlainObject, deepMerge, loadMergedConfig, resolvePlatformConfig,
  statusForError, statusToKind,
  readState, writeState, appendHistory, readHistory,
  acquireLock, humanSize, classifySpace,
};
