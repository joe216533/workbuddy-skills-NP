# 模块架构与调用关系

## 分层

```
┌─────────────────────────────────────────────┐
│ scripts/baidu-baidunetdisk.cjs   唯一入口     │
└───────────────────┬─────────────────────────┘
                    ▼
┌─────────────────────────────────────────────┐
│ src/cli/   命令解析、调度、输出格式化          │
└───────────────────┬─────────────────────────┘
                    ▼
┌─────────────────────────────────────────────┐
│ src/auth/  会话建立（谁在操作）                │
│ src/safety/ 安全闸门（能不能做）               │
└───────────────────┬─────────────────────────┘
                    ▼
┌─────────────────────────────────────────────┐
│ src/api/    协议实现（怎么做）                 │
│ src/storage/ 路径与哈希（基础工具）            │
└───────────────────┬─────────────────────────┘
                    ▼
┌─────────────────────────────────────────────┐
│ src/utils/  错误、日志、平台适配               │
└─────────────────────────────────────────────┘
```

依赖方向只能向下，不能回指。`src/api/*` 不知道 `src/cli/*` 的存在，`src/storage/*` 不依赖网络。

## 三个不可合并的安全边界

| 文件 | 职责 | 为什么必须独立 |
|-|-|-|
| `src/auth_browser-login.js` | 调起浏览器、等登录、取两个 Cookie 字段 | 唯一接触明文凭据的地方，审查范围必须最小 |
| `src/auth_credential-store.js` | 加密落盘、解密读取、按平台分派 | 唯一接触磁盘密文的地方，与浏览器解耦 |
| `src/safety_delete-guard.js` | 路径校验、预览、二次核对、删后复查 | 唯一能触发破坏性操作的地方 |

这三个文件互不 require。`browser-login` 返回明文对象给 `session`，由 `session` 交给
`credential-store` 保存；`delete-guard` 只通过 `api/delete.js` 触达网络。

## 关键调用链

### 授权

```
commands.cmdAuthLogin
  → auth/browser-login.loginWithDedicatedBrowser   # 起浏览器、等 /disk/main、取 cookie、关浏览器
  → auth/session.verifyCredential                  # 立即用新凭据调一次 list，不合格不落盘
  → auth/credential-store.save                     # 平台分派加密
  → auth/accounts.register                         # 写索引
```

### 上传

```
commands.cmdUpload
  → auth/session.openSession                       # 拿 client（cookie + bdstoken）
  → safety/upload-guard.prepareUploadDir           # 规范化目录、必要时逐级创建
  → safety/upload-guard.checkConflict              # 同名预检，默认不覆盖
  → api/upload.uploadFile
       → api/upload.checkSpace                     # 先查容量，不足直接拒绝
       → api/upload.precreate                      # 4MB 分片 MD5 数组
       → api/upload.uploadPart × N                 # 只传服务端要的片
       → client.api('/api/create')                 # 收尾，errno 为唯一成功依据
```

### 转存

```
commands.cmdTransfer
  → api/transfer.transfer
       → api/transfer.openShareSession
            → parseShareUrl                        # surl = 短链去掉首字符 '1'
            → POST /share/verify                   # 换 randsk
            → GET  /share/list  (Cookie + BDCLND)  # 拿 share_id / uk / fs_id
       → POST /share/transfer (sekey=randsk)       # 落盘到自己目录
```

### 删除

```
commands.cmdDelete
  → safety/delete-guard.previewDelete
       → validateTarget        # 绝对路径、禁通配符、禁根目录、限技能目录
       → api/file-list.stat    # 拿 fs_id / size / mtime
       → api/file-list.walk    # 目录递归统计；非空且无 --recursive 直接拒绝
  → safety/delete-guard.executeDelete
       → 检查 --yes
       → recheck               # 重新 stat，fs_id 与 size 必须一致
       → api/delete.deletePaths
       → api/file-list.stat    # 复查，必须查不到才算成功
```

## 错误传播

所有业务失败统一抛 `SkillError(code, text, { exit, errno })`：

- `code` 给程序判断（`NO_SPACE`、`REFUSED_WILDCARD`、`NOT_LOGIN` …）
- `text` 给人看，且必须包含"下一步怎么做"
- `exit` 决定进程退出码（见 `src/utils_errors.js` 的 `EXIT`）

原则：**失败绝不输出成功字样；未执行的项目输出 SKIP，不假报 PASS。**

## 为什么不用 ES Module

WorkBuddy 技能以目录形式加载，父目录可能存在 `"type": "module"` 的 `package.json`，
导致 `.js` 被当 ESM 解析。本技能用 `package.json` 显式固定 `"type": "commonjs"`，
`src/*.js` 统一 CommonJS，入口用 `.cjs` 双重保险。
