# 安全规范

本技能需要接触三类敏感对象：**登录凭据**、**你的网盘文件**、**网络出口**。
下面每一条都是硬性实现约束，代码里没有对应的关闭开关。

---

## 一、授权模型

### 走什么路

不走百度开放平台 API，不申请 `access_token`，不使用官方 SDK。
鉴权复用你在浏览器里登录百度网盘后产生的会话 Cookie。

只取两个字段：

| 字段 | 取自哪个域 | 为什么必须是这个域 |
|-|-|-|
| `BDUSS` | `.baidu.com` | 百度全站登录票据 |
| `STOKEN` | `.pan.baidu.com` | 网盘专用票据 |

踩过的坑：`.passport.baidu.com`、`.pan.baidu.com`、`.pcs.baidu.com`、`.pcsdata.baidu.com`
下都有同名的 `STOKEN` 但**值不同**，取错会直接得到 `errno=-6 未登录`。
所以 `pickCookies()` 按域白名单精确挑选，不按名字撞运气。

其余几十个 cookie 一概丢弃，不写入任何文件。

### 专用浏览器

| 措施 | 实现 | 目的 |
|-|-|-|
| 独立实例 | `--user-data-dir=<临时目录>` | 不碰日常浏览器 Profile |
| 窗口可见 | `spawn(..., { windowsHide: false })` | 由本人扫码登录，程序不代输密码 |
| 国内直连 | `--proxy-server=direct://` `--proxy-bypass-list=*` | 只让该浏览器绕过代理，**不需要关全局 VPN** |
| 端口收敛 | `--remote-debugging-address=127.0.0.1` + 9500–9700 空闲端口 | 调试端口不对外暴露 |
| 用后即毁 | `Browser.close` + `fs.rmSync(profile)` | 不在磁盘留会话残留 |

登录判定只看 `location.href` 是否进入 `/disk/main` 或 `/disk/home`，
这个阶段**不读取任何凭据字段**，登录完成后才取 cookie。

---

## 二、凭据存储

### 平台分派

| 平台 | 机制 | 位置 |
|-|-|-|
| Windows | DPAPI `CurrentUser` | `%LOCALAPPDATA%\baidu-baidunetdisk\accounts\<别名>.cred` |
| macOS | 登录钥匙串 | `security add-generic-password -s baidu-baidunetdisk -a <别名>` |
| Linux | Secret Service | `secret-tool store service baidu-baidunetdisk account <别名>` |
| Linux（降级） | 0600 权限文件 | 无 `secret-tool` 时启用，并明确警告建议安装 libsecret |

**DPAPI 密文不能跨平台、跨机器、跨用户使用。** 这是设计，不是缺陷。
所以 `credential-store.load()` 解密失败时抛 `CRED_UNDECRYPTABLE`，提示重新授权，
而不是尝试"修复"。

### 明文不落盘

Windows 路径的加密流程是：

```
内存明文 ──stdin──► powershell.exe (DPAPI Protect) ──► 直接写二进制密文
```

早期实现先把明文写成 `.plain.tmp` 再加密，这个中间文件已删除。现在明文只经过 stdin 管道，
不产生任何临时文件。

### 多账号隔离

- 每个别名一个凭据文件，`auth logout --as 159` 只删 159 的记录和文件。
- 所有命令都支持 `--as`，未指定时用 `auth use` 设的当前账号。
- **授权失效时不会自动切到另一个账号。** 这是明确的设计取舍：静默切换会让"用错账号"变成
  难以察觉的事故，尤其是删除。
- 别名由使用者指定（如 `159`、`156`），不自动读百度昵称——昵称含个人信息、会变、会重名。

---

## 三、删除安全（本技能风险最高的部分）

### 十道闸

| # | 闸门 | 实现位置 | 拒绝码 |
|-|-|-|-|
| 1 | 只接受网盘绝对路径 | `validateTarget` | `REFUSED_RELATIVE` |
| 2 | 禁止通配符 `* ? [ ] { }` | `validateTarget` | `REFUSED_WILDCARD` |
| 3 | 禁止根目录与空路径 | `validateTarget` | `REFUSED_ROOT` / `REFUSED_EMPTY` |
| 4 | 只允许技能目录之下，且不许删该目录本身 | `validateTarget` | `REFUSED_OUTSIDE` / `REFUSED_SKILL_ROOT` |
| 5 | 禁止 `..` 越界 | `paths.normalize` | `REFUSED_TRAVERSAL` |
| 6 | 必须显式 `--yes` | `executeDelete` | `REFUSED_NO_YES` |
| 7 | 非空目录必须 `--recursive` | `previewDelete` | `REFUSED_NEED_RECURSIVE` |
| 8 | 执行前 `fs_id` 与大小二次核对 | `recheck` | `REFUSED_ID_CHANGED` / `REFUSED_SIZE_CHANGED` |
| 9 | 删除后必须复查目标已消失 | `executeDelete` | 状态降为 `unverified` |
| 10 | 结果未知绝不报成功 | `api/delete.deletePaths` | `DELETE_UNKNOWN` |

### 为什么要有第 8 道

只有路径是不够的。可能发生这种时序：

```
1. 程序 list 看到 /来自：WorkBuddy/baidu-baidunetdisk/test.zip  (fs_id=111)
2. 你在网页端把 test.zip 删掉，又传了一个同名但内容不同的 test.zip (fs_id=222)
3. 程序按路径执行删除 —— 删掉的是 fs_id=222 的新文件
```

所以预览时记录 `fs_id` 与 `size`，执行前重新 `stat` 目标，两者都必须一致。
百度删除接口只接受路径、不接受 `fs_id`，因此"用 ID 精确删除"做不到，
二次核对是当前的等价手段。

### 递归删除的门槛更高

| 对象 | 要求 |
|-|-|
| 单个文件 | `delete <路径> --yes` |
| 空目录 | `delete <路径> --yes` |
| 非空目录 | `delete <路径> --recursive --yes`，且预览必须列出文件数、子目录数、总大小 |

### 删除后去哪了

删除的对象进入**网页端回收站**，可以在 `pan.baidu.com` 恢复。
但**回收站内容仍然占用容量**——这一点直接决定了空间不足时的提示语必须包含"回收站也要清"。

---

## 四、日志与输出脱敏

`src/safety_redaction.js` 做三件事：

1. 按 key 打码：`BDUSS`、`STOKEN`、`BDCLND`、`sekey`、`randsk`、`pwd`、`password`、`cookie`
2. 字符串级抹除 `key=value` 形态
3. 长 token 形态的裸串打码，保留长度信息便于排查

日志只写 stderr，不写本地文件。`BD_DEBUG=1` 才输出 DEBUG 级别，且同样经脱敏。
`--json` 输出同样过 `fmtScalar → redact`。

---

## 五、不做的事

- 不把凭据上传到任何服务器
- 不上报使用统计
- 不读取你网盘里与本次操作无关的目录
- 不自动重试删除
- 不在授权失效时自动切换账号
- 不提供 `--allow-outside` 之类的删除绕过开关
- 不修改百度账号的任何设置（不转让、不改密、不解绑）

---

## 六、使用者需要自己守住的三条

1. **不要把 `.cred` 文件或浏览器 Profile 发给别人，也不要放进代码仓库/网盘/聊天工具。**
2. **不要在共用电脑上长期保留授权**，用完执行 `auth logout --as <别名>`。
3. **删除前一定看预览清单**。程序会拦住明显错误，但"这个东西是不是真的该删"只有你知道。
