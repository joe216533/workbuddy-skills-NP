'use strict';
// 创建目录（mkdir -p 语义：逐级创建，已存在不视为失败）
const { normalize } = require('./storage_paths');
const log = require('./utils_logger');

async function mkdirOnce(client, dir) {
  const d = normalize(dir);
  const r = await client.api('/api/create', {}, new URLSearchParams({
    path: d,
    isdir: '1',
    block_list: '[]',
    size: '0',
    rtype: '0',
  }).toString());
  const j = r.j || {};
  // -8 = 已存在，视为成功
  if (j.errno === 0) return { path: d, created: true, fs_id: j.fs_id ? Number(j.fs_id) : null };
  if (j.errno === -8) return { path: d, created: false, existed: true, fs_id: j.fs_id ? Number(j.fs_id) : null };
  return { path: d, created: false, errno: j.errno, show_msg: j.show_msg || '' };
}

// 逐级确保目录存在，返回 { ok, failedAt }
async function ensureDir(client, dir) {
  const d = normalize(dir);
  if (d === '/') return { ok: true, path: '/', steps: [] };
  const segs = d.split('/').filter(Boolean);
  const steps = [];
  let cur = '';
  for (const s of segs) {
    cur += '/' + s;
    const r = await mkdirOnce(client, cur);
    steps.push(r);
    if (r.errno != null && r.errno !== 0 && r.errno !== -8) {
      log.warn(`创建目录失败于 ${cur}（errno ${r.errno}）`);
      return { ok: false, path: cur, errno: r.errno, steps };
    }
  }
  return { ok: true, path: d, steps };
}

module.exports = { mkdirOnce, ensureDir };
