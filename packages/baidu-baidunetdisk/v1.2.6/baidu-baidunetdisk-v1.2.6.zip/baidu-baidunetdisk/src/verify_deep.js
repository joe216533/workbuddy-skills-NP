'use strict';
// 深度验证：端到端跑一遍上传 → 分享 → 下载 → 撤分享 → 删除 → 复查清理
//
// 铁律：
//   - 必须显式 --yes 才执行（会真实产生并删除文件）
//   - 只能使用技能专用测试目录 /来自：WorkBuddy/baidu-baidunetdisk/.verify，绝不允许指向业务目录
//   - 清理失败必须让整体 FAIL，不能因为上传/分享/下载成功就报告通过
//   - 失败时必须说明哪一步失败、哪些临时资产已清理、哪些未清理、残留分享的处理方式
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

const { openSession } = require('./auth_session');
const { ensureDir } = require('./api_mkdir');
const { uploadFile } = require('./api_upload');
const { createShare, cancelShares, probeShare } = require('./api_share');
const { downloadByFsid } = require('./api_download');
const { deletePaths } = require('./api_delete');
const { listAll, stat } = require('./api_file-list');
const { VERIFY_DIR, join } = require('./storage_paths');
const { sha256Buffer, humanSize } = require('./storage_integrity');
const { SkillError, EXIT } = require('./utils_errors');
const { runBasic } = require('./verify_basic');
const log = require('./utils_logger');

const TEST_DIR = VERIFY_DIR;
const TEST_SIZE = 64 * 1024; // 64KB 随机内容，足够验证完整性又不是大文件

function makeTestFile(fileName) {
  const dir = path.join(os.tmpdir(), 'bdskill-verify');
  fs.mkdirSync(dir, { recursive: true });
  const p = path.join(dir, fileName);
  const buf = crypto.randomBytes(TEST_SIZE);
  fs.writeFileSync(p, buf);
  return { path: p, sha256: sha256Buffer(buf), size: TEST_SIZE };
}

async function runDeep({ as, yes } = {}) {
  if (!yes) {
    throw new SkillError(
      'REFUSED_NO_YES',
      '深度验证会上传、分享、下载并删除真实文件，必须显式加 --yes。测试只会在专用目录 ' +
        TEST_DIR +
        ' 内进行，不会碰你的业务文件。',
      { exit: EXIT.REFUSED }
    );
  }

  const base = await runBasic({ as });
  const r = {
    skill_version: base.skill_version,
    node_version: base.node_version,
    module_integrity: base.module_integrity,
    credential_status: base.credential_status,
    account_alias: base.account_alias,
    api_status: base.api_status,
    list_status: base.list_status,
    upload_status: 'SKIP',
    share_status: 'SKIP',
    download_status: 'SKIP',
    delete_status: 'SKIP',
    cleanup_status: 'SKIP',
    overall_status: 'FAIL',
    test_dir: TEST_DIR,
    steps: [],
  };

  if (base.overall_status !== 'PASS') {
    r.summary = `普通验证未通过，深度验证中止：${base.summary}`;
    r.steps.push({ step: 'preflight', status: 'FAIL', detail: base.summary });
    return r;
  }

  const client = await openSession({ as: base.account_alias });
  const stamp = new Date().toISOString().replace(/[-:T.Z]/g, '').slice(0, 14);
  const fileName = `verify-${stamp}.bin`;
  let local = null;
  let remotePath = null;
  let shareId = null;
  let shareUrl = null;
  const residual = [];

  const step = (name, status, detail) => {
    r.steps.push({ step: name, status, detail: detail || '' });
    log.step(`${name} → ${status}${detail ? '：' + detail : ''}`);
  };

  try {
    // 1. 专用目录
    const mk = await ensureDir(client, TEST_DIR);
    if (!mk.ok) throw new SkillError('MKDIR_FAILED', `无法创建测试目录 ${TEST_DIR}`);
    step('准备测试目录', 'PASS', TEST_DIR);

    // 2. 生成测试文件
    local = makeTestFile(fileName);
    step('生成测试文件', 'PASS', `${fileName}（${humanSize(local.size)}）`);

    // 3. 上传
    const up = await uploadFile(client, local.path, TEST_DIR);
    remotePath = up.remote_path;
    r.upload_status = 'PASS';
    step('上传', 'PASS', `${up.upload_method}，fs_id=${up.fs_id}`);

    // 4. 回读确认
    const found = await stat(client, remotePath);
    if (!found) throw new SkillError('VERIFY_LIST_MISMATCH', `上传成功但目录里查不到 ${remotePath}`);
    step('回读确认', 'PASS', `fs_id=${found.fs_id}，大小 ${humanSize(found.size)}`);

    // 5. 创建分享（1 天有效期，降低影响面）
    const sh = await createShare(client, [remotePath], { period: 1 });
    shareId = sh.share_id;
    shareUrl = sh.short_url;
    r.share_status = 'PASS';
    step('创建分享', 'PASS', `share_id=${shareId}，${sh.period_text}`);

    // 6. 验证分享可读（另一条会话走分享页接口）
    const probe = await probeShare(client, shareUrl);
    if (!probe.ok) {
      step('验证分享记录', 'FAIL', `分享接口回读失败 errno=${probe.errno}`);
      r.share_status = 'FAIL';
      residual.push(`分享 ${shareUrl} 可能无效`);
    } else {
      step('验证分享记录', 'PASS', '分享页可读');
    }

    // 7. 下载
    const outDir = path.join(os.tmpdir(), 'bdskill-verify-download');
    const dl = await downloadByFsid(client, found.fs_id, outDir, { saveAs: fileName, expectSize: local.size });
    r.download_status = 'PASS';
    step('下载', 'PASS', `${humanSize(dl.file_size)}`);

    // 8. SHA256 对照
    if (dl.sha256 !== local.sha256) {
      throw new SkillError('SHA_MISMATCH', `SHA256 不一致：本地 ${local.sha256}，下载 ${dl.sha256}`);
    }
    step('SHA256 对照', 'PASS', dl.sha256.slice(0, 32) + '…');

    // 9. 撤销分享
    const cancel = await cancelShares(client, [shareId]);
    if (!cancel.ok) {
      step('撤销分享', 'FAIL', cancel.text || '撤销失败');
      residual.push(`分享 ${shareUrl}（share_id=${shareId}）仍未撤销`);
      r.share_status = 'FAIL';
    } else {
      const after = await probeShare(client, shareUrl);
      if (after.ok) {
        step('撤销分享', 'UNVERIFIED', '接口返回成功，但分享页仍可读');
        residual.push(`分享 ${shareUrl} 状态未确认，建议手动检查`);
      } else {
        shareId = null;
        step('撤销分享', 'PASS', '分享已失效');
      }
    }

    // 10. 删除测试文件
    const del = await deletePaths(client, [remotePath]);
    if (!del.ok) {
      r.delete_status = 'FAIL';
      step('删除测试文件', 'FAIL', del.text || `errno=${del.errno}`);
      residual.push(`网盘文件 ${remotePath}`);
    } else {
      const gone = await stat(client, remotePath);
      if (gone) {
        r.delete_status = 'UNVERIFIED';
        step('删除测试文件', 'UNVERIFIED', '接口成功但复查仍能查到');
        residual.push(`网盘文件 ${remotePath}（复查仍存在）`);
      } else {
        r.delete_status = 'PASS';
        remotePath = null;
        step('删除测试文件', 'PASS', '已移入回收站，目录内已消失');
      }
    }
  } catch (e) {
    const code = e.code || 'ERROR';
    const text = e.text || e.message || String(e);
    step('执行中断', 'FAIL', `${code}: ${text}`);
    r.error = `${code}: ${text}`;
    // 中断也要尝试清理，避免留垃圾
    if (remotePath) residual.push(`网盘文件 ${remotePath}`);
    if (shareId) residual.push(`分享 ${shareUrl}（share_id=${shareId}）`);
  } finally {
    // 尽力清理：撤分享 + 删网盘文件 + 删本地临时文件
    if (shareId) {
      const c = await cancelShares(client, [shareId]).catch(() => ({ ok: false }));
      if (c.ok) {
        const i = residual.findIndex((x) => x.includes(`share_id=${shareId}`));
        if (i >= 0) residual.splice(i, 1);
        step('清理临时分享', 'PASS', `share_id=${shareId} 已撤销`);
      }
    }
    if (remotePath) {
      const d = await deletePaths(client, [remotePath]).catch(() => ({ ok: false }));
      const gone = await stat(client, remotePath).catch(() => null);
      if (d.ok && !gone) {
        const i = residual.findIndex((x) => x.includes(remotePath));
        if (i >= 0) residual.splice(i, 1);
        step('清理临时文件', 'PASS', remotePath);
        remotePath = null;
      }
    }
    if (local && fs.existsSync(local.path)) {
      try {
        fs.rmSync(local.path, { force: true });
        step('清理本地临时文件', 'PASS', path.basename(local.path));
      } catch {
        residual.push(`本地临时文件 ${local.path}`);
      }
    }

    // 最终复查：测试目录里应当没有我们留下的文件
    let leftover = [];
    try {
      const items = await listAll(client, TEST_DIR);
      leftover = items.filter((x) => x.name.startsWith('verify-')).map((x) => x.name);
    } catch (e) {
      leftover = ['（无法读取测试目录）'];
    }
    if (leftover.length) {
      for (const n of leftover) if (!residual.some((x) => x.includes(n))) residual.push(`测试目录残留 ${join(TEST_DIR, n)}`);
    }

    if (residual.length) {
      r.cleanup_status = 'FAIL';
      step('清理复查', 'FAIL', `${residual.length} 项残留`);
    } else {
      r.cleanup_status = 'PASS';
      step('清理复查', 'PASS', '测试目录内无残留，分享已撤销，本地临时文件已删除');
    }
    r.residual = residual;
  }

  const hardFail =
    r.cleanup_status !== 'PASS' ||
    [r.upload_status, r.share_status, r.download_status, r.delete_status].some((s) => s === 'FAIL');
  r.overall_status = hardFail ? 'FAIL' : 'PASS';

  if (r.overall_status === 'PASS') {
    r.summary = '深度验证通过：上传、分享、下载、SHA256 校验、撤销分享、删除、清理复查全部成功。';
  } else if (r.cleanup_status !== 'PASS') {
    r.summary =
      '深度验证未通过：清理未完成，必须人工处理残留后再判定。' +
      (residual.length ? ` 残留：${residual.join('；')}` : '');
  } else {
    const failed = r.steps.filter((s) => s.status === 'FAIL').map((s) => s.step);
    r.summary = `深度验证未通过：${failed.join('、')} 失败。`;
  }
  return r;
}

module.exports = { runDeep, TEST_DIR };
