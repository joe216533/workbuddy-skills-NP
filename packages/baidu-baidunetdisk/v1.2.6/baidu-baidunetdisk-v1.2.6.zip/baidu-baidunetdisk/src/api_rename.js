'use strict';
// 重命名（单文件 / 单目录，一次一个）
//
// 接口：POST /api/filemanager?opera=rename
//       body: filelist=[{"path":"/a/b.txt","newname":"c.txt"}]&async=0&ondup=0
// 实测（159 账号，2026-11-26）：返回 errno=0，info[0].to_path 是改名后的完整路径。
//
// 设计约束：
//   - 只改当前这一层的名字，不接受带路径分隔符的新名字（避免被当成移动）
//   - 不改后缀以外的东西也不阻止，但会提示后缀变化，防止误把 .txt 改成 .exe
//   - 目标已存在同名时服务端会报错，不在这里自动覆盖
const { SkillError, explain } = require('./utils_errors');
const { normalize, basename } = require('./storage_paths');

function splitExt(name) {
  const i = name.lastIndexOf('.');
  if (i <= 0) return { stem: name, ext: '' };
  return { stem: name.slice(0, i), ext: name.slice(i) };
}

async function renamePath(client, remotePath, newName) {
  const from = normalize(remotePath);
  const nn = String(newName || '').trim();

  if (!nn) throw new SkillError('BAD_PARAM', '没有提供新名字。');
  if (/[\\/]/.test(nn)) {
    throw new SkillError('BAD_PARAM', `新名字不能包含路径分隔符：「${nn}」。本命令只改名，不移动。`);
  }
  if (nn === '.' || nn === '..') {
    throw new SkillError('BAD_PARAM', `新名字不合法：「${nn}」。`);
  }
  if (nn.length > 255) {
    throw new SkillError('BAD_PARAM', '新名字过长（超过 255 字符）。');
  }

  const oldName = basename(from);
  if (oldName === nn) {
    return {
      ok: true,
      unchanged: true,
      from,
      to: from,
      note: '新旧名字相同，未执行改名。',
    };
  }

  const a = splitExt(oldName);
  const b = splitExt(nn);
  const extChanged = a.ext.toLowerCase() !== b.ext.toLowerCase();

  const filelist = JSON.stringify([{ path: from, newname: nn }]);
  const body = new URLSearchParams({ filelist, async: '0', ondup: '0' }).toString();

  let r;
  try {
    r = await client.api('/api/filemanager', { opera: 'rename' }, body);
  } catch (e) {
    // 请求已发出但结果未知：绝不报成功
    throw new SkillError(
      'RENAME_UNKNOWN',
      `改名请求已发出，但未收到服务端结果（${e.message}）。请先用 list 确认新名字是否已生效，不要直接重复改名。`
    );
  }

  const j = r.j;
  if (!j) {
    throw new SkillError(
      'RENAME_UNKNOWN',
      `改名返回非 JSON（HTTP ${r.http}）：${r.text || ''}。结果未知，请用 list 复核。`
    );
  }

  const info = Array.isArray(j.info) ? j.info : [];
  const first = info[0] || {};

  if (j.errno !== 0 || Number(first.errno) !== 0) {
    const errno = Number(first.errno || j.errno);
    const e = explain(errno, j);
    // -8 / 同名冲突在 rename 语境下不是“目录已存在，无需重复创建”，
    // 而是“目标名字已被占用”。通用文案会把排障方向带偏，这里单独纠正。
    if (['ALREADY_EXISTS', 'NAME_CONFLICT', 'EXISTS_OR_PARAM'].includes(e.code)) {
      throw new SkillError('RENAME_CONFLICT',
        `目标名字已被占用：该目录下已存在「${nn}」，本次未改名。可换个名字或先处理同名文件。`,
        { errno, exit: e.exit });
    }
    throw new SkillError(e.code || 'RENAME_FAILED', e.text || `改名失败（errno ${errno}）。`);
  }

  return {
    ok: true,
    unchanged: false,
    from,
    to: first.to_path || null,
    old_name: oldName,
    new_name: nn,
    ext_changed: extChanged,
    old_ext: a.ext || null,
    new_ext: b.ext || null,
    request_id: j.request_id || null,
    note: extChanged ? '注意：文件后缀已改变，确认这是你要的结果。' : undefined,
  };
}

module.exports = { renamePath, splitExt };
