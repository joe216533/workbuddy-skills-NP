'use strict';
// 下载：xpan/file?method=filemetas&dlink=1 取直链 → 带 Cookie+UA 拉取 → 校验 SHA256
//
// 不使用 pcs.baidu.com 的 locatedownload：该接口需要开放平台 token（31326 user is not authorized），
// 纯登录态不可用。也不使用新版 /disk/home 的 sign1/sign3：页面已不再下发这些参数。
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Readable } = require('node:stream');
const { pipeline } = require('node:stream/promises');
const { SkillError, explain } = require('./utils_errors');
const { basename, dirname, normalize } = require('./storage_paths');
const log = require('./utils_logger');

const APPID = '250528';
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36';

// 取单个文件的直链信息
async function getDlink(client, fsid) {
  const fsids = encodeURIComponent(JSON.stringify([Number(fsid)]));
  const url = `https://pan.baidu.com/rest/2.0/xpan/file?method=filemetas&dlink=1&fsids=${fsids}&app_id=${APPID}`;
  const r = await client.getAbsolute(url);
  const j = r.j || {};
  if (j.errno !== 0) {
    const e = explain(j.errno, j);
    throw new SkillError(e.code, `获取下载直链失败：${e.text}`, { errno: j.errno, exit: e.exit });
  }
  const item = (j.info || [])[0];
  if (!item || !item.dlink) throw new SkillError('NO_DLINK', '接口未返回直链，可能该文件类型受限或登录态失效。');
  return { dlink: item.dlink, filename: item.filename, size: Number(item.size || 0), md5: item.md5 || null };
}

// 下载到本地目录，返回实际路径与 SHA256
async function downloadByFsid(client, fsid, outDir, { saveAs = null, expectSize = null } = {}) {
  const info = await getDlink(client, fsid);
  const name = saveAs || info.filename || `file-${fsid}`;
  const outPath = path.resolve(outDir, name);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });

  const r = await fetch(info.dlink, {
    headers: { 'User-Agent': UA, Cookie: client.cookie, Referer: 'https://pan.baidu.com/disk/main' },
  });
  if (!r.ok) throw new SkillError('DOWNLOAD_HTTP', `下载请求失败（HTTP ${r.status}）。直链过期时重试一次通常可恢复。`);

  const h = crypto.createHash('sha256');
  const fh = fs.createWriteStream(outPath);
  const src = Readable.fromWeb(r.body);
  src.on('data', (c) => h.update(c));
  await pipeline(src, fh);

  const size = fs.statSync(outPath).size;
  if (expectSize != null && expectSize > 0 && size !== expectSize) {
    throw new SkillError('SIZE_MISMATCH', `下载文件大小不符：期望 ${expectSize} 字节，实际 ${size} 字节。文件可能不完整，已保留在 ${outPath}。`);
  }
  const sha256 = h.digest('hex');
  log.info(`下载完成 ${name}（${size} 字节）sha256=${sha256.slice(0, 16)}…`);
  return { local_path: outPath, file_name: name, file_size: size, sha256, remote_size: info.size };
}

// 按网盘路径下载：先 stat 拿 fs_id
async function downloadByPath(client, remotePath, outDir) {
  const { stat } = require('./api_file-list');
  const p = normalize(remotePath);
  const item = await stat(client, p);
  if (!item) throw new SkillError('BAD_PATH', `网盘上找不到该文件：${p}`);
  if (item.isdir) throw new SkillError('IS_DIR', `这是目录，本版只支持下载单个文件：${p}`);
  return downloadByFsid(client, item.fs_id, outDir, { saveAs: basename(p), expectSize: item.size });
}

module.exports = { getDlink, downloadByFsid, downloadByPath, dirname };
