'use strict';
// 命令注册与参数校验 + 各命令实现
//
// 命令清单（顾问第 35 轮定稿）：
//   auth login --as <别名> | auth status [--as] | auth use <别名> | auth logout --as <别名>
//   list [路径] | mkdir <绝对路径> | rename <绝对路径> <新名字> | upload <本地> --to <目录> | download <路径> --to <本地目录>
//   delete <绝对路径> [--recursive] --yes | share <路径> [--period 0] [--pwd xxxx]
//   transfer <分享链接> --pwd <提取码> --to <目录> | verify [--deep] [--yes]
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const accounts = require('./auth_accounts');
const credentialStore = require('./auth_credential-store');
const { loginWithDedicatedBrowser } = require('./auth_browser-login');
const { openSession, checkSession, verifyCredential } = require('./auth_session');
const { listAll } = require('./api_file-list');
const { ensureDir } = require('./api_mkdir');
const { renamePath } = require('./api_rename');
const { uploadFile, checkSpace } = require('./api_upload');
const { downloadByPath } = require('./api_download');
const { createShare } = require('./api_share');
const { transfer } = require('./api_transfer');
const deleteGuard = require('./safety_delete-guard');
const { prepareUploadDir, checkConflict } = require('./safety_upload-guard');
const { SkillError, EXIT } = require('./utils_errors');
const { humanSize } = require('./storage_integrity');
const { normalize } = require('./storage_paths');
const out = require('./cli_output');
const log = require('./utils_logger');
const selfcheck = require('./selfcheck_hook');

const BOOL_FLAGS = new Set(['json', 'yes', 'recursive', 'deep', 'help', 'force', 'all', 'no-selfcheck']);
const VALUE_FLAGS = new Set(['as', 'to', 'pwd', 'period', 'dir', 'timeout', 'alias', 'platform']);

function parseArgs(argv) {
  const pos = [];
  const flags = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith('--')) {
      pos.push(a);
      continue;
    }
    const body = a.slice(2);
    if (body.includes('=')) {
      const idx = body.indexOf('=');
      flags[body.slice(0, idx)] = body.slice(idx + 1);
      continue;
    }
    if (BOOL_FLAGS.has(body)) flags[body] = true;
    else if (VALUE_FLAGS.has(body)) {
      const v = argv[i + 1];
      if (v === undefined || String(v).startsWith('--')) {
        throw new SkillError('USAGE', `参数 --${body} 缺少取值`, { exit: EXIT.USAGE });
      }
      flags[body] = v;
      i++;
    } else {
      throw new SkillError('USAGE', `未知参数：--${body}`, { exit: EXIT.USAGE });
    }
  }
  return { pos, flags };
}

// ---------- auth ----------
async function cmdAuthLogin(pos, flags) {
  const alias = accounts.assertAlias(flags.as || flags.alias);
  log.step(`开始授权账号：${alias}`);

  const picked = await loginWithDedicatedBrowser({
    timeoutMs: Number(flags.timeout || 10) * 60 * 1000,
    onNotice: (m) => log.info(m),
  });

  const cred = { bduss: picked.bduss, stoken: picked.stoken };
  const verified = await verifyCredential(cred);
  const saved = credentialStore.save(alias, { ...cred, savedAt: new Date().toISOString() });
  const rec = accounts.register(alias, {
    store: saved.store,
    lastVerifiedAt: new Date().toISOString(),
  });

  return {
    account_alias: alias,
    login_status: 'logged_in',
    authorization_status: 'valid',
    credential_store: saved.store,
    credential_path: saved.file,
    cookie_fields: 'BDUSS + STOKEN',
    uk: verified.uk,
    quota_total: verified.quota ? humanSize(verified.quota.total) : null,
    quota_used: verified.quota ? humanSize(verified.quota.used) : null,
    is_current: accounts.getCurrent() === alias,
    created_at: rec.createdAt,
    last_verified_at: rec.lastVerifiedAt,
    note: '凭据已加密保存在本机，不能复制到其他电脑使用；换机请重新授权。',
  };
}

async function cmdAuthStatus(pos, flags) {
  const alias = flags.as || flags.alias || accounts.getCurrent();
  if (!alias) {
    const l = accounts.list();
    return {
      account_alias: null,
      login_status: 'no_account',
      authorization_status: 'none',
      detail: '本机还没有授权任何账号。请执行：auth login --as <别名>',
      accounts: l.accounts,
    };
  }
  const st = await checkSession(alias);
  return {
    account_alias: alias,
    login_status: st.login_status,
    authorization_status: st.authorization_status,
    credential_store: credentialStore.exists(alias) ? credentialStore.storeKind() : 'none',
    last_verified_at: st.checked_at,
    is_current: accounts.getCurrent() === alias,
    quota_total: st.quota ? humanSize(st.quota.total_bytes) : null,
    quota_used: st.quota ? humanSize(st.quota.used_bytes) : null,
    quota_free: st.quota ? humanSize(st.quota.free_bytes) : null,
    error: st.error || undefined,
  };
}

function cmdAuthUse(pos) {
  const alias = accounts.assertAlias(pos[0]);
  accounts.setCurrent(alias);
  return { current_account: alias, switched: true, note: '后续未显式指定 --as 的命令都会使用这个账号。' };
}

function cmdAuthLogout(pos, flags) {
  const alias = accounts.assertAlias(flags.as || flags.alias || accounts.getCurrent());
  const removed = credentialStore.remove(alias);
  const existed = accounts.unregister(alias);
  return {
    account_alias: alias,
    logout_status: removed || existed ? 'done' : 'not_found',
    credential_removed: removed,
    record_removed: existed,
    current_account: accounts.getCurrent() || '(无)',
    note: '只清除了本机这个账号的授权，网盘上的文件和别的账号都不受影响。',
  };
}

function cmdAuthList() {
  const l = accounts.list();
  return {
    current_account: l.current || '(无)',
    account_count: l.accounts.length,
    accounts: l.accounts.map((a) => ({
      alias: a.alias,
      is_current: a.is_current,
      store: a.store,
      created_at: a.createdAt,
      last_verified_at: a.lastVerifiedAt,
    })),
  };
}

// ---------- 文件与目录 ----------
async function cmdList(pos, flags) {
  const client = await openSession({ as: flags.as });
  const dir = pos[0] ? normalize(pos[0]) : '/';
  const items = await listAll(client, dir);
  const q = await client.quota();
  return {
    account_alias: client.alias,
    dir,
    item_count: items.length,
    items: items.map((x) => ({
      name: x.name,
      type: x.isdir ? 'dir' : 'file',
      size: x.size,
      size_human: x.isdir ? '-' : humanSize(x.size),
      mtime: x.mtime ? new Date(x.mtime * 1000).toISOString() : null,
      fs_id: x.fs_id,
    })),
    quota_total: q && q.errno === 0 ? humanSize(Number(q.total || 0)) : null,
    quota_used: q && q.errno === 0 ? humanSize(Number(q.used || 0)) : null,
    quota_free: q && q.errno === 0 ? humanSize(Number(q.total || 0) - Number(q.used || 0)) : null,
  };
}

async function cmdMkdir(pos, flags) {
  if (!pos[0]) throw new SkillError('USAGE', '用法：mkdir <网盘绝对路径> [--as 别名]', { exit: EXIT.USAGE });
  const client = await openSession({ as: flags.as });
  const dir = normalize(pos[0]);
  const r = await ensureDir(client, dir);
  if (!r.ok) throw new SkillError('MKDIR_FAILED', `创建目录失败于 ${r.path}（errno ${r.errno}）`);
  return {
    account_alias: client.alias,
    dir,
    mkdir_status: 'success',
    created_all: r.steps.every((s) => s.created || s.existed),
    path_count: r.steps.length,
  };
}

async function cmdRename(pos, flags) {
  if (!pos[0] || !pos[1]) {
    throw new SkillError(
      'USAGE',
      '用法：rename <网盘绝对路径> <新名字> [--as 别名]\n' +
        '示例：rename "/来自：WorkBuddy/x/a.txt" "b.txt"\n' +
        '说明：只改当前这一层的名字，新名字不能带路径分隔符；不自动覆盖已存在的同名文件。',
      { exit: EXIT.USAGE }
    );
  }
  const client = await openSession({ as: flags.as });
  const r = await renamePath(client, pos[0], pos[1]);
  return {
    account_alias: client.alias,
    from: r.from,
    to: r.to,
    old_name: r.old_name,
    new_name: r.new_name,
    rename_status: r.unchanged ? 'unchanged' : 'success',
    ext_changed: r.ext_changed,
    ...(r.note ? { note: r.note } : {}),
    request_id: r.request_id || null,
  };
}

async function cmdUpload(pos, flags) {
  const local = pos[0];
  if (!local) throw new SkillError('USAGE', '用法：upload <本地文件> --to <网盘目录> [--as 别名]', { exit: EXIT.USAGE });
  const abs = path.resolve(local);
  if (!fs.existsSync(abs)) throw new SkillError('NO_LOCAL_FILE', `本地文件不存在：${abs}`);

  const client = await openSession({ as: flags.as });
  const { dir, outside } = await prepareUploadDir(client, flags.to);

  const conflict = await checkConflict(client, dir, path.basename(abs));
  if (conflict.conflict && !flags.force) {
    throw new SkillError(
      'NAME_CONFLICT',
      `目标已存在同名文件：${conflict.path}（${humanSize(conflict.size)}）。为避免覆盖，本次没有上传。请改名、先删除旧文件，或显式加 --force 覆盖。`,
      { exit: EXIT.GENERAL, existing_fs_id: conflict.fs_id }
    );
  }

  const r = await uploadFile(client, abs, dir);
  return {
    account_alias: client.alias,
    local_path: abs,
    remote_path: r.remote_path,
    remote_file_id: r.fs_id,
    file_name: r.file_name,
    file_size: r.file_size,
    file_size_human: humanSize(r.file_size),
    upload_status: 'success',
    upload_method: r.upload_method,
    part_count: r.part_count,
    sha256: r.sha256,
    target_outside_skill_dir: outside || undefined,
  };
}

async function cmdDownload(pos, flags) {
  const remote = pos[0];
  if (!remote) throw new SkillError('USAGE', '用法：download <网盘路径> --to <本地目录> [--as 别名]', { exit: EXIT.USAGE });
  const client = await openSession({ as: flags.as });
  const toDir = path.resolve(flags.to || path.join(os.homedir(), 'Downloads'));
  const r = await downloadByPath(client, remote, toDir);
  return {
    account_alias: client.alias,
    remote_path: normalize(remote),
    local_path: r.local_path,
    file_name: r.file_name,
    file_size: r.file_size,
    file_size_human: humanSize(r.file_size),
    download_status: 'success',
    sha256: r.sha256,
  };
}

async function cmdDelete(pos, flags) {
  if (!pos[0]) {
    throw new SkillError(
      'USAGE',
      '用法：delete <网盘绝对路径> [--recursive] --yes [--as 别名]\n' +
        '安全说明：只允许删除技能目录 /来自：WorkBuddy/baidu-baidunetdisk 下的内容，不支持通配符，必须是绝对路径。',
      { exit: EXIT.USAGE }
    );
  }
  const client = await openSession({ as: flags.as });

  // 顾问要求：删除必须在执行前明确显示 当前账号 / 操作 / 目标路径
  if (!flags.json) {
    process.stdout.write(`current_account              : ${client.alias}\n`);
    process.stdout.write(`operation                    : delete\n`);
    process.stdout.write(`target_path                  : ${pos[0]}\n`);
    process.stdout.write('--- 预览（将被删除的内容） ---\n');
  }

  const preview = await deleteGuard.previewDelete(client, pos[0], { recursive: Boolean(flags.recursive) });

  if (!flags.json) {
    process.stdout.write(`target_type                  : ${preview.target_type}\n`);
    process.stdout.write(`target_file_id               : ${preview.target_file_id}\n`);
    process.stdout.write(`target_size                  : ${humanSize(preview.target_size)}\n`);
    process.stdout.write(`recursive                    : ${preview.recursive}\n`);
    process.stdout.write(`preview_item_count           : ${preview.preview_item_count}\n`);
    process.stdout.write(`preview_total_size           : ${humanSize(preview.preview_total_size)}\n`);
    if (preview.children.length) {
      process.stdout.write('将删除的文件：\n');
      for (const c of preview.children.slice(0, 50)) {
        process.stdout.write(`  - ${c.path}  (${humanSize(c.size)})\n`);
      }
      if (preview.children.length > 50) {
        process.stdout.write(`  … 另有 ${preview.children.length - 50} 个文件未列出\n`);
      }
    }
    process.stdout.write('--- 预览结束 ---\n');
  }

  const result = await deleteGuard.executeDelete(client, preview, { yes: Boolean(flags.yes) });
  return {
    ...result,
    account_alias: client.alias,
    preview_children: undefined,
  };
}

// ---------- 分享与转存 ----------
async function cmdShare(pos, flags) {
  const target = pos[0];
  if (!target) throw new SkillError('USAGE', '用法：share <网盘路径> [--period 0] [--pwd xxxx] [--as 别名]', { exit: EXIT.USAGE });
  const client = await openSession({ as: flags.as });
  const period = flags.period != null ? Number(flags.period) : 0;
  if (![0, 1, 7].includes(period)) {
    throw new SkillError('BAD_PERIOD', '有效期只支持 0（永久）、1（1 天）、7（7 天）', { exit: EXIT.USAGE });
  }
  const r = await createShare(client, [target], { pwd: flags.pwd, period });
  return {
    account_alias: client.alias,
    file_name: normalize(target),
    share_id: r.share_id,
    short_url: r.short_url,
    full_url: r.full_url,
    password: r.password,
    period: r.period,
    period_text: r.period_text,
    expired_type: r.expired_type,
    expire_time: r.expire_time,
    share_status: r.share_status,
    note: '链接带 ?pwd= 时，别人在浏览器打开会自动填好提取码。',
  };
}

async function cmdTransfer(pos, flags) {
  const url = pos[0];
  if (!url) throw new SkillError('USAGE', '用法：transfer <分享链接> --pwd <提取码> --to <目录> [--as 别名]', { exit: EXIT.USAGE });
  const client = await openSession({ as: flags.as });
  const { dir } = await prepareUploadDir(client, flags.to);
  const r = await transfer(client, url, dir, flags.pwd);
  return {
    account_alias: client.alias,
    source_share_url: r.source_share_url,
    source_file_name: r.source_file_name,
    source_file_count: r.source_file_count,
    target_path: r.target_path,
    target_file_path: r.target_file_path,
    target_file_id: r.target_file_id,
    renamed: r.renamed || undefined,
    transfer_status: r.transfer_status,
    note: r.renamed ? '目标目录已有同名文件，服务端自动改名保存（见 target_file_path）。' : undefined,
  };
}

// ---------- 验证 ----------
async function cmdVerify(pos, flags) {
  const { runBasic } = require('./verify_basic');
  const { runDeep } = require('./verify_deep');
  if (flags.deep) return runDeep({ as: flags.as, yes: Boolean(flags.yes) });
  return runBasic({ as: flags.as });
}

// 自检：直接透传自检模块的 stdio 与退出码，不经 out.print，
// 因为它有自己的输出格式（六步报告）与退出码语义（0/4/5）。
// 自检子命令：把 --force / --platform / --json 如实透传给自检入口。
// 早期实现把参数写死成 ['run','--platform','baidu']，--force 在这里被丢掉，
// 导致 selfcheck --force 实际走普通 run → 命中当天去重 → 返回 DONE_TODAY 且退出码 0，
// 即“没真跑却报成功”。这类假阳性比报错更危险，必须透传。
const SELFCHECK_SUBCMDS = new Set(['run', 'force', 'status', 'history', 'init', 'version']);
const SELFCHECK_READONLY = new Set(['status', 'history', 'version']);

function cmdSelfcheck(pos, flags) {
  const { spawnSync } = require('node:child_process');
  const runner = path.join(__dirname, 'selfcheck_index.js');
  const sub = pos[0];
  const argv = sub && SELFCHECK_SUBCMDS.has(sub)
    ? [sub]
    : ['run'];

  // status/history/version 不跑转存，不需要平台与 force
  if (!SELFCHECK_READONLY.has(argv[0])) {
    argv.push('--platform', String(flags.platform || 'baidu'));
  }
  if (flags.force && argv[0] !== 'force') argv.push('--force');
  if (flags.json) argv.push('--json');

  const r = spawnSync(process.execPath, [runner, ...argv], {
    env: Object.assign({}, process.env, { WB_SELFCHECK_RUNNING: '1' }),
    stdio: 'inherit',
    timeout: 90000,
  });
  if (r.error && r.error.code === 'ETIMEDOUT') {
    process.stderr.write('[自检] 执行超时\n');
    return EXIT.GENERAL;
  }
  return r.status == null ? EXIT.GENERAL : r.status;
}

const COMMANDS = {
  'auth login': cmdAuthLogin,
  'auth status': cmdAuthStatus,
  'auth use': cmdAuthUse,
  'auth logout': cmdAuthLogout,
  'auth list': cmdAuthList,
  list: cmdList,
  mkdir: cmdMkdir,
  rename: cmdRename,
  upload: cmdUpload,
  download: cmdDownload,
  delete: cmdDelete,
  share: cmdShare,
  transfer: cmdTransfer,
  verify: cmdVerify,
};

const HELP = `百度网盘操作技能（baidu-baidunetdisk）

用法：node scripts/baidu-baidunetdisk.cjs <命令> [参数]

授权与账号
  auth login --as <别名>          打开专用浏览器授权（窗口可见，只让该浏览器走国内直连）
  auth status [--as <别名>]       查询授权状态
  auth use <别名>                 切换当前默认账号
  auth logout --as <别名>         清除指定账号的本机授权（不影响其他账号）
  auth list                       列出本机已授权账号

文件与目录
  list [路径] [--as 别名]                       列出目录
  mkdir <绝对路径> [--as 别名]                   创建目录
  rename <绝对路径> <新名字> [--as 别名]          重命名（只改当前层名字，不移动）
  upload <本地文件> --to <网盘目录> [--as 别名]   上传文件
  download <网盘路径> --to <本地目录> [--as 别名] 下载文件
  delete <绝对路径> [--recursive] --yes [--as 别名]  删除（详见下方安全限制）

分享与转存
  share <网盘路径> [--period 0] [--pwd xxxx] [--as 别名]   创建分享（period 0=永久）
  transfer <分享链接> --pwd <提取码> --to <目录> [--as 别名]  转存他人分享

验证
  verify [--as 别名]              普通只读检查，不产生任何文件
  verify --deep --yes [--as 别名] 端到端测试（上传/分享/下载/删除），使用专用目录并验证清理
  selfcheck [--force] [--json]    技能启动自检：真实转存 1KB 文件并核验本次云端结果
  selfcheck status|history        查看当天状态与历史记录
  selfcheck --platform all        两个平台一起自检（本包只自带百度，夸克会判 NEEDS_CONFIG）

自检说明
  - 默认在每天第一次调用业务命令前自动执行；当天 PASS 后本日不再重复
  - 测试分享链接、提取码、文件名与大小随包内置，不需要换机后重新填写
  - 未授权标记 NEEDS_AUTH；平台限制标记 BLOCKED；失败不静默跳过
  - 自检失败只提示，不改变本次业务命令的行为与退出码

删除安全限制（硬规则，无绕过开关）
  - 只接受网盘绝对路径，禁止通配符 * ? [ ] { }
  - 只允许删除 /来自：WorkBuddy/baidu-baidunetdisk 下的内容，不允许删该目录本身
  - 非空目录必须加 --recursive
  - 必须显式加 --yes
  - 执行前会列预览清单（含 fs_id），执行后复查确认已消失

通用参数
  --json     输出结构化 JSON
  --help     显示本帮助
`;

async function run(argv) {
  const { pos, flags } = parseArgs(argv);
  if (flags.help || pos.length === 0 || pos[0] === 'help') {
    process.stdout.write(HELP);
    return EXIT.OK;
  }

  const sub = pos[0] === 'auth' ? `auth ${pos[1] || ''}`.trim() : pos[0];
  if (sub === 'selfcheck') return cmdSelfcheck(pos.slice(1), flags);

  // 自检前置：每天第一次调用时自动执行一次真实转存。
  // 只在未通过时输出一行提示，不改变本次命令的行为与退出码。
  try {
    const msg = selfcheck.notice(selfcheck.maybeRun(sub, flags));
    if (msg) process.stderr.write(msg);
  } catch {
    /* 自检模块自身异常绝不影响业务命令 */
  }

  const fn = COMMANDS[sub];
  if (!fn) {
    process.stdout.write(`未知命令：${sub}\n\n${HELP}`);
    return EXIT.USAGE;
  }

  const args = pos[0] === 'auth' ? pos.slice(2) : pos.slice(1);
  const started = Date.now();
  try {
    const result = await fn(args, flags);
    result.elapsed_ms = Date.now() - started;
    out.print(result, { json: Boolean(flags.json) });
    return EXIT.OK;
  } catch (e) {
    const code = e.code || 'ERROR';
    const text = e.text || e.message || String(e);
    out.printError(code, text, { errno: e.errno, account_alias: flags.as || accounts.getCurrent() }, { json: Boolean(flags.json) });
    log.error(`${code}: ${text}`);
    return e.exit != null ? e.exit : EXIT.GENERAL;
  }
}

module.exports = { run, parseArgs, COMMANDS, HELP, EXIT };
