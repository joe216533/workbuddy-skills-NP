'use strict';
// 技能启动自检 —— 每天首次调用时执行一次真实转存，并核验本次云端保存结果。
// 用法：
//   node index.js run [--platform quark|baidu|all] [--json]
//   node index.js force [--platform ...] [--json]
//   node index.js status|history|init|version
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const C = require('./selfcheck_common.js');
const { quark, baidu } = require('./selfcheck_adapters.js');

const ADAPTERS = { quark, baidu };
const DEFAULT_CFG = path.join(__dirname, 'selfcheck_config.default.json');
const PRIVATE_CFG = path.join(C.ROOT, 'config.json');

function readVersion(p) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')).version || null; } catch { return null; }
}
const AGENT_VERSION =
  readVersion(path.join(__dirname, 'selfcheck_agent-manifest.json')) ||
  readVersion(path.join(C.ROOT, 'manifest.json')) ||
  '0.0.0';
const SKILL_VERSION = readVersion(path.join(__dirname, '..', 'manifest.json')) || 'unknown';

function loadConfig() {
  const loaded = C.loadMergedConfig(DEFAULT_CFG, PRIVATE_CFG);
  if (!loaded.ok) throw new Error(`${C.E.CONFIG_MISSING}: 找不到包内默认配置 ${DEFAULT_CFG}`);
  return loaded;
}

function pickPlatforms(merged, want) {
  const source = merged.providers || merged.platforms || {};
  const keys = want && want !== 'all' ? [want] : Object.keys(source);
  return keys
    .filter((k) => ADAPTERS[k])
    .map((k) => ({ id: k, cfg: C.resolvePlatformConfig(merged, k, __dirname) }));
}

const STEP_NAMES = ['本地状态', '保存方账号', '测试分享源', '真实云端保存', '云端结果核验', '文件整理与记录'];

function blankSteps() {
  return STEP_NAMES.map((name, i) => ({ n: i + 1, name, status: C.STATUS.NOT_RUN }));
}

function setStep(steps, n, status, extra = {}) {
  const i = steps.findIndex((s) => s.n === n);
  if (i >= 0) steps[i] = { ...steps[i], status, ...extra };
}

function selfCheck(merged, platformId, pc) {
  const ad = ADAPTERS[platformId];
  const steps = blankSteps();
  const t0 = Date.now();
  const runId = C.executionId(platformId);
  const resourceVersion = pc.resource_version;

  function finish(status, errorCode, extra = {}) {
    const result = {
      platform: platformId,
      label: ad.label,
      status,
      kind: C.statusToKind(status),
      errorCode: errorCode || null,
      hint: errorCode ? (C.HINT[errorCode] || '') : '',
      steps,
      executionId: runId,
      resourceVersion,
      account: extra.saver ? {
        alias: extra.saver.nickname || pc.saver_alias || null,
        nickname: extra.saver.nickname,
        free: extra.saver.free,
        total: extra.saver.total,
        used: extra.saver.used,
        spaceStatus: extra.space?.status || 'UNKNOWN',
      } : null,
      spaceWarning: extra.space ? extra.space.level === 'warn' : false,
      save: extra.save || null,
      verified: extra.vr || null,
      elapsedMs: Date.now() - t0,
      rawTail: extra.raw || undefined,
    };
    return result;
  }

  // ① 本地技能状态
  const local = ad.checkLocal(pc);
  setStep(steps, 1, local.ok ? C.STATUS.PASS : C.statusForError(local.error), {
    ok: Boolean(local.ok),
    error: local.error || undefined,
    detail: local.ok ? '命令行脚本可用' : undefined,
  });
  if (!local.ok) return finish(C.statusForError(local.error), local.error);

  // ② 保存方账号 + 容量
  const saver = ad.checkSaver(pc);
  if (!saver.ok) {
    const status = saver.status || C.statusForError(saver.error);
    setStep(steps, 2, status, { ok: false, error: saver.error, raw: saver.raw });
    return finish(status, saver.error, { raw: saver.raw });
  }
  const th = merged.thresholds || {};
  const space = C.classifySpace(saver.free, th);
  setStep(steps, 2, C.STATUS.PASS, {
    ok: true,
    detail: `${saver.nickname || pc.saver_alias || '当前账号'} · 剩余 ${C.humanSize(saver.free)} · ${space.status}`,
    space,
  });
  if (space.level === 'deny') {
    return finish(C.STATUS.FAIL, C.E.SPACE_INSUFFICIENT, { saver, space });
  }

  // ③ 测试分享源
  const link = ad.checkLink(pc);
  if (!link.ok) {
    setStep(steps, 3, C.STATUS.FAIL, { ok: false, error: link.error, raw: link.raw });
    return finish(C.STATUS.FAIL, link.error, { saver, space, raw: link.raw });
  }
  setStep(steps, 3, link.notRun ? C.STATUS.NOT_RUN : C.STATUS.PASS, {
    ok: !link.notRun,
    detail: link.notRun
      ? (link.reason || '本步骤不适用，由真实保存步骤判定')
      : `${link.expired_type === 1 ? '永久有效' : `有效期 ${link.expired_type}`} · ${link.file_num || 1} 个文件`,
  });

  // ④ 真实云端保存
  const save = ad.doSave(pc);
  if (!save.ok) {
    const status = save.status || C.statusForError(save.error);
    setStep(steps, 4, status, { ok: false, error: save.error, raw: save.raw });
    return finish(status, save.error, { saver, space, raw: save.raw });
  }
  setStep(steps, 4, C.STATUS.PASS, {
    ok: true,
    detail: `${((Date.now() - t0) / 1000).toFixed(1)}s`,
    savePath: save.savePath,
  });

  // ⑤ 云端结果核验：必须核验本次执行产生的文件，不能只看历史同名文件
  const vr = ad.verifyResult(pc, save);
  if (!vr.ok) {
    setStep(steps, 5, C.STATUS.FAIL, { ok: false, error: vr.error, reason: vr.reason });
    return finish(C.STATUS.FAIL, vr.error, { saver, space, save, raw: vr.reason });
  }
  setStep(steps, 5, C.STATUS.PASS, {
    ok: true,
    detail: `${vr.filename} · ${C.humanSize(vr.size)} · ${C.humanSize(vr.size) === C.humanSize(pc.expected_size) ? '大小符合预期' : '大小需关注'}`,
    fileId: vr.fid,
  });

  // ⑥ 整理与记录：改名失败不改变保存能力 PASS
  const rn = merged.keep_rename || {};
  if (rn.enabled && ad.renameSaved) {
    const dateStamp = (merged.__today || '').replace(/-/g, '');
    const target = String(rn.pattern || '可删除_{date}_自检副本')
      .replace('{date}', dateStamp) + '.txt';
    const rr = ad.renameSaved(pc, { ...vr, savePath: save.savePath }, target);
    // 归档改名属“后置整理”，失败不否定“真实保存 + 云端核验”的结论；
    // 但状态必须如实标 WARN（步骤级，不参与整体 PASS/FAIL 判定），
    // 不能一边写 PASS 一边在 detail 里报失败，否则读日志的人会以为自检自相矛盾。
    if (rr.ok) {
      setStep(steps, 6, C.STATUS.PASS, {
        ok: true,
        detail: rr.unchanged
          ? '无需改名'
          : `→ ${path.posix.basename(String(rr.to || rr.renamedTo || ''))}`,
      });
    } else {
      setStep(steps, 6, 'WARN', {
        ok: false,
        error: rr.error,
        detail: `未改名：${rr.reason || rr.error}（不影响保存与核验结论）`,
      });
    }
  } else {
    setStep(steps, 6, C.STATUS.NOT_RUN, { ok: false, detail: '文件整理未启用' });
  }

  return finish(C.STATUS.PASS, null, { saver, space, save, vr });
}

function printResult(r, opts = {}) {
  if (opts.json) return;
  const nick = r.account?.nickname ? ` · ${r.account.nickname}` : '';
  console.log(`\n[自检] ${r.label}${nick}`);
  for (const s of r.steps || []) {
    const extra = s.detail ? `  ${s.detail}` : '';
    const err = s.error ? `  [${s.error}]` : '';
    console.log(`  ${s.n} ${s.name.padEnd(12, ' ')} ${String(s.status).padEnd(11, ' ')}${extra}${err}`);
  }
  const head = r.status === C.STATUS.PASS
    ? '结论：PASS · 真实云端保存已核验'
    : `结论：${r.status}${r.errorCode ? ` · ${r.errorCode}` : ''}`;
  console.log(`  ${head}`);
  if (r.precheckFailed) console.log('  说明：本轮在「当天去重」之前就拦下了——历史 PASS 不代表当前环境仍可用');
  if (r.stateNotWritten) console.log(`  注意：${r.stateNotWritten}`);
  if (r.hint) console.log(`  提示：${r.hint}`);
  if (r.spaceWarning && r.status === C.STATUS.PASS) console.log('  注意：保存方空间偏低，建议关注');
}

// ① 本地环境有效性预检（不联网）——必须先于「当天已 PASS」去重。
// 去重只看历史状态文件，无法发现 CLI 被删、路径被改、包被搬走；
// 若先判去重，就会出现「环境已经坏了，却仍返回 DONE_TODAY + 退出码 0」。
// 这里只查「最终解析出来的有效 CLI」（含私有配置覆盖的结果），不做任何网络请求。
function localPrecheck(platformId, pc) {
  const ad = ADAPTERS[platformId];
  const local = ad.checkLocal(pc);
  if (local.ok) return null;

  const status = C.statusForError(local.error);
  const steps = blankSteps();
  setStep(steps, 1, status, {
    ok: false,
    error: local.error,
    detail: `有效 CLI 不可用：${pc.saver_cli || '(未解析到路径)'}`,
  });
  return {
    platform: platformId,
    label: ad.label,
    status,
    kind: C.statusToKind(status),
    errorCode: local.error,
    hint: C.HINT[local.error] || '',
    steps,
    executionId: C.executionId(platformId),
    resourceVersion: pc.resource_version,
    account: null,
    elapsedMs: 0,
    precheckFailed: true,
  };
}

function persistResult(id, today, tz, pc, r) {
  const rec = {
    date: today,
    checkedAt: C.nowISO(tz),
    executionId: r.executionId,
    agentVersion: AGENT_VERSION,
    skillVersion: SKILL_VERSION,
    status: r.status,
    kind: r.kind,
    errorCode: r.errorCode,
    account: r.account?.alias || pc.saver_alias || null,
    spaceStatus: r.account?.spaceStatus || 'UNKNOWN',
    resourceVersion: r.resourceVersion,
    elapsedMs: r.elapsedMs,
    hint: r.hint,
  };
  C.writeState(id, rec);
  C.appendHistory(id, { ...rec, rawTail: r.rawTail, steps: r.steps });
  return rec;
}

function cmdRun(argv) {
  const opts = parseArgs(argv);
  const loaded = loadConfig();
  const merged = loaded.cfg;
  const tz = merged.timezone || 'Asia/Shanghai';
  const today = C.todayStamp(tz);
  merged.__today = today;
  const targets = pickPlatforms(merged, opts.platform);
  const out = [];

  for (const { id, cfg: pc } of targets) {
    const st = C.readState(id);

    // ① 本地环境有效性预检：先于当天去重。
    // 环境细节（CLI 被删/被搬）不是「今天已经验过的业务事实」，不能被历史 PASS 吞掉。
    const pre = localPrecheck(id, pc);
    if (pre) {
      // 与正常流程一致地拿锁，避免覆盖另一个正在运行的自检写入的状态
      const preLock = C.acquireLock(id);
      if (preLock) {
        try { persistResult(id, today, tz, pc, pre); } finally { preLock.release(); }
      } else {
        pre.stateNotWritten = '另一个自检正在运行，本次未写入状态';
      }
      out.push(pre);
      if (!opts.json) printResult(pre, opts);
      continue;
    }

    // ② 每日去重只锁定 PASS；NEEDS_AUTH / BLOCKED / FAIL / ERROR 均允许条件变化后重试
    if (!opts.force && st && st.date === today && st.status === C.STATUS.PASS) {
      out.push({ platform: id, status: 'DONE_TODAY', state: st });
      if (!opts.json && !opts.quiet) {
        console.log(`\n[自检] ${ADAPTERS[id].label} · 今日已完成（${st.checkedAt}），本轮不再重复执行`);
      }
      continue;
    }

    const lock = C.acquireLock(id);
    if (!lock) {
      out.push({ platform: id, status: C.STATUS.NOT_RUN, reason: '另一个自检正在运行' });
      if (!opts.json && !opts.quiet) console.log(`\n[自检] ${ADAPTERS[id].label} · 另一个自检正在运行，本轮 NOT_RUN`);
      continue;
    }

    let r;
    try {
      r = selfCheck(merged, id, pc);
    } catch (e) {
      r = {
        platform: id, label: ADAPTERS[id].label,
        status: C.STATUS.ERROR, kind: C.KIND.SUSPECT_SKILL,
        errorCode: C.E.UNKNOWN_ERROR, hint: '自检执行异常：' + e.message,
        steps: blankSteps(), executionId: C.executionId(id),
      };
    } finally {
      lock.release();
    }

    const rec = persistResult(id, today, tz, pc, r);

    out.push(r);
    if (!opts.json) printResult(r, opts);
  }

  if (opts.json) console.log(JSON.stringify(out, null, 2));
  const bad = out.filter((x) => x.status && ![C.STATUS.PASS, 'DONE_TODAY'].includes(x.status));
  return bad.length === 0 ? 0 : 4;
}

function cmdStatus(argv) {
  const opts = parseArgs(argv);
  const loaded = loadConfig();
  const merged = loaded.cfg;
  const today = C.todayStamp(merged.timezone || 'Asia/Shanghai');
  const rows = Object.keys(merged.providers || merged.platforms || {})
    .filter((id) => ADAPTERS[id])
    .map((id) => ({ platform: id, label: ADAPTERS[id].label, today, state: C.readState(id) }));
  if (opts.json) { console.log(JSON.stringify(rows, null, 2)); return 0; }
  console.log(`\n自检状态（今天 ${today}）`);
  for (const r of rows) {
    if (!r.state) { console.log(`  ${r.label.padEnd(6)} 尚未自检`); continue; }
    const okToday = r.state.date === today;
    const tag = r.state.status || r.state.errorCode || 'UNKNOWN';
    console.log(`  ${r.label.padEnd(6)} ${okToday ? '今天已做' : '今天未做'} · 最近 ${r.state.date} ${r.state.checkedAt?.slice(11, 19)} · ${tag}`);
  }
  return 0;
}

function cmdHistory(argv) {
  const opts = parseArgs(argv);
  const loaded = loadConfig();
  const merged = loaded.cfg;
  const limit = Number(opts.limit || 20);
  for (const id of Object.keys(merged.providers || merged.platforms || {})) {
    if (!ADAPTERS[id]) continue;
    if (opts.platform && opts.platform !== 'all' && opts.platform !== id) continue;
    const h = C.readHistory(id, limit);
    console.log(`\n${ADAPTERS[id].label} · 最近 ${h.length} 次`);
    if (!h.length) { console.log('  （无记录）'); continue; }
    for (const x of h.slice(-limit)) {
      const tag = x.status || x.errorCode || 'UNKNOWN';
      console.log(`  ${x.date} ${x.checkedAt?.slice(11, 19) || ''}  ${tag}  ${x.spaceStatus || ''}  ${x.elapsedMs || ''}ms`);
    }
  }
  return 0;
}

function cmdInit() {
  const loaded = loadConfig();
  const merged = loaded.cfg;
  console.log('\n自检配置检查');
  console.log(`  包内默认配置：${DEFAULT_CFG}`);
  console.log(`  本机私有配置：${PRIVATE_CFG}${loaded.hasPrivate ? '（已加载）' : '（未创建；使用包内默认测试资源）'}`);
  console.log(`  时区：${merged.timezone || 'Asia/Shanghai'}`);
  console.log(`  测试资源版本：${merged.self_check?.resource_version || 'v1'}`);
  for (const id of Object.keys(merged.providers || {})) {
    const pc = C.resolvePlatformConfig(merged, id, __dirname);
    const ad = ADAPTERS[id];
    const localOk = ad ? ad.checkLocal(pc).ok : false;
    console.log(`  ${(ad?.label || id).padEnd(6)} 脚本 ${localOk ? 'PASS' : 'MISSING'} · 分享 ${pc.share_url}`);
  }
  return 0;
}

function parseArgs(argv) {
  const o = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--json') o.json = true;
    else if (a === '--quiet') o.quiet = true;
    else if (a === '--force') o.force = true;
    else if (a === '--platform') o.platform = argv[++i];
    else if (a === '--limit') o.limit = argv[++i];
  }
  return o;
}

const cmd = process.argv[2] || 'run';
const rest = process.argv.slice(3);
let code = 0;
try {
  if (cmd === 'run') code = cmdRun(rest);
  else if (cmd === 'force') code = cmdRun(['--force', ...rest]);
  else if (cmd === 'status') code = cmdStatus(rest);
  else if (cmd === 'history') code = cmdHistory(rest);
  else if (cmd === 'init') code = cmdInit();
  else if (cmd === 'version' || cmd === '--version' || cmd === '-v') {
    console.log(`workbuddy-selfcheck v${AGENT_VERSION}`);
    code = 0;
  } else {
    console.log('用法：node index.js <run|force|status|history|init|version> [--platform quark|baidu|all] [--json]');
    code = 1;
  }
} catch (e) {
  console.error('自检失败：' + e.message);
  code = 5;
}
process.exit(code);
