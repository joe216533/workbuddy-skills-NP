'use strict';
// 普通验证：只读，不产生任何文件。未执行的项目一律输出 SKIP，绝不假报 PASS。
const fs = require('node:fs');
const path = require('node:path');
const accounts = require('./auth_accounts');
const credentialStore = require('./auth_credential-store');
const { openSession } = require('./auth_session');
const { listAll } = require('./api_file-list');
const { nodeMajor } = require('./utils_platform');
const { SKILL_ROOT, VERIFY_DIR } = require('./storage_paths');
const { humanSize } = require('./storage_integrity');

const ROOT = path.resolve(__dirname, '..');

// 必备文件清单：换电脑复现时按这个清单逐项核对，不用猜结构
const REQUIRED = [
  'SKILL.md',
  'manifest.json',
  'README.md',
  'LICENSE',
  'scripts/baidu-baidunetdisk.cjs',
  'scripts/install.js',
  'scripts/verify.js',
  'scripts/preflight.js',
  'src/cli_commands.js',
  'src/cli_output.js',
  'src/auth_browser-login.js',
  'src/auth_credential-store.js',
  'src/auth_accounts.js',
  'src/auth_session.js',
  'src/api_client.js',
  'src/api_signing.js',
  'src/api_file-list.js',
  'src/api_mkdir.js',
  'src/api_upload.js',
  'src/api_share.js',
  'src/api_transfer.js',
  'src/api_download.js',
  'src/api_delete.js',
  'src/api_rename.js',
  'src/storage_paths.js',
  'src/storage_integrity.js',
  'src/safety_delete-guard.js',
  'src/safety_upload-guard.js',
  'src/safety_redaction.js',
  'src/selfcheck_index.js',
  'src/selfcheck_common.js',
  'src/selfcheck_adapters.js',
  'src/selfcheck_hook.js',
  'src/selfcheck_agent-manifest.json',
  'src/selfcheck_config.example.json',
  'src/verify_basic.js',
  'src/verify_deep.js',
  'src/utils_errors.js',
  'src/utils_logger.js',
  'src/utils_platform.js',
];

const MIN_NODE_MAJOR = 18;

async function runBasic({ as } = {}) {
  const r = {
    skill_version: null,
    node_version: process.version,
    module_integrity: 'UNKNOWN',
    credential_status: 'UNKNOWN',
    account_alias: null,
    credential_store: credentialStore.storeKind(),
    api_status: 'SKIP',
    list_status: 'SKIP',
    upload_status: 'SKIP',
    share_status: 'SKIP',
    download_status: 'SKIP',
    delete_status: 'SKIP',
    cleanup_status: 'SKIP',
    overall_status: 'PASS',
    checks: [],
  };

  // 1. manifest
  let manifest = null;
  try {
    manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
    r.skill_version = manifest.version || null;
    r.checks.push({ name: 'manifest_version', status: manifest.version ? 'PASS' : 'FAIL', detail: manifest.version });
  } catch (e) {
    r.checks.push({ name: 'manifest_version', status: 'FAIL', detail: e.message });
  }

  // 2. Node 版本
  const nm = nodeMajor();
  r.checks.push({
    name: 'node_version',
    status: nm >= MIN_NODE_MAJOR ? 'PASS' : 'FAIL',
    detail: `${process.version}（要求 >= v${MIN_NODE_MAJOR}）`,
  });

  // 3. 文件完整性
  const missing = [];
  const empty = [];
  for (const rel of REQUIRED) {
    const p = path.join(ROOT, rel);
    if (!fs.existsSync(p)) missing.push(rel);
    else if (fs.statSync(p).size === 0) empty.push(rel);
  }
  r.module_integrity = missing.length || empty.length ? 'FAIL' : 'PASS';
  r.checks.push({
    name: 'module_integrity',
    status: r.module_integrity,
    detail: missing.length || empty.length ? `缺失 ${missing.join(',')} 空文件 ${empty.join(',')}` : `${REQUIRED.length} 个必备文件齐全`,
  });

  // 4. 账号与凭据
  const alias = as || accounts.getCurrent();
  r.account_alias = alias || null;
  if (!alias) {
    r.credential_status = 'FAIL';
    r.checks.push({ name: 'credential', status: 'FAIL', detail: '本机还没有授权任何账号，请先 auth login --as <别名>' });
  } else if (!credentialStore.exists(alias)) {
    r.credential_status = 'FAIL';
    r.checks.push({ name: 'credential', status: 'FAIL', detail: `账号 ${alias} 没有本机凭据，请重新授权` });
  } else {
    try {
      credentialStore.load(alias);
      r.credential_status = 'PASS';
      r.checks.push({ name: 'credential', status: 'PASS', detail: `账号 ${alias} 的凭据可被当前用户解密（${r.credential_store}）` });
    } catch (e) {
      r.credential_status = 'FAIL';
      r.checks.push({ name: 'credential', status: 'FAIL', detail: e.message });
    }
  }

  // 5~6. 接口可用 + 根目录读取
  if (r.credential_status === 'PASS') {
    try {
      const client = await openSession({ as: alias });
      r.api_status = 'PASS';
      const items = await listAll(client, '/');
      r.list_status = 'PASS';
      const q = await client.quota();
      r.checks.push({ name: 'api', status: 'PASS', detail: `bdstoken 获取成功，uk 已解析` });
      r.checks.push({ name: 'list', status: 'PASS', detail: `根目录 ${items.length} 项` });
      if (q && q.errno === 0) {
        r.quota_total = humanSize(Number(q.total || 0));
        r.quota_used = humanSize(Number(q.used || 0));
        r.quota_free = humanSize(Number(q.total || 0) - Number(q.used || 0));
      }
      r.skill_root = SKILL_ROOT;
      r.verify_dir = VERIFY_DIR;
    } catch (e) {
      r.api_status = 'FAIL';
      r.list_status = 'FAIL';
      r.checks.push({ name: 'api', status: 'FAIL', detail: e.message });
    }
  }

  const failed = r.checks.filter((c) => c.status === 'FAIL');
  r.overall_status = failed.length ? 'FAIL' : 'PASS';
  r.summary = failed.length
    ? `未通过：${failed.map((c) => c.name).join('、')}`
    : '普通验证通过。上传/分享/下载/删除未执行，状态为 SKIP；需要端到端确认请用 verify --deep --yes。';
  return r;
}

module.exports = { runBasic, REQUIRED, MIN_NODE_MAJOR };
