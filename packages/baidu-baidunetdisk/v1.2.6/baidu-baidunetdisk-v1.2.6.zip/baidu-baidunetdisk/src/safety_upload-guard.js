'use strict';
// 上传落点保护：默认落到技能目录，外部目录明确告知，同名文件不静默覆盖
const paths = require('./storage_paths');
const { ensureDir } = require('./api_mkdir');
const { stat } = require('./api_file-list');
const { SkillError } = require('./utils_errors');
const log = require('./utils_logger');

const DEFAULT_UPLOAD_DIR = paths.SKILL_ROOT;

/**
 * 解析并准备上传目录
 * @returns {Promise<{dir:string, outside:boolean}>}
 */
async function prepareUploadDir(client, rawDir, { createIfMissing = true } = {}) {
  const dir = paths.assertAbsolute(rawDir || DEFAULT_UPLOAD_DIR);
  const outside = !paths.isUnder(dir, paths.SKILL_ROOT);

  if (outside) {
    log.warn(`上传目标在技能目录之外：${dir}。这是你显式指定的路径，技能不会擅自改动其他目录。`);
  }

  if (createIfMissing) {
    const r = await ensureDir(client, dir);
    if (!r.ok) {
      throw new SkillError('MKDIR_FAILED', `无法创建目标目录 ${r.path}（errno ${r.errno}），本次未上传。`, { exit: 1 });
    }
  }
  return { dir, outside };
}

// 同名冲突预检：不静默覆盖，交给调用方决定
async function checkConflict(client, remoteDir, fileName) {
  const full = paths.join(remoteDir, fileName);
  const item = await stat(client, full);
  if (!item) return { conflict: false, path: full };
  return { conflict: true, path: full, fs_id: item.fs_id, size: item.size, mtime: item.mtime };
}

module.exports = { DEFAULT_UPLOAD_DIR, prepareUploadDir, checkConflict };
