'use strict';
// 本机凭据安全存储（跨平台，各平台用各自的原生机制，绝不混用）
//
//   Windows : DPAPI CurrentUser 加密后写 %LOCALAPPDATA%\baidu-baidunetdisk\accounts\<别名>.cred
//   macOS   : 登录钥匙串（security add-generic-password），文件位置仅存引用
//   Linux   : libsecret / Secret Service（secret-tool）；不可用时降级为 0600 权限文件并明确警告
//
// 铁律：
//   - 只保存 BDUSS 与 STOKEN 两个字段，别的 cookie 一概不取
//   - 明文只在内存与 stdin 中传递，不落盘
//   - DPAPI 加密结果不能跨机器/跨系统复用，也不允许复制到其他电脑
const fs = require('node:fs');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { ensureDataDir, isWin, isMac, isLinux } = require('./utils_platform');
const { SkillError } = require('./utils_errors');
const log = require('./utils_logger');

const SERVICE = 'baidu-baidunetdisk';

function accountsDir() {
  const d = path.join(ensureDataDir(), 'accounts');
  fs.mkdirSync(d, { recursive: true, mode: 0o700 });
  return d;
}

function credFile(alias) {
  return path.join(accountsDir(), `${alias}.cred`);
}

// ---------- Windows DPAPI ----------
function dpapiProtect(plain, outFile) {
  const ps =
    `Add-Type -AssemblyName System.Security; ` +
    `$s=[Console]::In.ReadToEnd(); ` +
    `$b=[Text.Encoding]::UTF8.GetBytes($s); ` +
    `$p=[Security.Cryptography.ProtectedData]::Protect($b,$null,'CurrentUser'); ` +
    `[IO.File]::WriteAllBytes('${outFile.replace(/'/g, "''")}',$p);`;
  execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
    input: plain,
    stdio: ['pipe', 'pipe', 'pipe'],
  });
}

function dpapiUnprotect(inFile) {
  const b64 = fs.readFileSync(inFile).toString('base64');
  const ps =
    `Add-Type -AssemblyName System.Security; ` +
    `$b=[Convert]::FromBase64String('${b64}'); ` +
    `$p=[Security.Cryptography.ProtectedData]::Unprotect($b,$null,'CurrentUser'); ` +
    `[Console]::Out.Write([Text.Encoding]::UTF8.GetString($p));`;
  return execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { encoding: 'utf8' });
}

// ---------- macOS Keychain ----------
function macSave(alias, plain) {
  try {
    execFileSync('security', ['delete-generic-password', '-s', SERVICE, '-a', alias], { stdio: 'ignore' });
  } catch {
    /* 不存在则忽略 */
  }
  execFileSync(
    'security',
    ['add-generic-password', '-s', SERVICE, '-a', alias, '-w', plain, '-U'],
    { stdio: ['pipe', 'pipe', 'pipe'] }
  );
}

function macLoad(alias) {
  return execFileSync('security', ['find-generic-password', '-s', SERVICE, '-a', alias, '-w'], { encoding: 'utf8' });
}

function macDelete(alias) {
  try {
    execFileSync('security', ['delete-generic-password', '-s', SERVICE, '-a', alias], { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

// ---------- Linux Secret Service ----------
function hasSecretTool() {
  try {
    execFileSync('secret-tool', ['--version'], { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

function linSaveSecret(alias, plain) {
  execFileSync('secret-tool', ['store', '--label', `${SERVICE} ${alias}`, 'service', SERVICE, 'account', alias], {
    input: plain,
    stdio: ['pipe', 'pipe', 'pipe'],
  });
}

function linLoadSecret(alias) {
  return execFileSync('secret-tool', ['lookup', 'service', SERVICE, 'account', alias], { encoding: 'utf8' });
}

// ---------- 统一接口 ----------
function storeKind() {
  if (isWin) return 'dpapi-currentuser';
  if (isMac) return 'macos-keychain';
  if (isLinux) return hasSecretTool() ? 'linux-secret-service' : 'linux-file-0600';
  return 'unknown';
}

function save(alias, payload) {
  const plain = JSON.stringify(payload);
  const kind = storeKind();
  const file = credFile(alias);

  if (isWin) {
    dpapiProtect(plain, file);
    return { store: kind, file };
  }
  if (isMac) {
    macSave(alias, plain);
    // 钥匙串存的不是文件，写一个占位仅用于表示本机已授权，内容为空
    fs.writeFileSync(file, '', { mode: 0o600 });
    return { store: kind, file };
  }
  if (isLinux && kind === 'linux-secret-service') {
    linSaveSecret(alias, plain);
    fs.writeFileSync(file, '', { mode: 0o600 });
    return { store: kind, file };
  }
  // 降级：0600 权限文件。这是明确告知的降级，不是默认方案。
  fs.writeFileSync(file, plain, { mode: 0o600 });
  try {
    fs.chmodSync(file, 0o600);
  } catch {
    /* ignore */
  }
  log.warn('当前 Linux 环境没有 secret-tool，凭据以 0600 权限文件保存。建议安装 libsecret 以使用系统密钥环。');
  return { store: kind, file, degraded: true };
}

function load(alias) {
  const kind = storeKind();
  const file = credFile(alias);

  if (isWin) {
    if (!fs.existsSync(file)) throw new SkillError('NO_CRED', `本机没有账号 ${alias} 的凭据，请先 auth login --as ${alias}`);
    let plain;
    try {
      plain = dpapiUnprotect(file);
    } catch (e) {
      throw new SkillError(
        'CRED_UNDECRYPTABLE',
        `账号 ${alias} 的凭据无法解密。DPAPI 绑定当前 Windows 用户，换用户或复制别机的凭据都会失败。请重新 auth login --as ${alias}。`
      );
    }
    return JSON.parse(plain);
  }

  if (isMac) {
    let plain;
    try {
      plain = macLoad(alias);
    } catch {
      throw new SkillError('NO_CRED', `钥匙串里没有账号 ${alias} 的凭据，请先 auth login --as ${alias}`);
    }
    return JSON.parse(plain);
  }

  if (isLinux) {
    if (kind === 'linux-secret-service') {
      try {
        return JSON.parse(linLoadSecret(alias));
      } catch {
        /* 落到文件 */
      }
    }
    if (!fs.existsSync(file)) throw new SkillError('NO_CRED', `本机没有账号 ${alias} 的凭据，请先 auth login --as ${alias}`);
    const raw = fs.readFileSync(file, 'utf8');
    if (!raw.trim()) throw new SkillError('CRED_EMPTY', `账号 ${alias} 的凭据为空，请重新授权。`);
    return JSON.parse(raw);
  }

  throw new SkillError('UNSUPPORTED_PLATFORM', `不支持的平台：${process.platform}`);
}

function remove(alias) {
  const file = credFile(alias);
  let removed = false;
  if (isMac) removed = macDelete(alias) || removed;
  if (isLinux && storeKind() === 'linux-secret-service') {
    try {
      execFileSync('secret-tool', ['clear', 'service', SERVICE, 'account', alias], { stdio: 'ignore' });
      removed = true;
    } catch {
      /* ignore */
    }
  }
  if (fs.existsSync(file)) {
    fs.rmSync(file, { force: true });
    removed = true;
  }
  return removed;
}

function exists(alias) {
  const file = credFile(alias);
  return fs.existsSync(file);
}

module.exports = { save, load, remove, exists, storeKind, credFile, accountsDir, SERVICE };
