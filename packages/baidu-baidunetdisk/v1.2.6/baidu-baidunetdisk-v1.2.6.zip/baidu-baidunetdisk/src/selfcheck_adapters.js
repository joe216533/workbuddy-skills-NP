'use strict';
// 平台适配器：夸克 / 百度
// 每个适配器实现 checkLocal / checkSaver / checkLink / doSave / verifyResult / renameSaved
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const { E } = require('./selfcheck_common.js');

// 第 6 步（归档改名）专用错误码。这两个码不参与整体结论判定，只用于如实描述失败原因，
// 避免把“改名撞名”笼统报成 SAVE_FAILED 误导排障。
const RENAME_CONFLICT = 'RENAME_CONFLICT';
const RENAME_FAILED = 'RENAME_FAILED';

function runNode(cli, args, timeout = 60000) {
  try {
    const out = execFileSync(process.execPath, [cli, ...args], {
      encoding: 'utf8', timeout, windowsHide: true,
      maxBuffer: 8 * 1024 * 1024,
      // 显式收走子进程 stderr：默认 stderr 会直接透传到调用方，
      // 导致“中间重试打印的 ERROR 日志”混进自检输出，看起来像自检失败。
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, MSYS_NO_PATHCONV: '1', WB_SELFCHECK_RUNNING: '1' },
    });
    return { ok: true, out };
  } catch (e) {
    const out = String((e.stdout || '') + (e.stderr || ''));
    return { ok: false, out, code: e.code, timedOut: e.killed === true };
  }
}

function sessionArgs(extra = []) {
  return [...extra, '--session-input', 'WorkBuddy 启动自检', '--session-id', 'keep-' + Date.now()];
}

function lastJson(text) {
  if (!text) return null;
  const lines = text.split(/\r?\n/).filter((l) => l.trim().startsWith('{'));
  const parsed = [];
  for (const l of lines) {
    try { parsed.push(JSON.parse(l)); } catch {}
  }
  if (!parsed.length) {
    try { return JSON.parse(text); } catch {}
    return null;
  }
  for (let i = parsed.length - 1; i >= 0; i--) {
    if (parsed[i] && parsed[i].type === 'result') return parsed[i];
  }
  return parsed[parsed.length - 1];
}

function mapError(platform, text) {
  const t = String(text || '').toLowerCase();
  if (!t) return E.UNKNOWN_ERROR;
  if (/41017|禁止转存自己的分享|用户禁止转存/.test(t)) return E.CREATOR_SAVE_BLOCKED;
  if (/enotfound|econnrefused|etimedout|econnreset|socket hang up|network/.test(t)) return E.NETWORK_ERROR;
  if (/not logged|未登录|未完成授权|unauthor|登录.*(失效|过期)|token.*(invalid|expired)/.test(t)) return E.AUTH_EXPIRED;
  if (/空间.*(不足|已满)|insufficient|no space|quota.*space|存储空间已不足/.test(t)) return E.SPACE_INSUFFICIENT;
  if (/提取码|passcode|pwd.*(error|invalid)/.test(t)) return E.PASSCODE_INVALID;
  if (/链接.*(失效|无效|不存在)|share.*(invalid|not found|expired)|分享已(取消|失效)/.test(t)) return E.LINK_INVALID;
  if (/频繁|频率|rate.?limit|too many/.test(t)) return E.RATE_LIMITED;
  if (/权限|permission|forbidden|403/.test(t)) return E.PERMISSION_DENIED;
  if (/同名|name.?conflict|exists_or_param/.test(t)) return E.NAME_CONFLICT;
  if (/5\d\d|服务异常|server error|internal/.test(t)) return E.PLATFORM_ERROR;
  return E.SAVE_FAILED;
}

function withAlias(args, alias) {
  return alias ? [...args, '--as', alias] : args;
}

// ───────────────────────── 夸克 ─────────────────────────
const quark = {
  id: 'quark',
  label: '夸克网盘',

  checkLocal(cfg) {
    if (!cfg.saver_cli || !fs.existsSync(cfg.saver_cli)) return { ok: false, error: E.CLI_MISSING };
    return { ok: true };
  },

  checkSaver(cfg) {
    const r = runNode(cfg.saver_cli, sessionArgs(['get-user-info']), 40000);
    const j = lastJson(r.out);
    if (!j || j.code !== 0) {
      return { ok: false, error: mapError('quark', r.out), raw: r.out.slice(-500) };
    }
    const d = j.data || {};
    const total = Number(d.vipInfo?.capacity ?? 0);
    const used = Number(d.vipInfo?.used ?? 0);
    return {
      ok: true,
      nickname: d.userInfo?.nickname ?? null,
      total, used, free: total - used,
    };
  },

  checkLink(cfg) {
    const extra = ['--url', cfg.share_url];
    if (cfg.passcode) extra.push('--passcode', cfg.passcode);
    const r = runNode(cfg.saver_cli, sessionArgs(['share-detail', ...extra]), 40000);
    const j = lastJson(r.out);
    if (!j || j.code !== 0) {
      return { ok: false, error: mapError('quark', r.out), raw: r.out.slice(-500) };
    }
    const si = j.data?.share_info || {};
    const first = j.data?.share_info?.first_file || j.data?.files?.[0] || {};
    if (si.url_type !== 1 || si.expired_type !== 1) {
      return { ok: false, error: E.LINK_INVALID, raw: `url_type=${si.url_type}, expired_type=${si.expired_type}` };
    }
    if (first.filename && first.filename !== cfg.expected_name) {
      return { ok: false, error: E.LINK_INVALID, raw: `filename=${first.filename}` };
    }
    return {
      ok: true,
      title: si.title || null,
      expired_type: si.expired_type,
      expired_days: si.expired_days ?? null,
      file_num: si.file_num ?? null,
    };
  },

  doSave(cfg) {
    const extra = ['--url', cfg.share_url];
    if (cfg.passcode) extra.push('--passcode', cfg.passcode);
    const r = runNode(cfg.saver_cli, sessionArgs(['saveas', ...extra]), 90000);
    const j = lastJson(r.out);
    if (!j || j.code !== 0) {
      return { ok: false, error: mapError('quark', r.out), raw: r.out.slice(-600) };
    }
    const sa = j.data?.save_as || {};
    const remain = Number(sa.remain_capacity ?? NaN);
    return {
      ok: true,
      savePath: j.data?.save_path || null,
      archiveFid: sa.to_pdir_fid || null,
      savedIds: [].concat(sa.save_as_top_fids || [], sa.save_as_select_top_fids || []),
      createdAt: Number(j.data?.created_at ?? NaN),
      remainCapacity: Number.isFinite(remain) ? remain : null,
      notice: j.notice?.text || null,
    };
  },

  verifyResult(cfg, saveInfo) {
    if (!saveInfo?.archiveFid) return { ok: false, error: E.RESULT_NOT_FOUND, reason: '转存结果未返回归档目录 ID' };
    const r = runNode(cfg.saver_cli, sessionArgs([
      'browse', '--parent-fid', saveInfo.archiveFid, '--page-size', '50',
    ]), 40000);
    const j = lastJson(r.out);
    if (!j || j.code !== 0) {
      return { ok: false, error: mapError('quark', r.out) };
    }
    const list = j.data?.file_list || [];
    const stem = String(cfg.expected_name || '').replace(/\.txt$/, '');
    const sameSize = list.filter((f) => Number(f.size) === Number(cfg.expected_size));
    // 以本次 saveas 返回的创建时间为主键；平台可能秒传复用同一文件，文件也可能已被上一轮改名。
    const hit = sameSize.find((f) =>
      Number(f.created_at) === Number(saveInfo.createdAt) &&
      (String(f.filename || '') === cfg.expected_name ||
       String(f.filename || '').startsWith(stem) ||
       String(f.filename || '').startsWith('可删除_'))
    ) || sameSize.find((f) => Number(f.created_at) === Number(saveInfo.createdAt));
    if (!hit) return { ok: false, error: E.RESULT_NOT_FOUND, reason: '未在本次归档目录中核验到本次保存文件' };
    return {
      ok: true,
      filename: hit.filename,
      size: hit.size,
      fid: hit.fid,
      count: list.length,
      reusedCloudFile: Number(hit.created_at) === Number(saveInfo.createdAt),
    };
  },

  renameSaved(cfg, saved, newName) {
    const os = require('node:os');
    if (!saved?.fid || !saved?.filename) {
      return { ok: false, error: E.SAVE_FAILED, reason: '缺少 fid 或原文件名' };
    }
    if (saved.filename === newName) return { ok: true, unchanged: true, to: newName };
    const items = {
      schema_version: 1,
      items: [{ fid: saved.fid, old_name: saved.filename, new_name: newName }],
    };
    const tmp = path.join(os.tmpdir(), `keep-rename-${Date.now()}.json`);
    try {
      fs.writeFileSync(tmp, JSON.stringify(items), 'utf8');
      const r = runNode(cfg.saver_cli, sessionArgs(['rename', '--items-file', tmp]), 60000);
      const j = lastJson(r.out);
      if (!j || j.code !== 0) return { ok: false, error: mapError('quark', r.out), raw: r.out.slice(-400) };
      const d = j.data || {};
      if (d.result_status !== 'SUCCESS') {
        return { ok: false, error: E.SAVE_FAILED, reason: `result_status=${d.result_status}`, raw: r.out.slice(-400) };
      }
      return { ok: true, to: newName, success: d.success_count };
    } finally {
      try { fs.unlinkSync(tmp); } catch {}
    }
  },
};

// ───────────────────────── 百度 ─────────────────────────
const baidu = {
  id: 'baidu',
  label: '百度网盘',

  checkLocal(cfg) {
    if (!cfg.saver_cli || !fs.existsSync(cfg.saver_cli)) return { ok: false, error: E.CLI_MISSING };
    return { ok: true };
  },

  checkSaver(cfg) {
    const r = runNode(cfg.saver_cli, withAlias(['auth', 'status', '--json'], cfg.saver_alias), 40000);
    const j = lastJson(r.out);
    if (!j || j.ok === false) {
      return { ok: false, error: mapError('baidu', r.out), raw: r.out.slice(-500) };
    }
    if (!j.account_alias) {
      return { ok: false, error: E.AUTH_MISSING, raw: '未检测到当前授权账号' };
    }
    const parse = (s) => {
      const m = String(s || '').match(/([\d.]+)\s*(B|KB|MB|GB|TB)/i);
      if (!m) return NaN;
      const mul = { B: 1, KB: 1024, MB: 1048576, GB: 1073741824, TB: 1099511627776 };
      return parseFloat(m[1]) * mul[m[2].toUpperCase()];
    };
    return {
      ok: true,
      nickname: j.account_alias,
      total: parse(j.quota_total),
      used: parse(j.quota_used),
      free: parse(j.quota_free),
    };
  },

  // 百度 CLI 无分享详情命令；本步骤记录 NOT_RUN，链接有效性由转存步骤判定
  checkLink() {
    return { ok: true, notRun: true, reason: '百度技能无分享详情命令，链接有效性由真实转存判定' };
  },

  doSave(cfg) {
    const args = ['transfer', cfg.share_url];
    if (cfg.passcode) args.push('--pwd', cfg.passcode);
    if (cfg.archive_path) args.push('--to', cfg.archive_path);
    args.push('--json');
    const r = runNode(cfg.saver_cli, withAlias(args, cfg.saver_alias), 120000);
    const j = lastJson(r.out);
    if (!j || j.ok === false) {
      return { ok: false, error: mapError('baidu', r.out), raw: r.out.slice(-600) };
    }
    return {
      ok: true,
      savePath: j.target_file_path || null,
      fileId: j.target_file_id || null,
      renamed: j.renamed === true,
    };
  },

  verifyResult(cfg, saveInfo) {
    if (!saveInfo?.savePath) return { ok: false, error: E.RESULT_NOT_FOUND, reason: '转存结果未返回目标文件路径' };
    const dir = path.posix.dirname(saveInfo.savePath);
    const r = runNode(cfg.saver_cli, withAlias(['list', dir, '--json'], cfg.saver_alias), 40000);
    const j = lastJson(r.out);
    if (!j || j.ok === false) return { ok: false, error: mapError('baidu', r.out) };
    const items = j.items || [];
    const hit = items.find((f) => String(f.fs_id) === String(saveInfo.fileId)) ||
      items.find((f) => String(f.name || '') === path.posix.basename(saveInfo.savePath));
    if (!hit) return { ok: false, error: E.RESULT_NOT_FOUND, reason: '未在目标目录核验到本次保存文件' };
    return { ok: true, filename: hit.name, size: hit.size, fid: hit.fs_id, count: items.length };
  },

  renameSaved(cfg, saved, newName) {
    if (!saved?.filename) return { ok: false, error: RENAME_FAILED, reason: '缺少原文件名' };
    if (saved.filename === newName) return { ok: true, unchanged: true, to: newName };

    const dir = path.posix.dirname(saved.savePath || cfg.archive_path || '');
    const from = `${dir}/${saved.filename}`.replace(/^\/$/, '/');

    // 归档名固定成“可删除_日期_自检副本.txt”，同一天重复自检必然撞名。
    // 做法：撞名不算失败，先加 _2.._4，再退到带时间戳的名字，保证一定落得下去。
    const m = /^(.*?)(\.[^.]+)?$/.exec(newName);
    const stem = m[1];
    const ext = m[2] || '.txt';
    const stamp = new Date().toISOString().slice(11, 19).replace(/:/g, '');
    const candidates = [
      newName,
      `${stem}_2${ext}`,
      `${stem}_3${ext}`,
      `${stem}_4${ext}`,
      `${stem}_${stamp}${ext}`,
    ];

    let lastConflict = '';
    for (let i = 0; i < candidates.length; i++) {
      const name = candidates[i];
      const r = runNode(cfg.saver_cli, withAlias(['rename', from, name, '--json'], cfg.saver_alias), 60000);
      const j = lastJson(r.out);
      if (j && j.ok !== false) {
        return { ok: true, to: j.to || `${dir}/${name}`, renamedTo: name, attempt: i + 1 };
      }
      const out = String(r.out || '');
      const code = (j && (j.error_code || j.code)) || '';
      const isConflict = ['RENAME_CONFLICT', 'NAME_CONFLICT', 'EXISTS_OR_PARAM', 'ALREADY_EXISTS'].includes(code) ||
        /同名|已存在|占用|name.?conflict|exists/i.test(out);
      // 不是撞名就立即失败，不要用加后缀掩盖真实原因
      if (!isConflict) {
        return { ok: false, error: RENAME_FAILED, reason: code || '改名失败', raw: out.slice(-400) };
      }
      lastConflict = out;
    }
    return {
      ok: false,
      error: RENAME_CONFLICT,
      reason: '归档名连续撞名（同名文件已存在），已尝试加后缀仍冲突',
      raw: lastConflict.slice(-400),
    };
  },
};

module.exports = { quark, baidu, mapError, lastJson, RENAME_CONFLICT, RENAME_FAILED };
