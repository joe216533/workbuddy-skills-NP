'use strict';
// 目录读取：分页、stat、递归统计
const { ok } = require('./utils_errors');
const { normalize, basename, join, MAX_DEPTH } = require('./storage_paths');

const PAGE_SIZE = 200;

// 列一层目录。dir 必须是已规范化的绝对路径。
async function listDir(client, dir, { page = 1, num = PAGE_SIZE } = {}) {
  const d = normalize(dir);
  const r = await client.api('/api/list', {
    order: 'name',
    desc: '0',
    showempty: '1',
    page: String(page),
    num: String(num),
    dir: d,
    t: String(Date.now()),
  });
  if (!r.j) throw new Error(`目录读取返回非 JSON（HTTP ${r.http}）：${r.text || ''}`);
  ok(r.j.errno, r.j, `读取目录 ${d}`);
  return r.j;
}

// 列全部（自动翻页）
async function listAll(client, dir) {
  const d = normalize(dir);
  let page = 1;
  let all = [];
  for (;;) {
    const j = await listDir(client, d, { page, num: PAGE_SIZE });
    const items = j.list || [];
    all = all.concat(items);
    if (items.length < PAGE_SIZE || page >= 50) break;
    page++;
  }
  return all.map((x) => ({
    fs_id: Number(x.fs_id),
    name: x.server_filename,
    path: x.path || join(d, x.server_filename),
    isdir: Number(x.isdir) === 1,
    size: Number(x.size || 0),
    mtime: Number(x.server_mtime || x.local_mtime || 0),
    md5: x.md5 || null,
  }));
}

// 精确查一个路径对应的条目；不存在返回 null
async function stat(client, remotePath) {
  const p = normalize(remotePath);
  if (p === '/') return { path: '/', name: '', isdir: true, size: 0, fs_id: 0, mtime: 0, isRoot: true };
  const parent = p.slice(0, p.lastIndexOf('/')) || '/';
  const name = basename(p);
  let items;
  try {
    items = await listAll(client, parent);
  } catch (e) {
    // 父目录不存在时按"目标不存在"处理，不把异常当成功
    if (/路径|不存在|BAD_PATH/.test(String(e.message))) return null;
    throw e;
  }
  return items.find((x) => x.name === name) || null;
}

// 递归统计目录内容（用于删除预览：必须给出数量、总大小、范围）
async function walk(client, remotePath, depth = 0) {
  const p = normalize(remotePath);
  const files = [];
  const dirs = [];
  let totalSize = 0;
  if (depth > MAX_DEPTH) return { files, dirs, totalSize, truncated: true };

  const items = await listAll(client, p);
  for (const it of items) {
    if (it.isdir) {
      dirs.push(it.path);
      const sub = await walk(client, it.path, depth + 1);
      files.push(...sub.files);
      dirs.push(...sub.dirs);
      totalSize += sub.totalSize;
    } else {
      files.push(it);
      totalSize += it.size;
    }
  }
  return { files, dirs, totalSize, truncated: false };
}

module.exports = { listDir, listAll, stat, walk, PAGE_SIZE };
