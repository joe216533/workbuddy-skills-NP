'use strict';
// 百度接口请求基础层：cookie 鉴权、bdstoken 获取、统一响应解析
const { SkillError, explain } = require('./utils_errors');
const log = require('./utils_logger');

const APPID = '250528';
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36';
const PAN = 'https://pan.baidu.com';

class PanClient {
  constructor(cred, alias) {
    if (!cred || !cred.bduss || !cred.stoken) {
      throw new SkillError('BAD_CRED', '凭据缺少 BDUSS 或 STOKEN，请重新授权。');
    }
    this.alias = alias || null;
    this.cookie = `BDUSS=${cred.bduss}; STOKEN=${cred.stoken}`;
    this.bdstoken = null;
    this.uk = null;
  }

  hdr(extra = {}) {
    return {
      Cookie: this.cookie,
      'User-Agent': UA,
      Referer: `${PAN}/disk/main`,
      ...extra,
    };
  }

  // 公共查询参数
  q(params = {}) {
    return new URLSearchParams({
      clienttype: '0',
      app_id: APPID,
      web: '1',
      channel: 'chunlei',
      bdstoken: this.bdstoken || '',
      ...params,
    }).toString();
  }

  async request(pathname, { params = {}, body = null, raw = false } = {}) {
    const url = pathname.startsWith('http') ? pathname : `${PAN}${pathname}?${this.q(params)}`;
    const opt = { headers: this.hdr() };
    if (body != null) {
      opt.method = 'POST';
      opt.headers = this.hdr({ 'Content-Type': 'application/x-www-form-urlencoded' });
      opt.body = body;
    }
    log.debug(`请求 ${opt.method || 'GET'} ${url.replace(/bdstoken=[^&]*/, 'bdstoken=***')}`);
    const r = await fetch(url, opt);
    const text = await r.text();
    if (raw) return { http: r.status, text };
    let j = null;
    try {
      j = JSON.parse(text);
    } catch {
      /* 非 JSON，交给调用方看 text */
    }
    return { http: r.status, j, text: j ? null : text.slice(0, 300) };
  }

  async api(pathname, params = {}, body = null) {
    return this.request(pathname, { params, body });
  }

  // 直接对完整 URL 发请求（调用方已自行拼好全部查询参数）
  async getAbsolute(url, extraHeaders = {}, wantsJson = true) {
    log.debug(`请求 GET ${url.replace(/bdstoken=[^&]*/, 'bdstoken=***').replace(/sekey=[^&]*/, 'sekey=***')}`);
    const r = await fetch(url, { headers: this.hdr(extraHeaders) });
    const text = await r.text();
    if (!wantsJson) return { http: r.status, text };
    let j = null;
    try {
      j = JSON.parse(text);
    } catch {
      /* ignore */
    }
    return { http: r.status, j, text: j ? null : text.slice(0, 300) };
  }

  // 初始化：取 bdstoken 与 uk，并顺带确认登录态有效
  async init() {
    const r = await this.request('/api/gettemplatevariable', {
      params: { fields: JSON.stringify(['bdstoken', 'uk']), clienttype: '0', app_id: APPID, web: '1', channel: 'chunlei' },
    });
    const j = r.j;
    if (!j) throw new SkillError('BAD_RESPONSE', `接口返回非 JSON（HTTP ${r.http}）：${r.text || ''}`);
    if (j.errno !== 0) {
      const e = explain(j.errno, j);
      throw new SkillError(e.code, e.text, { errno: j.errno, exit: e.exit });
    }
    this.bdstoken = j.result && j.result.bdstoken;
    this.uk = j.result && j.result.uk;
    if (!this.bdstoken) throw new SkillError('NO_BDSTOKEN', '未能获取 bdstoken，登录态可能已失效，请重新授权。');
    log.debug(`初始化完成 uk=${this.uk} bdstoken 长度=${String(this.bdstoken).length}`);
    return this;
  }

  // 当前账号容量
  async quota() {
    const r = await this.api('/api/quota', { checkfree: '1', checkexpire: '1' });
    return r.j;
  }

  // 账号信息（昵称等只用于人看，不作为别名依据）
  async uinfo() {
    const r = await this.request('/rest/2.0/xpan/nas', { params: { method: 'uinfo', app_id: APPID, web: '1' } });
    return r.j;
  }
}

module.exports = { PanClient, APPID, UA, PAN };
