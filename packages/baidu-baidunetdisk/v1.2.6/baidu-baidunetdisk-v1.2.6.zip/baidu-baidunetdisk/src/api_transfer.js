'use strict';
// 转存他人分享：surl → verify(取 randsk) → share/list → share/transfer
//
// 四个必须记住的细节（全部来自实测踩坑）：
//   1. surl = 短链去掉首字符 '1'；share/list 的 shorturl 也用这个值，用完整短链会 errno=140
//   2. 服务端抓取时 ?pwd= 无效，必须 POST /share/verify 换 randsk
//   3. 后续请求 Cookie 追加 BDCLND=<randsk>
//   4. share/transfer 还要带 sekey=<randsk>，否则报 200025「提取码输入错误」
const { normalize } = require('./storage_paths');
const { SkillError, explain } = require('./utils_errors');
const log = require('./utils_logger');

const PAN = 'https://pan.baidu.com';
const APPID = '250528';

function parseShareUrl(input) {
  const s = String(input || '').trim();
  const m = s.match(/pan\.baidu\.com\/s\/([A-Za-z0-9_-]+)/);
  if (!m) throw new SkillError('BAD_SHARE_URL', `无法解析分享链接：${s}`);
  const shorturl = m[1];
  // 支持 /s/1abcd?pwd=xxxx 与 /s/1abcd 两种形态，也支持省略协议的粘贴
  const pwdFromUrl = (s.match(/[?&]pwd=([A-Za-z0-9]{4})/) || [])[1] || null;
  const surl = shorturl.startsWith('1') ? shorturl.slice(1) : shorturl;
  return { shorturl, surl, pwdFromUrl };
}

// 建立分享会话：返回 shareid / uk / 文件列表 / 带 BDCLND 的 cookie
async function openShareSession(client, shareUrl, pwd) {
  const { surl, pwdFromUrl, shorturl } = parseShareUrl(shareUrl);
  const password = pwd || pwdFromUrl;
  let randsk = null;

  if (password) {
    const url = `${PAN}/share/verify?t=${Date.now()}&bioc=1&surl=${surl}&channel=chunlei&web=1&app_id=${APPID}&bdstoken=${client.bdstoken || ''}`;
    const r = await fetch(url, {
      method: 'POST',
      headers: client.hdr({
        'Content-Type': 'application/x-www-form-urlencoded',
        Referer: `${PAN}/share/init?surl=${surl}`,
      }),
      body: `pwd=${encodeURIComponent(password)}&vcode=&vcode_str=`,
    });
    const j = await r.json();
    if (j.errno !== 0) {
      const e = explain(j.errno, j);
      throw new SkillError(e.code, `提取码校验未通过：${e.text}`, { errno: j.errno, exit: e.exit });
    }
    randsk = j.randsk;
  }

  const cookie = randsk ? `${client.cookie}; BDCLND=${randsk}` : client.cookie;
  const listUrl =
    `${PAN}/share/list?shorturl=${surl}&web=5&app_id=${APPID}&desc=1&showempty=0&page=1&num=100` +
    `&order=time&root=1&view_mode=1&channel=chunlei&clienttype=0&bdstoken=${client.bdstoken || ''}`;
  const lr = await fetch(listUrl, { headers: { ...client.hdr(), Cookie: cookie, Referer: shareUrl } });
  const lj = await lr.json();
  if (lj.errno !== 0) {
    const e = explain(lj.errno, lj);
    throw new SkillError(e.code, `读取分享内容失败：${e.text}`, { errno: lj.errno, exit: e.exit, share: shorturl });
  }

  return {
    surl,
    shorturl,
    randsk,
    cookie,
    shareid: lj.share_id,
    fromUk: lj.uk,
    expiredType: lj.expired_type,
    title: lj.title || '',
    files: (lj.list || []).map((f) => ({
      fs_id: Number(f.fs_id),
      name: f.server_filename,
      isdir: Number(f.isdir) === 1,
      size: Number(f.size || 0),
    })),
  };
}

// 转存到自己的目录
async function transfer(client, shareUrl, toDir, pwd) {
  const s = await openShareSession(client, shareUrl, pwd);
  if (!s.files.length) throw new SkillError('EMPTY_SHARE', '分享里没有可转存的文件。');

  const ids = s.files.map((f) => f.fs_id);
  const target = normalize(toDir);
  log.info(`转存 ${s.files.map((f) => f.name).join('、')} → ${target}`);

  const qs = new URLSearchParams({
    shareid: String(s.shareid),
    from: String(s.fromUk),
    ondup: 'newcopy',
    channel: 'chunlei',
    web: '1',
    app_id: APPID,
    clienttype: '0',
    bdstoken: client.bdstoken || '',
    sekey: s.randsk ? decodeURIComponent(s.randsk) : '',
  });

  const r = await fetch(`${PAN}/share/transfer?${qs.toString()}`, {
    method: 'POST',
    headers: client.hdr({
      'Content-Type': 'application/x-www-form-urlencoded',
      Cookie: s.cookie,
      Referer: shareUrl,
    }),
    body: `fsidlist=${encodeURIComponent(JSON.stringify(ids))}&path=${encodeURIComponent(target)}`,
  });
  const text = await r.text();
  let j = null;
  try {
    j = JSON.parse(text);
  } catch {
    /* ignore */
  }
  if (!j) throw new SkillError('BAD_RESPONSE', `转存返回非 JSON（HTTP ${r.status}）：${text.slice(0, 200)}`);

  if (j.errno !== 0) {
    const e = explain(j.errno, j);
    throw new SkillError(e.code, `转存失败：${e.text}`, { errno: j.errno, exit: e.exit, from_fs: ids });
  }

  const extra = j.extra || {};
  return mapTransferExtra(extra, { shareUrl, files: s.files, target });
}

// 把 /share/transfer 的 extra 映射成对外的结果字段。
// 真实结构：extra.list[] = [{ from, from_fs_id, to, to_fs_id }]
// 注意 to 是服务端实际落点——同目录已有同名文件时会自动改名成 xxx(1).zip，
// 所以不能假设"目标目录 + 原文件名"，必须回报 to。
function mapTransferExtra(extra, { shareUrl, files, target }) {
  const moved = Array.isArray(extra.list) ? extra.list : [];
  const first = moved[0] || {};
  const srcName = files && files.length ? files[0].name : '';
  return {
    source_share_url: shareUrl,
    source_file_name: (files || []).map((f) => f.name).join('、'),
    source_file_count: (files || []).length,
    target_path: target,
    target_file_id: first.to_fs_id ? Number(first.to_fs_id) : extra.to_fs_id ? Number(extra.to_fs_id) : null,
    target_file_path: first.to || null,
    renamed: first.to && srcName ? !String(first.to).endsWith('/' + srcName) : false,
    moved_list: moved.map((x) => ({ from: x.from, to: x.to, to_fs_id: x.to_fs_id ? Number(x.to_fs_id) : null })),
    transfer_status: 'success',
  };
}

module.exports = { parseShareUrl, openShareSession, transfer, mapTransferExtra };
