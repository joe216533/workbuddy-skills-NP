#!/usr/bin/env node
'use strict';
// 发布前硬门禁：任何一项 FAIL 都不允许打包发布
const fs = require('node:fs');
const path = require('node:path');
const { REQUIRED } = require('../src/verify_basic');

const ROOT = path.resolve(__dirname, '..');
const results = [];
let failed = 0;

function check(name, fn) {
  try {
    const r = fn();
    const status = r.status || (r.ok ? 'PASS' : 'FAIL');
    if (status === 'FAIL') failed++;
    results.push({ name, status, detail: r.detail || '' });
  } catch (e) {
    failed++;
    results.push({ name, status: 'FAIL', detail: e.message });
  }
}

function walk(dir, acc = []) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ent.name === '.git' || ent.name === 'node_modules') continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p, acc);
    else acc.push(p);
  }
  return acc;
}

const allFiles = walk(ROOT);
const rel = (p) => path.relative(ROOT, p).replace(/\\/g, '/');

// 1. 必备文件
check('必备文件齐全', () => {
  const missing = REQUIRED.filter((r) => !fs.existsSync(path.join(ROOT, r)));
  return { ok: !missing.length, detail: missing.length ? `缺失：${missing.join(', ')}` : `${REQUIRED.length} 个文件` };
});

// 2. 版本一致（manifest.json 与 SKILL.md frontmatter）
check('版本号一致', () => {
  const m = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
  const s = fs.readFileSync(path.join(ROOT, 'SKILL.md'), 'utf8');
  const fm = s.match(/^---[\s\S]*?\bversion:\s*([0-9]+\.[0-9]+\.[0-9]+)/m);
  const skillVer = fm ? fm[1] : null;
  const same = skillVer && m.version && skillVer === m.version;
  return { ok: Boolean(same), detail: `manifest=${m.version} SKILL.md=${skillVer || '未找到'}` };
});

// 3. 中文显示名
check('manifest 含中文显示名', () => {
  const m = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
  const name = m.displayName || m.display_name || '';
  return { ok: /[\u4e00-\u9fa5]/.test(name), detail: name || '缺失' };
});

// 4. 禁止夹带真实凭据、账号索引、日志、临时文件
check('无凭据与临时文件', () => {
  const bad = allFiles.filter((p) => {
    const n = rel(p);
    return (
      /\.cred$/i.test(n) ||
      /(^|\/)accounts\.json$/i.test(n) ||
      /\.(log|tmp|plain\.tmp)$/i.test(n) ||
      /(^|\/)node_modules\//.test(n) ||
      /chrome-.*-profile/.test(n) ||
      /(^|\/)\.DS_Store$/.test(n)
    );
  });
  return { ok: !bad.length, detail: bad.length ? `发现：${bad.join(', ')}` : '干净' };
});

// 5. 源码里不得出现真实 BDUSS/STOKEN 形态的值
check('源码无真实凭据值', () => {
  const hits = [];
  for (const p of allFiles) {
    if (!/\.(js|cjs|json|md|txt)$/i.test(p)) continue;
    if (rel(p).startsWith('tests/')) continue;
    const t = fs.readFileSync(p, 'utf8');
    if (/(BDUSS|STOKEN)\s*=\s*[A-Za-z0-9_-]{40,}/.test(t)) hits.push(rel(p));
  }
  return { ok: !hits.length, detail: hits.length ? `命中：${hits.join(', ')}` : '未发现' };
});

// 6. 源码里不得出现开发者本机绝对路径
check('无本机绝对路径泄漏', () => {
  const bad = [];
  for (const p of allFiles) {
    if (!/\.(js|cjs|json|md|txt)$/i.test(p)) continue;
    const t = fs.readFileSync(p, 'utf8');
    if (/[A-Za-z]:[\\/](Tools|Users)[\\/]/.test(t)) bad.push(rel(p));
  }
  return { ok: !bad.length, detail: bad.length ? `命中：${bad.join(', ')}` : '未发现' };
});

// 7. 许可证与第三方声明
check('许可证与第三方声明', () => {
  const need = ['LICENSE', 'THIRD-PARTY-NOTICES'];
  const missing = need.filter((r) => !fs.existsSync(path.join(ROOT, r)));
  if (missing.length) return { ok: false, detail: `缺失：${missing.join(', ')}` };

  // 零依赖声明必须与 package.json 实际情况一致
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const deps = Object.keys({ ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) });
  const licDir = path.join(ROOT, 'licenses');
  const licFiles = fs.existsSync(licDir)
    ? fs.readdirSync(licDir).filter((f) => /\.txt$/i.test(f))
    : [];

  if (deps.length && !licFiles.length) {
    return { ok: false, detail: `package.json 声明了 ${deps.length} 个依赖，但 licenses/ 下没有许可证文本` };
  }
  return {
    ok: true,
    detail: deps.length ? `依赖 ${deps.length} 个，许可证文本 ${licFiles.length} 份` : '零第三方依赖，声明齐全',
  };
});

// 8. 文档齐全
check('文档齐全', () => {
  const need = ['docs/architecture.md', 'docs/security.md', 'docs/protocol-references.md', 'docs/limitations.md'];
  const missing = need.filter((r) => !fs.existsSync(path.join(ROOT, r)));
  return { ok: !missing.length, detail: missing.length ? `缺失：${missing.join(', ')}` : '齐全' };
});

// 9. SKILL.md 结构要求（目录树 / 命令 / 复现步骤 / 删除限制）
check('SKILL.md 结构完整', () => {
  const s = fs.readFileSync(path.join(ROOT, 'SKILL.md'), 'utf8');
  const need = [
    ['目录树', /├──|└──/],
    ['文件职责', /职责/],
    ['命令清单', /auth login/],
    ['复现步骤', /复现|换机/],
    ['删除安全', /--recursive/],
  ];
  const missing = need.filter(([, re]) => !re.test(s)).map(([n]) => n);
  return { ok: !missing.length, detail: missing.length ? `缺少章节：${missing.join('、')}` : '五项齐全' };
});

// 10. 测试文件存在
check('测试文件齐全', () => {
  const need = ['auth', 'upload', 'share', 'transfer', 'download', 'delete', 'integrity'];
  const missing = need.filter((n) => !fs.existsSync(path.join(ROOT, 'tests', `${n}.test.js`)));
  return { ok: !missing.length, detail: missing.length ? `缺失：${missing.join(', ')}` : '7 个测试文件' };
});

// 输出
const width = Math.max(...results.map((r) => r.name.length));
process.stdout.write('=== 发布前门禁（preflight）===\n');
for (const r of results) {
  process.stdout.write(`${r.name.padEnd(width)}  ${r.status.padEnd(5)}  ${r.detail}\n`);
}
process.stdout.write(`\n结果：${failed ? `FAIL（${failed} 项未通过）` : 'PASS（可以打包发布）'}\n`);
process.exitCode = failed ? 1 : 0;
