'use strict';
// 上传：分片切块、空间预判、本地文件前置校验
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { splitBlocks, humanSize, CHUNK } = require('../src/storage_integrity');
const { checkSpace, uploadFile } = require('../src/api_upload');
const { DEFAULT_UPLOAD_DIR, prepareUploadDir } = require('../src/safety_upload-guard');
const paths = require('../src/storage_paths');

function tmpFile(size) {
  const p = path.join(os.tmpdir(), `bdskill-test-${Date.now()}-${Math.random().toString(16).slice(2)}.bin`);
  fs.writeFileSync(p, Buffer.alloc(size, 7));
  return p;
}

test('4MB 分片：9MB 切成 3 片，最后一片 1MB', () => {
  const p = tmpFile(9 * 1024 * 1024);
  try {
    const { size, blocks, blockList } = splitBlocks(p);
    assert.strictEqual(size, 9 * 1024 * 1024);
    assert.strictEqual(blocks.length, 3);
    assert.strictEqual(blockList.length, 3);
    assert.strictEqual(blocks[0].length, CHUNK);
    assert.strictEqual(blocks[1].length, CHUNK);
    assert.strictEqual(blocks[2].length, 1024 * 1024);
    assert.ok(blockList.every((h) => /^[0-9a-f]{32}$/.test(h)), 'MD5 必须是 32 位十六进制');
  } finally {
    fs.rmSync(p, { force: true });
  }
});

test('小于 4MB 的文件只有 1 片，且空文件也能切', () => {
  const p = tmpFile(1024);
  const q = tmpFile(0);
  try {
    assert.strictEqual(splitBlocks(p).blocks.length, 1);
    assert.strictEqual(splitBlocks(q).blocks.length, 1);
  } finally {
    fs.rmSync(p, { force: true });
    fs.rmSync(q, { force: true });
  }
});

test('checkSpace 正确判定余量不足', async () => {
  const client = { quota: async () => ({ errno: 0, total: 1000, used: 950 }) };
  const r = await checkSpace(client, 100);
  assert.strictEqual(r.known, true);
  assert.strictEqual(r.free, 50);
  assert.strictEqual(r.enough, false);
});

test('checkSpace 余量足够时 enough 为 true', async () => {
  const client = { quota: async () => ({ errno: 0, total: 1000, used: 100 }) };
  const r = await checkSpace(client, 100);
  assert.strictEqual(r.enough, true);
});

test('quota 接口失败时不冒充"空间够用"', async () => {
  const client = { quota: async () => ({ errno: -6 }) };
  const r = await checkSpace(client, 100);
  assert.strictEqual(r.known, false);
});

test('本地文件不存在时在触网前就失败', async () => {
  await assert.rejects(
    () => uploadFile({}, path.join(os.tmpdir(), '绝对不存在的文件-xyz.bin'), '/来自：WorkBuddy/baidu-baidunetdisk'),
    (e) => e.code === 'NO_LOCAL_FILE'
  );
});

test('默认上传目录就是技能根目录', () => {
  assert.strictEqual(DEFAULT_UPLOAD_DIR, paths.SKILL_ROOT);
});

test('prepareUploadDir 规范化路径并标记是否在技能目录外', async () => {
  const client = { api: async () => ({ j: { errno: 0 } }) };
  const a = await prepareUploadDir(client, '/来自：WorkBuddy/baidu-baidunetdisk/sub', { createIfMissing: false });
  assert.strictEqual(a.dir, '/来自：WorkBuddy/baidu-baidunetdisk/sub');
  assert.strictEqual(a.outside, false);

  const b = await prepareUploadDir(client, '/别的目录', { createIfMissing: false });
  assert.strictEqual(b.outside, true, '技能目录外要标记出来，但上传本身允许');

  await assert.rejects(() => prepareUploadDir(client, '相对路径', { createIfMissing: false }), /绝对路径/);
});

test('humanSize 输出可读单位', () => {
  assert.strictEqual(humanSize(0), '0 B', '字节级不补小数');
  assert.strictEqual(humanSize(999), '999 B');
  assert.match(humanSize(1024), /^1\.00 KB$/);
  assert.match(humanSize(9 * 1024 * 1024), /^9\.00 MB$/);
});
