'use strict';
// 下载：直链获取的失败分支必须明确报错，不能返回空对象冒充成功
const test = require('node:test');
const assert = require('node:assert');
const { getDlink } = require('../src/api_download');

test('接口 errno 非 0 时抛错，不返回空直链', async () => {
  const client = { getAbsolute: async () => ({ j: { errno: -6 } }) };
  await assert.rejects(() => getDlink(client, 123), (e) => e.code === 'NOT_LOGIN');
});

test('接口返回 0 但没有 dlink 时抛 NO_DLINK', async () => {
  const client = { getAbsolute: async () => ({ j: { errno: 0, info: [{ fs_id: 1, filename: 'a.txt', size: 10 }] } }) };
  await assert.rejects(() => getDlink(client, 1), (e) => e.code === 'NO_DLINK');
});

test('接口返回 info 为空时抛 NO_DLINK', async () => {
  const client = { getAbsolute: async () => ({ j: { errno: 0, info: [] } }) };
  await assert.rejects(() => getDlink(client, 1), (e) => e.code === 'NO_DLINK');
});

test('正常返回 dlink / filename / size', async () => {
  const client = {
    getAbsolute: async (url) => {
      assert.ok(url.includes('method=filemetas'), '必须走 filemetas，不是已失效的 locatedownload');
      assert.ok(url.includes('dlink=1'), '必须请求 dlink');
      assert.ok(url.includes('fsids='), '必须带 fsids');
      return { j: { errno: 0, info: [{ fs_id: 9, filename: '报告.pdf', size: 1234, dlink: 'https://d.pcs.baidu.com/x' }] } };
    },
  };
  const r = await getDlink(client, 9);
  assert.strictEqual(r.dlink, 'https://d.pcs.baidu.com/x');
  assert.strictEqual(r.filename, '报告.pdf');
  assert.strictEqual(r.size, 1234);
});

test('fsids 以数组形式传入', async () => {
  let seen = '';
  const client = {
    getAbsolute: async (url) => {
      seen = url;
      return { j: { errno: 0, info: [{ fs_id: 7, filename: 'x', size: 1, dlink: 'd' }] } };
    },
  };
  await getDlink(client, 7);
  assert.ok(decodeURIComponent(seen).includes('fsids=[7]'), seen);
});
