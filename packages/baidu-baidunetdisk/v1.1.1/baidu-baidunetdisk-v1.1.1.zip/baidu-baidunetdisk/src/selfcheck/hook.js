'use strict';
// 自检前置钩子：每天第一次调用本技能时，自动跑一次真实转存自检。
// 设计约束：
//   1. 只在前置位置执行，不改变任何既有命令的行为与退出码；
//   2. 自检失败只提示，不阻断业务（00A 12.z.1）；
//   3. 用环境变量防递归——自检内部会再次调用本 CLI；
//   4. 未配置时静默跳过，不打扰只想用基础功能的用户。
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawnSync } = require('node:child_process');

const ROOT = path.join(os.homedir(), '.workbuddy', 'keep-agent');
const CFG = path.join(ROOT, 'config.json');
const STATE = path.join(ROOT, 'state', 'baidu.json');
const RUNNER = path.join(__dirname, 'index.js');

function today(tz) {
  const zone = tz || 'Asia/Shanghai';
  try {
    return new Intl.DateTimeFormat('en-CA', { timeZone: zone }).format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

function readConfig() {
  try {
    return JSON.parse(fs.readFileSync(CFG, 'utf8'));
  } catch {
    return null;
  }
}

function doneToday(cfg) {
  try {
    const st = JSON.parse(fs.readFileSync(STATE, 'utf8'));
    return Boolean(st && st.date === today(cfg && cfg.timezone) && st.kind === 'ok');
  } catch {
    return false;
  }
}

/**
 * 判断本次调用是否应该跳过自动自检。
 * @returns {{run:boolean, reason?:string}}
 */
function shouldRun(sub, flags) {
  if (process.env.WB_SELFCHECK_RUNNING === '1') return { run: false, reason: 'RECURSION_GUARD' };
  if (sub === 'selfcheck') return { run: false, reason: 'IS_SELFCHECK' };
  if (String(sub).startsWith('auth')) return { run: false, reason: 'AUTH_COMMAND' };
  if (flags && (flags['no-selfcheck'] || flags.noSelfcheck)) return { run: false, reason: 'OPT_OUT' };

  const cfg = readConfig();
  if (!cfg) return { run: false, reason: 'UNCONFIGURED' };
  if (cfg.platforms && cfg.platforms.baidu && cfg.platforms.baidu.enabled === false) {
    return { run: false, reason: 'DISABLED' };
  }
  if (doneToday(cfg)) return { run: false, reason: 'DONE_TODAY' };
  return { run: true };
}

/**
 * 执行自检。同步，超时 40 秒。
 * @returns {{skipped?:string, code?:number, stdout?:string, stderr?:string, timedOut?:boolean}}
 */
function maybeRun(sub, flags) {
  const decide = shouldRun(sub, flags);
  if (!decide.run) return { skipped: decide.reason };

  const r = spawnSync(process.execPath, [RUNNER, 'run', '--platform', 'baidu'], {
    env: Object.assign({}, process.env, { WB_SELFCHECK_RUNNING: '1' }),
    encoding: 'utf8',
    timeout: 40000,
    windowsHide: true,
  });

  return {
    code: r.status == null ? -1 : r.status,
    stdout: r.stdout || '',
    stderr: r.stderr || (r.error ? String(r.error.message) : ''),
    timedOut: Boolean(r.error && (r.error.code === 'ETIMEDOUT' || r.error.code === 'ABORT_ERR')),
  };
}

/**
 * 把自检结果转成一行提示。只在未通过时输出，通过时保持静默。
 */
function notice(res) {
  if (!res || res.skipped) return '';
  if (res.timedOut) return '[自检] 今日自检超时未完成，不影响本次命令。可手动重跑：selfcheck\n';
  if (res.code === 0) return '';
  if (res.code === 4) {
    return '[自检] 今日自检未通过，不影响本次命令。查看详情：selfcheck --json\n';
  }
  return `[自检] 自检执行异常（退出码 ${res.code}），不影响本次命令。可手动重跑：selfcheck\n`;
}

module.exports = { maybeRun, notice, shouldRun, ROOT, CFG, STATE };
