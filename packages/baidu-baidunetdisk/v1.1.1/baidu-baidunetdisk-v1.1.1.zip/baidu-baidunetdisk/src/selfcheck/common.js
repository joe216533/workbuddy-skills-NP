'use strict';
// 自检核心：日期/锁/状态/历史/错误码
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const ROOT = path.join(os.homedir(), '.workbuddy', 'keep-agent');
const DIR_STATE = path.join(ROOT, 'state');
const DIR_HISTORY = path.join(ROOT, 'history');
const DIR_LOCK = path.join(ROOT, 'locks');

// 错误码（两平台共用，按顾问第 41 轮的分层诊断表）
const E = {
  LOCAL_CONFIG_MISSING: 'LOCAL_CONFIG_MISSING',
  SCRIPT_MISSING: 'SCRIPT_MISSING',
  AUTH_EXPIRED: 'AUTH_EXPIRED',
  AUTH_INVALID: 'AUTH_INVALID',
  SPACE_INSUFFICIENT: 'SPACE_INSUFFICIENT',
  LINK_INVALID: 'LINK_INVALID',
  PASSCODE_INVALID: 'PASSCODE_INVALID',
  PERMISSION_DENIED: 'PERMISSION_DENIED',
  RATE_LIMITED: 'RATE_LIMITED',
  QUOTA_EXCEEDED: 'QUOTA_EXCEEDED',
  NETWORK_ERROR: 'NETWORK_ERROR',
  PLATFORM_ERROR: 'PLATFORM_ERROR',
  NAME_CONFLICT: 'NAME_CONFLICT',
  SAVE_FAILED: 'SAVE_FAILED',
  RESULT_NOT_FOUND: 'RESULT_NOT_FOUND',
  UNKNOWN_ERROR: 'UNKNOWN_ERROR',
};

// 两级结论：明确故障 / 疑似技能异常
const KIND = {
  OK: 'ok',
  CLEAR_FAULT: 'clear_fault',      // 能明确指出是哪个环节坏了
  SUSPECT_SKILL: 'suspect_skill',  // 各环都正常，但转存报无法解释的错
};

// 用户提示模板
const HINT = {
  [E.LOCAL_CONFIG_MISSING]: '自检配置缺失，请先运行初始化（keep init）',
  [E.SCRIPT_MISSING]: '技能脚本缺失，请重新安装技能',
  [E.AUTH_EXPIRED]: '保存方账号登录已过期，请重新授权',
  [E.AUTH_INVALID]: '保存方账号凭据无效，请检查授权状态',
  [E.SPACE_INSUFFICIENT]: '保存方网盘空间不足，请清理空间',
  [E.LINK_INVALID]: '分享链接已失效，请重建分享并更新配置',
  [E.PASSCODE_INVALID]: '提取码错误，请检查配置',
  [E.PERMISSION_DENIED]: '当前账号无权保存该分享，请检查账号与权限',
  [E.RATE_LIMITED]: '平台频率限制，请稍后重试',
  [E.QUOTA_EXCEEDED]: '平台配额限制，请检查账号配额',
  [E.NETWORK_ERROR]: '网络连接失败，请检查网络',
  [E.PLATFORM_ERROR]: '平台服务异常，请稍后重试',
  [E.NAME_CONFLICT]: '目标目录存在同名文件（已自动改名，可忽略）',
  [E.SAVE_FAILED]: '保存失败，请查看诊断信息',
  [E.RESULT_NOT_FOUND]: '命令返回成功但未在目标目录找到文件，需进一步排查',
  [E.UNKNOWN_ERROR]: '未知错误，请保留诊断信息',
};

function ensureDirs() {
  for (const d of [ROOT, DIR_STATE, DIR_HISTORY, DIR_LOCK]) {
    fs.mkdirSync(d, { recursive: true });
  }
}

// 按配置时区取自然日，避免跨机器系统时区差异
function todayStamp(tz) {
  const now = new Date();
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz || 'Asia/Shanghai',
    year: 'numeric', month: '2-digit', day: '2-digit',
  });
  return fmt.format(now); // YYYY-MM-DD
}

function nowISO(tz) {
  const now = new Date();
  const parts = new Intl.DateTimeFormat('sv-SE', {
    timeZone: tz || 'Asia/Shanghai',
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  }).format(now);
  return parts.replace(' ', 'T');
}

function statePath(platform) {
  return path.join(DIR_STATE, `${platform}.json`);
}

function readState(platform) {
  try {
    return JSON.parse(fs.readFileSync(statePath(platform), 'utf8'));
  } catch {
    return null;
  }
}

function writeState(platform, obj) {
  ensureDirs();
  const p = statePath(platform);
  const tmp = p + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), 'utf8');
  fs.renameSync(tmp, p);
}

function appendHistory(platform, rec) {
  ensureDirs();
  fs.appendFileSync(path.join(DIR_HISTORY, `${platform}.jsonl`), JSON.stringify(rec) + '\n', 'utf8');
}

function readHistory(platform, limit = 90) {
  const p = path.join(DIR_HISTORY, `${platform}.jsonl`);
  if (!fs.existsSync(p)) return [];
  const lines = fs.readFileSync(p, 'utf8').split('\n').filter(Boolean);
  return lines.slice(-limit).map((l) => {
    try { return JSON.parse(l); } catch { return null; }
  }).filter(Boolean);
}

// 简单文件锁：拿不到就说明别的进程正在跑
function acquireLock(platform) {
  ensureDirs();
  const p = path.join(DIR_LOCK, `${platform}.lock`);
  try {
    const fd = fs.openSync(p, 'wx');
    fs.writeSync(fd, String(process.pid));
    fs.closeSync(fd);
    return {
      release() { try { fs.unlinkSync(p); } catch {} },
    };
  } catch (e) {
    if (e.code === 'EEXIST') {
      // 锁超过 10 分钟视为陈旧锁
      try {
        const st = fs.statSync(p);
        if (Date.now() - st.mtimeMs > 10 * 60 * 1000) {
          fs.unlinkSync(p);
          const fd = fs.openSync(p, 'wx');
          fs.writeSync(fd, String(process.pid));
          fs.closeSync(fd);
          return { release() { try { fs.unlinkSync(p); } catch {} } };
        }
      } catch {}
      return null;
    }
    throw e;
  }
}

function humanSize(n) {
  if (!Number.isFinite(n) || n < 0) return '-';
  if (n < 1024) return `${n} B`;
  const u = ['KB', 'MB', 'GB', 'TB'];
  let v = n / 1024;
  let i = 0;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(2)} ${u[i]}`;
}

// 依据 free 与阈值给出容量结论
function classifySpace(freeBytes, th) {
  if (!Number.isFinite(freeBytes)) {
    return { status: 'UNKNOWN', level: 'unknown' };
  }
  if (freeBytes <= th.deny_free_bytes) return { status: 'CRITICAL', level: 'deny' };
  if (freeBytes < th.warn_free_bytes) return { status: 'WARNING', level: 'warn' };
  return { status: 'NORMAL', level: 'ok' };
}

module.exports = {
  ROOT, E, KIND, HINT,
  ensureDirs, todayStamp, nowISO,
  readState, writeState, appendHistory, readHistory,
  acquireLock, humanSize, classifySpace,
};
