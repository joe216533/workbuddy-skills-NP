'use strict';
// 平台适配器：夸克 / 百度
// 每个适配器实现 checkSaver / checkLink / doSave / verifyResult
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const { E } = require('./common.js');

function runNode(cli, args, timeout = 60000) {
  try {
    const out = execFileSync(process.execPath, [cli, ...args], {
      encoding: 'utf8', timeout, windowsHide: true,
      maxBuffer: 8 * 1024 * 1024,
      env: { ...process.env, MSYS_NO_PATHCONV: '1' },
    });
    return { ok: true, out };
  } catch (e) {
    const out = String((e.stdout || '') + (e.stderr || ''));
    return { ok: false, out, code: e.code, timedOut: e.killed === true };
  }
}

// 从 CLI 输出里抠出最后一个「业务结果」JSON
// 注意：夸克 browse/share-detail 会额外输出 type=artifact 的行（只含文件落盘信息），
// 必须优先取 type=result，否则会拿到没有 file_list 的那一条。
function lastJson(text) {
  if (!text) return null;
  const lines = text.split(/\r?\n/).filter((l) => l.trim().startsWith('{'));
  const parsed = [];
  for (const l of lines) {
    try { parsed.push(JSON.parse(l)); } catch {}
  }
  if (!parsed.length) {
    try { return JSON.parse(text); } catch {}
    return null;
  }
  for (let i = parsed.length - 1; i >= 0; i--) {
    if (parsed[i] && parsed[i].type === 'result') return parsed[i];
  }
  return parsed[parsed.length - 1];
}

// 把平台原始报错映射成错误码
function mapError(platform, text) {
  const t = String(text || '').toLowerCase();
  if (!t) return E.UNKNOWN_ERROR;
  if (/enotfound|econnrefused|etimedout|econnreset|socket hang up|network/.test(t)) return E.NETWORK_ERROR;
  if (/not logged|未登录|unauthor|登录.*(失效|过期)|token.*(invalid|expired)/.test(t)) return E.AUTH_EXPIRED;
  if (/空间.*(不足|已满)|insufficient|no space|quota.*space|存储空间已不足/.test(t)) return E.SPACE_INSUFFICIENT;
  if (/提取码|passcode|pwd.*(error|invalid)/.test(t)) return E.PASSCODE_INVALID;
  if (/链接.*(失效|无效|不存在)|share.*(invalid|not found|expired)|分享已(取消|失效)/.test(t)) return E.LINK_INVALID;
  if (/频繁|频率|rate.?limit|too many/.test(t)) return E.RATE_LIMITED;
  if (/权限|permission|forbidden|403/.test(t)) return E.PERMISSION_DENIED;
  if (/同名|name.?conflict/.test(t)) return E.NAME_CONFLICT;
  if (/5\d\d|服务异常|server error|internal/.test(t)) return E.PLATFORM_ERROR;
  return E.SAVE_FAILED;
}

// ───────────────────────── 夸克 ─────────────────────────
const quark = {
  id: 'quark',
  label: '夸克网盘',

  checkLocal(cfg) {
    if (!fs.existsSync(cfg.saver_cli)) return { ok: false, error: E.SCRIPT_MISSING };
    return { ok: true };
  },

  checkSaver(cfg) {
    const r = runNode(cfg.saver_cli, ['get-user-info',
      '--session-input', 'keep selfcheck', '--session-id', 'keep-' + Date.now()], 40000);
    const j = lastJson(r.out);
    if (!j || j.code !== 0) {
      return { ok: false, error: mapError('quark', r.out), raw: r.out.slice(-500) };
    }
    const d = j.data || {};
    const total = Number(d.vipInfo?.capacity ?? 0);
    const used = Number(d.vipInfo?.used ?? 0);
    return {
      ok: true,
      nickname: d.userInfo?.nickname ?? null,
      total, used, free: total - used,
    };
  },

  checkLink(cfg) {
    const r = runNode(cfg.saver_cli, ['share-detail',
      '--url', cfg.share_url, '--passcode', cfg.passcode,
      '--session-input', 'keep selfcheck', '--session-id', 'keep-' + Date.now()], 40000);
    const j = lastJson(r.out);
    if (!j || j.code !== 0) {
      return { ok: false, error: mapError('quark', r.out), raw: r.out.slice(-500) };
    }
    const si = j.data?.share_info || {};
    return {
      ok: true,
      title: si.title || null,
      expired_type: si.expired_type,
      expired_days: si.expired_days ?? null,
      file_num: si.file_num ?? null,
    };
  },

  doSave(cfg) {
    const r = runNode(cfg.saver_cli, ['saveas',
      '--url', cfg.share_url, '--passcode', cfg.passcode,
      '--to-pdir-fid', cfg.archive_fid,
      '--session-input', 'keep selfcheck', '--session-id', 'keep-' + Date.now()], 90000);
    const j = lastJson(r.out);
    if (!j || j.code !== 0) {
      return { ok: false, error: mapError('quark', r.out), raw: r.out.slice(-600) };
    }
    const remain = Number(j.data?.save_as?.remain_capacity ?? NaN);
    return {
      ok: true,
      savePath: j.data?.save_path || null,
      remainCapacity: Number.isFinite(remain) ? remain : null,
      notice: j.notice?.text || null,
    };
  },

  verifyResult(cfg, probeName) {
    const r = runNode(cfg.saver_cli, ['browse',
      '--parent-fid', cfg.archive_fid, '--page-size', '50',
      '--session-input', 'keep selfcheck', '--session-id', 'keep-' + Date.now()], 40000);
    const j = lastJson(r.out);
    if (!j || j.code !== 0) {
      return { ok: false, error: mapError('quark', r.out) };
    }
    const list = j.data?.file_list || [];
    const stem = probeName.replace(/\.txt$/, '');
    const hit = list.find((f) => {
      const n = String(f.filename || '');
      return n === probeName || n.startsWith(stem + '(') || n.startsWith(stem + '_');
    });
    if (!hit) return { ok: false, error: E.RESULT_NOT_FOUND };
    return { ok: true, filename: hit.filename, size: hit.size, fid: hit.fid, count: list.length };
  },

  // 夸克 rename 规格：items 文件必须含 schema_version + old_name + new_name
  renameSaved(cfg, saved, newName) {
    const os = require('node:os');
    const pathMod = require('node:path');
    if (!saved?.fid || !saved?.filename) {
      return { ok: false, error: E.SAVE_FAILED, reason: '缺少 fid 或原文件名' };
    }
    if (saved.filename === newName) {
      return { ok: true, unchanged: true, to: newName };
    }
    const items = {
      schema_version: 1,
      items: [{ fid: saved.fid, old_name: saved.filename, new_name: newName }],
    };
    const tmp = pathMod.join(os.tmpdir(), `keep-rename-${Date.now()}.json`);
    try {
      fs.writeFileSync(tmp, JSON.stringify(items), 'utf8');
      const r = runNode(cfg.saver_cli, ['rename',
        '--items-file', tmp,
        '--session-input', 'keep selfcheck', '--session-id', 'keep-' + Date.now()], 60000);
      const j = lastJson(r.out);
      if (!j || j.code !== 0) {
        return { ok: false, error: mapError('quark', r.out), raw: r.out.slice(-400) };
      }
      const d = j.data || {};
      if (d.result_status !== 'SUCCESS') {
        return { ok: false, error: E.SAVE_FAILED, reason: `result_status=${d.result_status}`, raw: r.out.slice(-400) };
      }
      return { ok: true, to: newName, success: d.success_count };
    } finally {
      try { fs.unlinkSync(tmp); } catch {}
    }
  },
};

// ───────────────────────── 百度 ─────────────────────────
const baidu = {
  id: 'baidu',
  label: '百度网盘',

  checkLocal(cfg) {
    if (!fs.existsSync(cfg.saver_cli)) return { ok: false, error: E.SCRIPT_MISSING };
    return { ok: true };
  },

  checkSaver(cfg) {
    const r = runNode(cfg.saver_cli, ['auth', 'status', '--as', cfg.saver_alias, '--json'], 40000);
    const j = lastJson(r.out);
    if (!j || j.ok === false) {
      return { ok: false, error: mapError('baidu', r.out), raw: r.out.slice(-500) };
    }
    const parse = (s) => {
      const m = String(s || '').match(/([\d.]+)\s*(B|KB|MB|GB|TB)/i);
      if (!m) return NaN;
      const mul = { B: 1, KB: 1024, MB: 1048576, GB: 1073741824, TB: 1099511627776 };
      return parseFloat(m[1]) * mul[m[2].toUpperCase()];
    };
    return {
      ok: true,
      nickname: j.account_alias,
      total: parse(j.quota_total),
      used: parse(j.quota_used),
      free: parse(j.quota_free),
    };
  },

  // 百度 CLI 没有 share-detail，链接有效性靠转存步骤判定
  checkLink() {
    return { ok: true, skipped: true, reason: '百度技能无分享详情命令，链接有效性由转存步骤判定' };
  },

  doSave(cfg) {
    const r = runNode(cfg.saver_cli, ['transfer', cfg.share_url,
      '--pwd', cfg.passcode, '--to', cfg.archive_path,
      '--as', cfg.saver_alias, '--json'], 120000);
    const j = lastJson(r.out);
    if (!j || j.ok === false) {
      return { ok: false, error: mapError('baidu', r.out), raw: r.out.slice(-600) };
    }
    return {
      ok: true,
      savePath: j.target_file_path || null,
      fileId: j.target_file_id || null,
      renamed: j.renamed === true,
    };
  },

  verifyResult(cfg, probeName) {
    const r = runNode(cfg.saver_cli, ['list', cfg.archive_path, '--as', cfg.saver_alias, '--json'], 40000);
    const j = lastJson(r.out);
    if (!j || j.ok === false) {
      return { ok: false, error: mapError('baidu', r.out) };
    }
    const items = j.items || [];
    const stem = probeName.replace(/\.txt$/, '');
    const hit = items.find((f) => {
      const n = String(f.name || '');
      return n === probeName || n.startsWith(stem + '(') || n.startsWith(stem + '_');
    });
    if (!hit) return { ok: false, error: E.RESULT_NOT_FOUND };
    return { ok: true, filename: hit.name, size: hit.size, fid: hit.fs_id, count: items.length };
  },

  renameSaved(cfg, saved, newName) {
    if (!saved?.filename) {
      return { ok: false, error: E.SAVE_FAILED, reason: '缺少原文件名' };
    }
    if (saved.filename === newName) {
      return { ok: true, unchanged: true, to: newName };
    }
    const from = `${cfg.archive_path}/${saved.filename}`;
    const r = runNode(cfg.saver_cli, ['rename', from, newName,
      '--as', cfg.saver_alias, '--json'], 60000);
    const j = lastJson(r.out);
    if (!j || j.ok === false) {
      return { ok: false, error: mapError('baidu', r.out), raw: r.out.slice(-400) };
    }
    return { ok: true, to: j.to || newName };
  },
};

module.exports = { quark, baidu, mapError, lastJson };
