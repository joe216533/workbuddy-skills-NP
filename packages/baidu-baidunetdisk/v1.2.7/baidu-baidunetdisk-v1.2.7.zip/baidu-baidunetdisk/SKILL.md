---
name: baidu-baidunetdisk
display_name: "百度网盘操作"
display_name_en: "Baidu Netdisk Ops"
description_zh: "百度网盘操作技能：上传、下载、分享、转存他人分享、受限删除，支持多账号。纯 Node 实现，零第三方依赖。"
description_en: "Baidu Netdisk operations: upload, download, share, save-as, guarded delete, multi-account. Pure Node, zero dependencies."
version: 1.2.7
description: 百度网盘操作技能（Baidu Netdisk），用于上传、下载、分享、转存他人分享、受限删除，支持多账号与永久分享自动带提取码。纯 Node 实现，零第三方依赖，不需要百度开放平台权限，任何电脑装好 Node 18+ 即可使用。当用户要求把文件传到百度网盘、从百度网盘下载文件、生成百度网盘分享链接、转存别人给的百度网盘链接、或多账号切换操作百度网盘时使用。
metadata:
  emoji: "☁️"
  runtime: node
  minNodeVersion: 18.0.0
  requires:
    bins: ["node"]
  platforms: ["win32", "darwin", "linux"]
---

# 百度网盘操作技能（baidu-baidunetdisk）

纯 Node 实现的百度网盘客户端。不使用百度开放平台 API、不申请 access_token、不依赖任何第三方包或预编译二进制。
鉴权走你自己在浏览器里登录后产生的两个 Cookie 字段，因此**任何电脑只要能装 Node 18+ 就能免费使用**。

---

## 一、能力范围

| 能力 | 命令 | 状态 |
|-|-|-|
| 授权（专用浏览器扫码登录） | `auth login --as <别名>` | 支持 |
| 多账号与切换 | `auth use` / `auth status` / `auth logout` / `auth list` | 支持 |
| 列目录 | `list` | 支持 |
| 建目录 | `mkdir` | 支持 |
| 重命名（只改当前层名字，不移动） | `rename` | 支持 |
| 上传（自动分片，命中秒传） | `upload` | 支持 |
| 下载（带 SHA256 校验） | `download` | 支持 |
| 创建分享（永久 / 1 天 / 7 天，自动带提取码） | `share` | 支持 |
| 转存他人分享 | `transfer` | 支持 |
| 删除（严格受限，移入回收站） | `delete` | 支持，见第五节 |
| 撤销自己创建的分享 | 内部能力（`verify --deep` 使用） | 支持，未开放为独立命令 |
| 普通验证 / 深度验证 | `verify` / `verify --deep --yes` | 支持 |

---

## 二、目录结构（换电脑时按这份清单逐项核对）

```
baidu-baidunetdisk/
├── SKILL.md                      本文件：说明、命令、目录、复现步骤
├── manifest.json                 技能 ID、中文显示名、版本、入口、最低 Node 版本
├── package.json                  仅用于固定 CommonJS 模块解析与 npm scripts，无依赖
├── README.md                     安装说明与使用注意事项
├── LICENSE                       本技能自身许可证（MIT）
├── THIRD-PARTY-NOTICES           第三方代码与许可证声明（当前为零依赖）
│
├── scripts/
│   ├── baidu-baidunetdisk.cjs    【唯一入口】解析参数并调度
│   ├── install.js                安装与环境检查（Node 版本、文件完整性、浏览器、数据目录）
│   ├── verify.js                 验证入口，等价于主入口的 verify 命令
│   └── preflight.js              发布前硬门禁（10 项检查，任一 FAIL 不许打包）
│
├── src/
│   ├── cli/
│   │   ├── commands.js           命令注册、参数校验、各命令实现
│   │   └── output.js             统一输出格式（key: value）与 --json
│   ├── auth/
│   │   ├── browser-login.js      专用浏览器授权（可见窗口 + 国内直连 + 临时 Profile）
│   │   ├── credential-store.js   本机凭据安全存储（Win DPAPI / macOS Keychain / Linux Secret Service）
│   │   ├── accounts.js           多账号别名、当前账号、索引文件
│   │   └── session.js            会话建立与授权有效性检查
│   ├── api/
│   │   ├── client.js             请求基础层：cookie、bdstoken、公共参数、响应解析
│   │   ├── signing.js            签名算法参考实现（当前接口不需要，仅备查）
│   │   ├── file-list.js          列目录、分页、stat、递归统计
│   │   ├── mkdir.js              建目录（mkdir -p 语义）
│   │   ├── rename.js             重命名（filemanager?opera=rename）
│   │   ├── upload.js             分片上传 + 空间预判
│   │   ├── share.js              创建分享、撤销分享、分享状态回读
│   │   ├── transfer.js           转存四步链路
│   │   ├── download.js           取直链、流式下载、SHA256 校验
│   │   └── delete.js             删除接口（只被 delete-guard 调用）
│   ├── storage/
│   │   ├── paths.js              路径规范化与安全检查、技能根目录常量
│   │   └── integrity.js          MD5 分片、SHA256、4MB 切块、字节数格式化
│   ├── safety/
│   │   ├── delete-guard.js       【最高风险】删除闸门：路径校验、预览、fs_id 二次核对、删后复查
│   │   ├── upload-guard.js       上传落点保护、同名冲突预检
│   │   └── redaction.js          日志脱敏
│   ├── verify/
│   │   ├── basic.js              普通只读验证（含必备文件清单 REQUIRED）
│   │   └── deep.js               深度端到端验证（专用目录 + 清理复查）
│   └── utils/
│       ├── errors.js             错误码映射、退出码、SkillError
│       ├── logger.js             安全日志（只写 stderr）
│       └── platform.js           跨平台路径、浏览器定位、Node 版本
│
├── docs/
│   ├── architecture.md           模块架构与调用关系
│   ├── security.md               授权、凭据、删除的安全规范
│   ├── protocol-references.md    接口来源与协议参考（含踩坑清单）
│   └── limitations.md            已知限制和未支持能力
│
├── licenses/                     第三方许可证文本目录（当前零依赖，仅放说明）
│
└── tests/                        可离线运行的单元测试（node --test）
    ├── auth.test.js
    ├── upload.test.js
    ├── share.test.js
    ├── transfer.test.js
    ├── download.test.js
    ├── delete.test.js
    └── integrity.test.js
```

### 必备文件与辅助文件

- **必备**（缺失即无法运行）：`scripts/baidu-baidunetdisk.cjs`、`src/` 下全部文件、`manifest.json`、`SKILL.md`
- **辅助**（缺失不影响核心功能）：`tests/`、`docs/`、`scripts/preflight.js`、`README.md`

`src/verify_basic.js` 里的 `REQUIRED` 常量是这份清单的机器可读版本，`install.js` 与 `preflight.js` 都用它核对。

### 文件职责速查

| 文件 | 单一职责 | 出问题先看这里 |
|-|-|-|
| `scripts/baidu-baidunetdisk.cjs` | 进程入口，只做转发 | 命令完全不响应 |
| `src/cli_commands.js` | 参数解析、命令实现 | 参数报错、输出字段不对 |
| `src/cli_output.js` | 输出格式化与脱敏 | 中文乱码、`--json` 结构不对 |
| `src/auth_browser-login.js` | 起浏览器、等登录、取两个字段 | 浏览器打不开、等不到登录 |
| `src/auth_credential-store.js` | 加密存/解密读 | 解密失败、换机后失效 |
| `src/auth_accounts.js` | 别名与当前账号 | 账号切错、别名不认 |
| `src/auth_session.js` | 建会话、验状态 | errno -6 未登录 |
| `src/api_client.js` | 请求基础层 | 所有接口都失败 |
| `src/api_signing.js` | 签名算法（当前不用） | 一般不用管 |
| `src/api_file-list.js` | 列目录、stat、递归 | 路径查不到、目录读不全 |
| `src/api_mkdir.js` | 建目录 | 目录建不出来 |
| `src/api_rename.js` | 重命名 | 改名失败、名字冲突 |
| `src/api_upload.js` | 分片上传 | 上传中断、秒传未命中 |
| `src/api_share.js` | 创建/撤销分享 | 分享链接不对、撤销失败 |
| `src/api_transfer.js` | 转存四步 | errno 140 / 200025 |
| `src/api_download.js` | 取直链、落盘、校验 | 下载无权限、大小不符 |
| `src/api_delete.js` | 删除接口 | 删除结果未知 |
| `src/storage_paths.js` | 路径规范化与安全检查 | 路径被拒、全角冒号问题 |
| `src/storage_integrity.js` | MD5 分片、SHA256 | 校验不一致 |
| `src/safety_delete-guard.js` | 删除十道闸 | 删除被拒、误删风险 |
| `src/safety_upload-guard.js` | 上传落点与冲突 | 同名覆盖、目录越界 |
| `src/safety_redaction.js` | 脱敏 | 日志泄露 |
| `src/verify_basic.js` | 只读验证 + 必备文件清单 | verify 报 FAIL |
| `src/verify_deep.js` | 端到端验证与清理 | 有残留、清理失败 |
| `src/utils_errors.js` | 错误码与退出码 | 提示看不懂、退出码不对 |
| `src/utils_logger.js` | 日志 | 调试信息不够 |
| `src/utils_platform.js` | 跨平台适配 | 找不到浏览器、路径不对 |

### 模块调用关系

```
scripts/baidu-baidunetdisk.cjs
        │
        ▼
src/cli_commands.js ──────► src/auth_session.js ──► src/auth_credential-store.js
        │                        │                   src/auth_accounts.js
        │                        ▼
        │                  src/api_client.js  (cookie + bdstoken)
        │                        │
        ├──► src/api_file-list.js ──► 列目录 / stat / 递归
        ├──► src/api_mkdir.js
        ├──► src/api_upload.js ─────► src/storage_integrity.js
        ├──► src/api_download.js
        ├──► src/api_share.js
        ├──► src/api_transfer.js
        ├──► src/safety_upload-guard.js
        └──► src/safety_delete-guard.js ──► src/api_delete.js
                     │                      src/api_file-list.js
                     └──► src/storage_paths.js（路径合法性）
```

三个安全边界文件互不合并、互不调用：`browser-login.js`（拿凭据）、`credential-store.js`（存凭据）、`delete-guard.js`（删文件）。

---

## 三、安装（换电脑第一步）

```bash
# 1. 确认 Node 版本 >= 18
node -v

# 2. 环境检查（不需要 npm install，本技能零依赖）
node scripts/install.js
```

`install.js` 会检查：Node 版本、必备文件完整性、浏览器是否可用、本机数据目录能否创建，并打印凭据存储方式。

浏览器要求：Chrome 或 Edge。找不到时可用环境变量指定：

```bash
BD_CHROME_PATH="C:\Program Files\Google\Chrome\Application\chrome.exe" node scripts/install.js
```

---

## 四、命令清单

统一入口：`node scripts/baidu-baidunetdisk.cjs`

> 所有命令都必须带 `baidu-baidunetdisk.cjs` 这个入口名，不要写成裸 `list`，避免被误认为系统命令或夸克技能的命令。

### 4.1 授权与账号

```bash
node scripts/baidu-baidunetdisk.cjs auth login --as 159
node scripts/baidu-baidunetdisk.cjs auth login --as 156
node scripts/baidu-baidunetdisk.cjs auth status --as 159
node scripts/baidu-baidunetdisk.cjs auth use 159
node scripts/baidu-baidunetdisk.cjs auth logout --as 159
node scripts/baidu-baidunetdisk.cjs auth list
```

- 别名由使用者指定，技能**不会**自动读取百度昵称（昵称含个人信息、会变、会重名）。
- `auth login` 会打开一个**可见窗口**的独立浏览器，请在该窗口里扫码登录；登录成功后程序自动取凭据并关闭浏览器。
- 这个浏览器单独走国内直连（`--proxy-server=direct://`），**开了 VPN 也只需要让这个浏览器直连，不需要关掉全局 VPN**。
- 输出字段：`account_alias`、`login_status`、`authorization_status`、`credential_store`、`last_verified_at`、`quota_total`、`quota_used`。

### 4.2 文件与目录

```bash
node scripts/baidu-baidunetdisk.cjs list /
node scripts/baidu-baidunetdisk.cjs list "/来自：WorkBuddy/baidu-baidunetdisk" --as 159
node scripts/baidu-baidunetdisk.cjs mkdir "/来自：WorkBuddy/baidu-baidunetdisk" --as 159
node scripts/baidu-baidunetdisk.cjs upload ./测试文件.zip --to "/来自：WorkBuddy/baidu-baidunetdisk" --as 159
node scripts/baidu-baidunetdisk.cjs download "/来自：WorkBuddy/baidu-baidunetdisk/测试文件.zip" --to ./downloads --as 159
```

- `upload` 输出：`local_path`、`remote_path`、`remote_file_id`、`file_name`、`file_size`、`upload_status`、`upload_method`（`normal` 或 `instant` 秒传）、`part_count`、`sha256`。
- `download` 输出：`remote_path`、`local_path`、`file_name`、`file_size`、`download_status`、`sha256`。
- 上传前会预判空间：剩余容量不足时**直接拒绝并提示清理网盘（含清空回收站）**，不会等半天再失败。
- 目标已存在同名文件时默认**不覆盖**，明确提示；确需覆盖加 `--force`。

### 4.3 分享与转存

```bash
node scripts/baidu-baidunetdisk.cjs share "/来自：WorkBuddy/baidu-baidunetdisk/测试文件.zip" --period 0 --as 159
node scripts/baidu-baidunetdisk.cjs transfer "https://pan.baidu.com/s/1xxxxxxx" --pwd abcd --to "/来自：WorkBuddy/baidu-baidunetdisk" --as 156
```

- `--period 0` 永久有效（默认），`1` 一天，`7` 七天。
- 提取码由技能生成 4 位，`full_url` 形如 `https://pan.baidu.com/s/1xxxx?pwd=abcd`，**别人打开这个链接会自动填好提取码**。
- `share` 输出：`share_id`、`short_url`、`full_url`、`password`、`period`、`period_text`、`expired_type`、`expire_time`、`share_status`。
- `transfer` 支持链接里自带 `?pwd=`，也可以显式 `--pwd`。
- `transfer` 输出：`source_share_url`、`source_file_name`、`source_file_count`、`target_path`、`target_file_path`、`target_file_id`、`renamed`、`transfer_status`。
- **`target_file_path` 是服务端实际落点**：目标目录已有同名文件时，百度会自动改名成 `xxx(1).zip`，此时 `renamed` 为 true。不要假设落点一定是"目标目录 + 原文件名"。

### 4.4 验证

```bash
node scripts/baidu-baidunetdisk.cjs verify                    # 只读，不产生任何文件
node scripts/baidu-baidunetdisk.cjs verify --deep --yes --as 159  # 端到端，会产生并删除测试文件
```

- 普通验证检查：Node 版本、文件完整性、manifest 版本、凭据可读性、账号授权、接口可达、根目录可读。
- 未执行的项目一律输出 `SKIP`，**绝不假报 PASS**。
- 深度验证只在专用目录 `/来自：WorkBuddy/baidu-baidunetdisk/.verify/` 内进行，流程是：
  上传 → 回读确认 → 创建 1 天分享 → 验证分享可读 → 下载 → SHA256 对照 → 撤销分享 → 删除 → 复查清理。
- **清理失败会让整体判定 FAIL**，不会因为前面几步成功就报告通过。
- 失败时会列出：哪一步失败、哪些临时资产已清理、哪些未清理、是否有残留分享。

---

### 4.5 启动自检（技能自带）

本技能内置启动自检：**每天第一次调用业务命令时，自动执行一次真实云端保存**，把包内默认的 1KB 测试文件从独立测试资源账号转存到当前已授权账号，并核验本次云端结果。当天只有 `PASS` 会去重；`NEEDS_AUTH` / `BLOCKED` / `FAIL` / `ERROR` 允许条件变化后重试。

**去重之前先做一次本地环境预检（不联网）**：解析当前真正会被执行的 CLI 路径（含用户私有配置覆盖的结果），文件不存在就直接报 `CLI_MISSING` / `NEEDS_CONFIG`，退出码 4，**不会**因为今天早些时候 PASS 过就返回 `DONE_TODAY`。理由：`DONE_TODAY` 表示“今天验过了”，不能用来证明“当前环境仍然可用”。

```bash
# 手动执行（自动执行失败时用它排查）
node scripts/baidu-baidunetdisk.cjs selfcheck
node scripts/baidu-baidunetdisk.cjs selfcheck --json

# 当天已经 PASS 过、但你想强制复核一次真实链路（会真的转存一次）
node scripts/baidu-baidunetdisk.cjs selfcheck --force
node scripts/baidu-baidunetdisk.cjs selfcheck --force --json

# 两个平台一起自检（本包只自带百度，夸克会判 NEEDS_CONFIG）
node scripts/baidu-baidunetdisk.cjs selfcheck --platform all

# 查看状态与历史
node scripts/baidu-baidunetdisk.cjs selfcheck status
node scripts/baidu-baidunetdisk.cjs selfcheck history
```

六步检查与状态：

| 步骤 | 检查内容 | 未完成状态 |
|-|-|-|
| ① 本地状态 | 技能脚本是否可用 | `NEEDS_CONFIG` |
| ② 保存方账号 | 授权账号与容量；未授权标记 `NEEDS_AUTH` | `NEEDS_AUTH` |
| ③ 测试分享源 | 包内默认公开测试资源；百度由第④步判定 | `NOT_RUN` / `FAIL` |
| ④ 真实云端保存 | 实际转存一次 1KB 文件 | `FAIL` / `BLOCKED` / `ERROR` |
| ⑤ 云端结果核验 | 必须核验本次转存返回的云端文件 ID，不认历史同名文件 | `FAIL` |
| ⑥ 文件整理与记录 | 改名为 `可删除_YYYYMMDD_自检副本`；撞名自动加 `_2`..`_4` 再退到时间戳；失败标 `WARN`（不影响保存结论） | `PASS` / `WARN` / `NOT_RUN` |

最终状态：`PASS` / `FAIL` / `BLOCKED` / `NEEDS_AUTH` / `NEEDS_CONFIG` / `ERROR` / `NOT_RUN`。**不再有“未配置就静默跳过”。**

公开测试分享链接、提取码、测试文件名与大小随包内置，位于 `src/selfcheck_config.default.json`。本机私有配置只保存账号别名、CLI 路径与归档目录等机器相关字段，且完全可选：

```bash
# 可选；不创建也能自检
mkdir -p ~/.workbuddy/keep-agent
cp src/selfcheck_config.example.json ~/.workbuddy/keep-agent/config.json
```

状态与历史：

```
~/.workbuddy/keep-agent/
├── config.json               可选的本机私有覆盖，禁止提交或分发
├── state/baidu.json          当日状态
└── history/baidu.jsonl       历史记录（含 status / executionId / agentVersion / skillVersion / errorCode）
```

> 公开测试资源可以随包分发；账号凭据、登录态与本机 CLI 路径不得进入技能包或公共仓库。

## 五、删除的安全限制（硬规则，没有绕过开关）

删除是显式操作，不允许被"整理网盘""清理旧文件"这类模糊意图自动触发。

| 规则 | 具体要求 |
|-|-|
| 绝对路径 | 只接受以 `/` 开头的规范化路径 |
| 禁通配符 | 含 `* ? [ ] { }` 一律拒绝 |
| 禁根目录 | `/`、空路径一律拒绝 |
| 目录限制 | 只允许删 `/来自：WorkBuddy/baidu-baidunetdisk` **之下**的内容，不允许删该目录本身 |
| 必须 `--yes` | 没有 `--yes` 只输出预览，不执行 |
| 递归需显式 | 非空目录必须额外加 `--recursive` |
| 预览清单 | 执行前列出文件名、大小、修改时间、`fs_id`、数量、总大小 |
| 二次核对 | 执行前重新读取目标，`fs_id` 与大小必须与预览一致，否则中止 |
| 删后复查 | 删除后重新 list，确认目标消失才算成功 |
| 结果未知不报成功 | 网络中断等"请求已发出但没拿到结果"的情况标记为未知，要求先 list 复核 |

```bash
# 删单个文件
node scripts/baidu-baidunetdisk.cjs delete "/来自：WorkBuddy/baidu-baidunetdisk/test.zip" --yes --as 159

# 删非空目录
node scripts/baidu-baidunetdisk.cjs delete "/来自：WorkBuddy/baidu-baidunetdisk/test-folder" --recursive --yes --as 159
```

删除后对象进入**网页端回收站**，可以在 pan.baidu.com 恢复；但回收站内容**仍然占用容量**，需要腾空间时请到网页端清空回收站。

---

## 六、授权与凭据安全

| 项目 | 做法 |
|-|-|
| 浏览器 | 独立 Chrome 实例 + 独立临时 Profile，不碰日常浏览器；窗口可见，由本人扫码登录 |
| 网络 | `--proxy-server=direct://` + `--proxy-bypass-list=*`，只让这个浏览器直连，不影响全局 VPN |
| 调试端口 | CDP 只监听 `127.0.0.1` 随机端口 |
| 提取范围 | 只取 `BDUSS`（`.baidu.com` 域）与 `STOKEN`（`.pan.baidu.com` 域）两个字段，其余全部丢弃 |
| 存储 | Windows：DPAPI CurrentUser 加密到 `%LOCALAPPDATA%\baidu-baidunetdisk\accounts\<别名>.cred`；macOS：登录钥匙串；Linux：Secret Service，无 `secret-tool` 时降级为 0600 权限文件并明确警告 |
| 明文 | 只在内存与 stdin 中传递，不落盘 |
| 清理 | 取完凭据立即关闭浏览器并删除临时 Profile |
| 多账号 | 每个账号独立凭据文件，`auth logout --as 159` 不影响 156；授权失效时**不会**自动切到另一个账号 |

**不能把 `.cred` 文件或浏览器 Profile 复制到其他电脑。** DPAPI 绑定当前 Windows 用户，换用户名或换机器都无法解密，必须在本机重新 `auth login`。

---

## 七、换机复现步骤

在任意一台新电脑上，按这个顺序做，全部通过即视为复现成功：

```bash
# 1. 拷入技能目录（只拷代码，不要拷凭据）
node -v                                   # 需要 >= v18
node scripts/install.js                   # 应输出「安装检查通过」

# 2. 授权两个账号
node scripts/baidu-baidunetdisk.cjs auth login --as 159
node scripts/baidu-baidunetdisk.cjs auth login --as 156

# 3. 确认隔离
node scripts/baidu-baidunetdisk.cjs auth list
node scripts/baidu-baidunetdisk.cjs auth status --as 159
node scripts/baidu-baidunetdisk.cjs auth status --as 156

# 4. 只读验证
node scripts/baidu-baidunetdisk.cjs verify --as 159

# 5. 业务能力
node scripts/baidu-baidunetdisk.cjs list / --as 159
node scripts/baidu-baidunetdisk.cjs upload ./某个文件.txt --to "/来自：WorkBuddy/baidu-baidunetdisk" --as 159
node scripts/baidu-baidunetdisk.cjs share "/来自：WorkBuddy/baidu-baidunetdisk/某个文件.txt" --period 0 --as 159
node scripts/baidu-baidunetdisk.cjs transfer "<上一步的链接>" --pwd <提取码> --to "/来自：WorkBuddy/baidu-baidunetdisk" --as 156
node scripts/baidu-baidunetdisk.cjs download "/来自：WorkBuddy/baidu-baidunetdisk/某个文件.txt" --to ./downloads --as 156

# 6. 删除安全（应当先被拒绝、再加 --recursive 和 --yes 才成功）
node scripts/baidu-baidunetdisk.cjs delete "/来自：WorkBuddy/baidu-baidunetdisk/test-folder" --yes      # 预期被拒绝：非空目录需 --recursive
node scripts/baidu-baidunetdisk.cjs delete "/" --yes --recursive                                        # 预期被拒绝：禁止根目录
node scripts/baidu-baidunetdisk.cjs delete "/来自：WorkBuddy/baidu-baidunetdisk/test-folder" --recursive --yes

# 7. 端到端
node scripts/baidu-baidunetdisk.cjs verify --deep --yes --as 159
```

每一步的预期结果都写在上面的注释里。任何一步与预期不符，先看 `docs/limitations.md` 与 `docs/protocol-references.md`。

---

## 八、常见错误与处理

| 报错 | 含义 | 处理 |
|-|-|-|
| `NOT_LOGIN` / errno -6 | 登录态失效 | 重新 `auth login --as <别名>` |
| `NO_SPACE` / errno 12 + 子错误 -32 | 网盘空间不足，本次未写入 | 清理网盘，**回收站也要清空**，或换有余量的账号 |
| `NAME_CONFLICT` / errno 12 + 子错误 -30 | 同名文件冲突 | 改名、先删旧文件，或加 `--force` |
| `CRED_UNDECRYPTABLE` | 凭据无法解密（换了 Windows 用户或复制了别机凭据） | 本机重新授权 |
| `NO_BROWSER` | 找不到 Chrome/Edge | 安装 Chrome，或设 `BD_CHROME_PATH` |
| `REFUSED_*` | 删除被安全闸门拒绝 | 看提示，通常是要加 `--recursive` 或路径不在允许范围 |
| `BAD_PWD` / errno -9 / 200025 | 提取码不对 | 确认链接里的 4 位提取码 |
| `BAD_SHARE_URL` / errno 140 | 分享链接无效或已取消 | 找分享方重新发 |
| `NEED_VCAPTCHA` / errno 105 | 分享要求图形验证码 | 手动在浏览器打开链接转存 |

---

## 九、已知限制

- 不支持下载整个目录（只支持单文件下载），需要时先 `list` 后逐个下载。
- 不支持在线解压、重命名、移动、复制。
- 撤销分享目前只在 `verify --deep` 内部使用，未开放为独立命令。
- 分享提取码固定 4 位（百度限制），不能取消提取码。
- 部分他人分享要求图形验证码，无法自动转存。
- 不支持同步盘、秒传链接（`bdpan://`）解析。
