#!/usr/bin/env node
'use strict';
// 唯一 CLI 入口：解析参数并调度（所有业务逻辑在 src/ 里）
const path = require('node:path');
const { run } = require(path.join(__dirname, '..', 'src', 'cli', 'commands.js'));

run(process.argv.slice(2))
  .then((code) => {
    process.exitCode = code;
  })
  .catch((e) => {
    process.stderr.write(`[FATAL] ${e && e.stack ? e.stack : e}\n`);
    process.exitCode = 1;
  });
