#!/usr/bin/env node
'use strict';
// 验证入口：node scripts/verify.js [--deep --yes] [--as 别名] [--json]
const path = require('node:path');
const { run } = require(path.join(__dirname, '..', 'src', 'cli', 'commands.js'));

run(['verify', ...process.argv.slice(2)])
  .then((code) => {
    process.exitCode = code;
  })
  .catch((e) => {
    process.stderr.write(`[FATAL] ${e && e.stack ? e.stack : e}\n`);
    process.exitCode = 1;
  });
