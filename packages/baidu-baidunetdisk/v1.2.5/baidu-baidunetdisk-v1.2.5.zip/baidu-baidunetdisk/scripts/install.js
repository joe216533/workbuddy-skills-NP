#!/usr/bin/env node
'use strict';
// 安装与运行环境准备。本技能零第三方依赖，不需要 npm install。
const fs = require('node:fs');
const path = require('node:path');
const { nodeMajor, findChrome, dataDir, ensureDataDir, isWin, isMac, isLinux } = require('../src/utils/platform');
const { REQUIRED, MIN_NODE_MAJOR } = require('../src/verify/basic');
const { storeKind } = require('../src/auth/credential-store');

const ROOT = path.resolve(__dirname, '..');
const out = [];

function line(k, v) {
  out.push(`${k.padEnd(24)} : ${v}`);
}

line('技能目录', ROOT);
line('Node 版本', process.version);
line('平台', `${process.platform} ${process.arch}`);
line('本机数据目录', dataDir());
line('凭据存储方式', storeKind());

let ok = true;

// 1. Node 版本
if (nodeMajor() < MIN_NODE_MAJOR) {
  line('Node 检查', `FAIL — 需要 v${MIN_NODE_MAJOR} 或更高（当前 ${process.version}）。请升级 Node.js 后重试。`);
  ok = false;
} else {
  line('Node 检查', 'PASS');
}

// 2. 文件完整性
const missing = REQUIRED.filter((rel) => !fs.existsSync(path.join(ROOT, rel)));
const empty = REQUIRED.filter((rel) => fs.existsSync(path.join(ROOT, rel)) && fs.statSync(path.join(ROOT, rel)).size === 0);
if (missing.length || empty.length) {
  line('文件完整性', `FAIL — 缺失 ${missing.length} 个、空文件 ${empty.length} 个${missing.length ? '：' + missing.join(',') : ''}`);
  ok = false;
} else {
  line('文件完整性', `PASS（${REQUIRED.length} 个必备文件齐全）`);
}

// 3. 浏览器
const chrome = findChrome();
if (chrome) line('浏览器', `PASS — ${chrome}`);
else {
  line('浏览器', 'WARN — 未找到 Chrome/Edge。授权前请安装 Chrome，或设置环境变量 BD_CHROME_PATH 指向浏览器可执行文件。');
}

// 4. 数据目录
try {
  const d = ensureDataDir();
  line('数据目录', `PASS — ${d}`);
} catch (e) {
  line('数据目录', `FAIL — ${e.message}`);
  ok = false;
}

// 5. 平台凭据存储可用性提示
if (isWin) line('凭据方案', 'Windows DPAPI（绑定当前用户，不能复制到其他电脑）');
else if (isMac) line('凭据方案', 'macOS 登录钥匙串');
else if (isLinux) line('凭据方案', storeKind() === 'linux-secret-service' ? 'Linux Secret Service' : '降级：0600 权限文件（建议安装 libsecret）');

out.push('');
out.push(ok ? '安装检查通过。下一步：node scripts/baidu-baidunetdisk.cjs auth login --as <别名>' : '安装检查未通过，请先处理上面标记 FAIL 的项目。');
process.stdout.write(out.join('\n') + '\n');
process.exitCode = ok ? 0 : 1;
