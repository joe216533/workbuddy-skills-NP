# licenses/

本目录用于存放**第三方代码的许可证原文**。

当前本技能为零第三方运行时依赖（详见上一级 `THIRD-PARTY-NOTICES`），
因此本目录暂不存放任何许可证文本。

## 命名约定

如果将来引入第三方代码，许可证文本按 SPDX 标识命名放入本目录：

```
licenses/MIT.txt
licenses/Apache-2.0.txt
licenses/BSD-3-Clause.txt
```

同时在 `THIRD-PARTY-NOTICES` 补一节，写明组件名、版本、来源、许可证、用途、是否修改。

`scripts/preflight.js` 会检查：只要 `package.json` 里出现依赖，或源码里出现第三方版权头，
本目录就必须有对应的许可证文本，否则发布门禁直接 FAIL。
