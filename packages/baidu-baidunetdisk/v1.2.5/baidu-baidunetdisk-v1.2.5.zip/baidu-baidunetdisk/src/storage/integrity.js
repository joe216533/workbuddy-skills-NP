'use strict';
// 文件大小与哈希校验
const fs = require('node:fs');
const crypto = require('node:crypto');

const CHUNK = 4 * 1024 * 1024; // 百度分片上传固定 4MB

function sha256Buffer(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function sha256File(filePath) {
  const h = crypto.createHash('sha256');
  const fd = fs.openSync(filePath, 'r');
  try {
    const buf = Buffer.allocUnsafe(1024 * 1024);
    let n;
    while ((n = fs.readSync(fd, buf, 0, buf.length, null)) > 0) {
      h.update(buf.subarray(0, n));
    }
  } finally {
    fs.closeSync(fd);
  }
  return h.digest('hex');
}

function md5Buffer(buf) {
  return crypto.createHash('md5').update(buf).digest('hex');
}

// 按 4MB 切分并返回每片 MD5 与总大小（precreate 的 block_list 要用）
function splitBlocks(filePath) {
  const size = fs.statSync(filePath).size;
  const buf = fs.readFileSync(filePath);
  const blocks = [];
  const list = [];
  const limit = Math.max(size, 1);
  for (let off = 0; off < limit; off += CHUNK) {
    const chunk = buf.subarray(off, Math.min(off + CHUNK, size));
    blocks.push(chunk);
    list.push(md5Buffer(chunk));
  }
  return { size, buf, blocks, blockList: list };
}

function humanSize(bytes) {
  const n = Number(bytes || 0);
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${i === 0 ? v : v.toFixed(2)} ${units[i]}`;
}

module.exports = { CHUNK, sha256Buffer, sha256File, md5Buffer, splitBlocks, humanSize };
