'use strict';
// 网盘路径规范化与安全检查。所有对外路径统一 UTF-8，全角冒号等字符原样保留，
// 编码只在协议层（URLSearchParams）处理。

// 技能专属根目录：删除默认只允许在此目录内。全角冒号为既有资产习惯，不改为 ASCII。
const SKILL_ROOT = '/来自：WorkBuddy/baidu-baidunetdisk';
const VERIFY_DIR = SKILL_ROOT + '/.verify';

const WILDCARD = /[*?[\]{}]/;

// 规范化：补前导 /、折叠重复 /、消解 . 与 ..、去尾 /（根目录除外）
function normalize(input) {
  if (typeof input !== 'string') throw new TypeError('路径必须是字符串');
  let s = input.trim();
  if (!s) return '/';
  s = s.replace(/\\/g, '/');
  if (!s.startsWith('/')) s = '/' + s;
  const parts = [];
  for (const seg of s.split('/')) {
    if (!seg || seg === '.') continue;
    if (seg === '..') {
      if (parts.length === 0) throw new Error('路径越界：不得使用 .. 跳出根目录');
      parts.pop();
      continue;
    }
    parts.push(seg);
  }
  return '/' + parts.join('/');
}

function assertAbsolute(input) {
  const s = String(input || '');
  if (!s.startsWith('/')) {
    throw new Error(`必须是网盘绝对路径（以 / 开头），收到：${input}`);
  }
  return normalize(s);
}

function hasWildcard(input) {
  return WILDCARD.test(String(input || ''));
}

function isRoot(p) {
  return normalize(p) === '/';
}

// p 是否在 root 之下（含 root 本身）
function isUnder(p, root) {
  const a = normalize(p);
  const b = normalize(root);
  return a === b || a.startsWith(b + '/');
}

function basename(p) {
  const n = normalize(p);
  if (n === '/') return '';
  return n.slice(n.lastIndexOf('/') + 1);
}

function dirname(p) {
  const n = normalize(p);
  if (n === '/') return '/';
  const i = n.lastIndexOf('/');
  return i <= 0 ? '/' : n.slice(0, i);
}

function join(dir, name) {
  const d = normalize(dir);
  return d === '/' ? '/' + name : d + '/' + name;
}

// 递归深度上限，防止异常目录把 list 打爆
const MAX_DEPTH = 12;

module.exports = {
  SKILL_ROOT,
  VERIFY_DIR,
  MAX_DEPTH,
  normalize,
  assertAbsolute,
  hasWildcard,
  isRoot,
  isUnder,
  basename,
  dirname,
  join,
};
