'use strict';
// 错误码映射与统一错误类型。原则：失败绝不报成功，且必须给出下一步动作。

// 退出码约定（智能体可据此分支处理）
const EXIT = {
  OK: 0,
  GENERAL: 1,
  USAGE: 2,
  NO_ACCOUNT: 3,
  REFUSED: 4, // 被安全闸门拒绝
  VERIFY_FAIL: 5,
  NO_SPACE: 6,
  NOT_LOGGED_IN: 7,
};

class SkillError extends Error {
  constructor(code, text, extra = {}) {
    super(text);
    this.name = 'SkillError';
    this.code = code;
    this.text = text;
    Object.assign(this, extra);
  }
}

// 百度 errno → 用户可读提示
function explain(errno, resp) {
  const info = (resp && resp.info) || [];
  const sub = Array.isArray(info) ? info.find((x) => x && x.errno && x.errno !== 0) : null;
  const showMsg = (resp && (resp.show_msg || resp.err_msg)) || '';

  // 空间不足：errno 12 + 子错误 -32（实测 156 超容时就是这个组合）
  if (errno === 12 && ((sub && sub.errno === -32) || /空间不足|剩余空间/.test(showMsg))) {
    return {
      code: 'NO_SPACE',
      exit: EXIT.NO_SPACE,
      text: '百度网盘空间不足，本次没有写入任何内容。请先清理网盘腾出空间（网页端回收站也要清空，删除的文件仍占容量），或换一个有余量的账号后重试。',
    };
  }
  // 同名冲突：errno 12 + 子错误 -30，必须与空间不足区分开
  if (errno === 12 && sub && sub.errno === -30) {
    return { code: 'NAME_CONFLICT', exit: EXIT.GENERAL, text: '目标目录已存在同名文件，本次未覆盖。请先改名或先删除旧文件。' };
  }

  const map = {
    0: { code: 'OK', exit: EXIT.OK, text: '成功' },
    '-6': { code: 'NOT_LOGIN', exit: EXIT.NOT_LOGGED_IN, text: '登录状态已失效。请重新授权：auth login --as <别名>（换电脑、长期未用、或网页端退出过都会导致失效）。' },
    '-7': { code: 'BAD_PATH', exit: EXIT.GENERAL, text: '路径不存在或参数不合法，请检查网盘路径是否写对。' },
    '-8': { code: 'ALREADY_EXISTS', exit: EXIT.GENERAL, text: '目录已存在，无需重复创建。' },
    '-9': { code: 'BAD_PWD', exit: EXIT.GENERAL, text: '提取码不正确，请确认链接中的 4 位提取码。' },
    2: { code: 'EXISTS_OR_PARAM', exit: EXIT.GENERAL, text: '同名文件已存在或参数错误，本次未写入。' },
    12: { code: 'PARTIAL_FAIL', exit: EXIT.GENERAL, text: '部分内容未能写入，请查看逐项结果。' },
    105: { code: 'NEED_VCAPTCHA', exit: EXIT.GENERAL, text: '该分享要求图形验证码，无法自动完成，请手动在浏览器打开链接转存。' },
    113: { code: 'SIGN_ERROR', exit: EXIT.GENERAL, text: '下载签名失效，重试一次通常即可恢复。' },
    140: { code: 'BAD_SHARE_URL', exit: EXIT.GENERAL, text: '分享链接无效或已被取消，请向分享方确认链接是否还有效。' },
    190: { code: 'SHARE_EXPIRED', exit: EXIT.GENERAL, text: '分享已过期。' },
    200025: { code: 'BAD_PWD', exit: EXIT.GENERAL, text: '提取码不匹配，请确认链接中的 4 位提取码。' },
    31326: { code: 'NO_OPEN_API', exit: EXIT.GENERAL, text: '该接口需要开放平台授权，纯登录态不可用（本技能不走这条路）。' },
  };
  const hit = map[String(errno)];
  if (hit) return { ...hit, sub: sub || null, showMsg };
  return {
    code: 'UNKNOWN',
    exit: EXIT.GENERAL,
    text: `操作失败（errno ${errno}${sub ? '，子错误 ' + sub.errno : ''}${showMsg ? '，' + showMsg : ''}），本次没有写入任何内容。`,
    sub: sub || null,
    showMsg,
  };
}

// 断言：errno 必须为 0，否则抛 SkillError
function ok(errno, resp, what) {
  if (errno === 0) return resp;
  const e = explain(errno, resp);
  throw new SkillError(e.code, `${what ? what + '：' : ''}${e.text}`, { errno, exit: e.exit });
}

module.exports = { EXIT, SkillError, explain, ok };
