'use strict';
// 操作系统与运行环境适配（路径、浏览器定位、Node 版本门槛）
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const isWin = process.platform === 'win32';
const isMac = process.platform === 'darwin';
const isLinux = process.platform === 'linux';

const APP_DIR_NAME = 'baidu-baidunetdisk';

// 各平台本机数据目录（凭据与账号索引都放这里，不放进技能包目录，避免打包泄露）
function dataDir() {
  if (isWin) {
    const base = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return path.join(base, APP_DIR_NAME);
  }
  if (isMac) {
    return path.join(os.homedir(), 'Library', 'Application Support', APP_DIR_NAME);
  }
  const base = process.env.XDG_DATA_HOME || path.join(os.homedir(), '.local', 'share');
  return path.join(base, APP_DIR_NAME);
}

function ensureDataDir() {
  const d = dataDir();
  fs.mkdirSync(d, { recursive: true, mode: 0o700 });
  return d;
}

// 专用浏览器定位：优先环境变量 BD_CHROME_PATH，其次常见安装路径
function findChrome() {
  const env = process.env.BD_CHROME_PATH;
  if (env && fs.existsSync(env)) return env;

  const cands = [];
  if (isWin) {
    cands.push(
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
      process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'Application', 'chrome.exe') : '',
      'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
      'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'
    );
  } else if (isMac) {
    cands.push(
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
      '/Applications/Chromium.app/Contents/MacOS/Chromium'
    );
  } else {
    cands.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge');
  }
  for (const c of cands.filter(Boolean)) {
    if (fs.existsSync(c)) return c;
  }
  return null;
}

function nodeMajor() {
  return Number(process.versions.node.split('.')[0]);
}

module.exports = { isWin, isMac, isLinux, dataDir, ensureDataDir, findChrome, nodeMajor, APP_DIR_NAME };
