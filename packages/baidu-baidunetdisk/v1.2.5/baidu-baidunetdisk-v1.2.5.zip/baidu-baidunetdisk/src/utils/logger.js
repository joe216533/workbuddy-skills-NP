'use strict';
// 安全日志：只写 stderr，不写本地文件，全部经脱敏
const { redact } = require('../safety/redaction');

const DEBUG = /^(1|true|yes)$/i.test(String(process.env.BD_DEBUG || ''));

function stamp() {
  return new Date().toISOString().replace('T', ' ').slice(0, 19);
}

function emit(level, msg) {
  const line = `[${stamp()}] [${level}] ${redact(String(msg))}`;
  process.stderr.write(line + '\n');
}

module.exports = {
  debug(msg) {
    if (DEBUG) emit('DEBUG', msg);
  },
  info(msg) {
    emit('INFO', msg);
  },
  warn(msg) {
    emit('WARN', msg);
  },
  error(msg) {
    emit('ERROR', msg);
  },
  step(msg) {
    emit('STEP', msg);
  },
};
