'use strict';
// 分片上传：precreate → superfile2(逐片) → create
// 秒传命中时 return_type=2，直接 create；真正成功与否一律以 create 的 errno 为准。
const fs = require('node:fs');
const path = require('node:path');
const { splitBlocks, sha256File } = require('../storage/integrity');
const { SkillError, explain } = require('../utils/errors');
const { normalize, join, basename } = require('../storage/paths');
const log = require('../utils/logger');

// 上传前预判空间：宁可提前拒绝，也不要用户等半天才失败
async function checkSpace(client, needBytes) {
  const q = await client.quota();
  if (!q || q.errno !== 0) return { known: false };
  const total = Number(q.total || 0);
  const used = Number(q.used || 0);
  const free = total - used;
  return { known: true, total, used, free, enough: free >= needBytes };
}

async function precreate(client, remotePath, size, blockList) {
  const r = await client.api('/api/precreate', {}, new URLSearchParams({
    path: remotePath,
    size: String(size),
    isdir: '0',
    autoinit: '1',
    block_list: JSON.stringify(blockList),
    rtype: '3',
    contentCrc32: '0',
  }).toString());
  return r.j || {};
}

async function uploadPart(client, remotePath, uploadid, seq, chunk) {
  const form = new FormData();
  form.append('file', new Blob([chunk]), 'blob');
  const url = `https://c3.pcs.baidu.com/rest/2.0/pcs/superfile2?${client.q({
    method: 'upload',
    type: 'tmpfile',
    path: remotePath,
    partseq: String(seq),
    uploadid,
  })}`;
  const r = await fetch(url, { method: 'POST', headers: client.hdr(), body: form });
  const text = await r.text();
  let j = null;
  try {
    j = JSON.parse(text);
  } catch {
    /* ignore */
  }
  if (j && j.error_code) {
    const e = explain(j.error_code, j);
    throw new SkillError(e.code, `第 ${seq} 个分片上传失败：${e.text}`, { errno: j.error_code, exit: e.exit });
  }
  if (!j) {
    throw new SkillError('PART_BAD_RESPONSE', `第 ${seq} 个分片返回非 JSON（HTTP ${r.status}）：${text.slice(0, 200)}`);
  }
  return j;
}

/**
 * 上传单个本地文件到网盘目录
 * @returns {Promise<{remote_path,file_name,file_size,upload_method,fs_id,md5,sha256}>}
 */
async function uploadFile(client, localPath, remoteDir, { skipSpaceCheck = false } = {}) {
  if (!fs.existsSync(localPath)) throw new SkillError('NO_LOCAL_FILE', `本地文件不存在：${localPath}`);
  const st = fs.statSync(localPath);
  if (!st.isFile()) throw new SkillError('NOT_A_FILE', `不是普通文件：${localPath}`);

  const dir = normalize(remoteDir);
  const name = path.basename(localPath);
  const remotePath = join(dir, name);

  if (!skipSpaceCheck) {
    const sp = await checkSpace(client, st.size);
    if (sp.known && !sp.enough) {
      throw new SkillError(
        'NO_SPACE',
        `百度网盘空间不足，本次没有上传。当前账号总容量 ${(sp.total / 1024 ** 3).toFixed(1)} GiB，已用 ${(sp.used / 1024 ** 3).toFixed(1)} GiB，剩余不足 ${(st.size / 1024 ** 2).toFixed(1)} MB。请先清理网盘腾出空间（网页端回收站也要清空，删除的文件仍占容量），或换一个有余量的账号后重试。`,
        { exit: 6, space: sp }
      );
    }
  }

  const { size, blocks, blockList } = splitBlocks(localPath);
  const pre = await precreate(client, remotePath, size, blockList);
  if (pre.errno !== 0) {
    const e = explain(pre.errno, pre);
    throw new SkillError(e.code, `上传预检失败：${e.text}`, { errno: pre.errno, exit: e.exit });
  }

  const uploadid = pre.uploadid;
  const returnType = Number(pre.return_type);
  const need = (pre.block_list || []).map(Number);
  let method = 'normal';

  if (returnType === 2) {
    method = 'instant';
    log.info(`命中秒传：${name}`);
  } else {
    log.info(`开始上传 ${name}（${(size / 1024).toFixed(1)} KB，${need.length} 个分片）`);
    for (const seq of need) {
      await uploadPart(client, remotePath, uploadid, seq, blocks[seq]);
    }
  }

  const cr = await client.api('/api/create', {}, new URLSearchParams({
    path: remotePath,
    size: String(size),
    isdir: '0',
    block_list: JSON.stringify(blockList),
    uploadid: uploadid || '',
    rtype: '3',
  }).toString());
  const cj = cr.j || {};
  if (cj.errno !== 0) {
    const e = explain(cj.errno, cj);
    throw new SkillError(e.code, `上传收尾失败：${e.text}`, { errno: cj.errno, exit: e.exit });
  }

  return {
    remote_path: remotePath,
    file_name: name,
    file_size: size,
    upload_method: method,
    fs_id: cj.fs_id ? Number(cj.fs_id) : null,
    md5: cj.md5 || blockList[0],
    sha256: sha256File(localPath),
    part_count: need.length || blockList.length,
  };
}

module.exports = { uploadFile, checkSpace, precreate, uploadPart, basename };
