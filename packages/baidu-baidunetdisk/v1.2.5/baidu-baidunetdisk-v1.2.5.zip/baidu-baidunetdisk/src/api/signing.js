'use strict';
// 签名与协议算法
//
// 说明：当前走通的接口（list/create/precreate/share/list/pset/transfer/filemetas/filemanager）
// 全部只需 cookie + bdstoken，不需要 sign1/sign3/sign2。这里保留 sign2 供协议参考，
// 以及一个 bdstoken 提取工具，避免以后接口变化时无处下手。
//
// 历史坑：新版 /disk/home 页面已不再注入 sign1/sign3，老的 web 下载签名算法失效，
// 因此下载改走 xpan/file?method=filemetas&dlink=1。详见 docs/protocol-references.md。

// Sign2：百度历史上用于分享/下载的 RC4 变体（256 字节 S 盒，按 key rune 循环）
function sign2(key, data) {
  const a = new Array(256);
  const p = new Array(256);
  const v = key.length;
  let u = 0;
  let i = 0;
  for (let q = 0; q < 256; q++) {
    a[q] = key[q % v];
    p[q] = q;
  }
  for (let q = 0; q < 256; q++) {
    u = (u + p[q] + a[q]) % 256;
    const t = p[q];
    p[q] = p[u];
    p[u] = t;
  }
  u = 0;
  const o = new Uint8Array(data.length);
  for (let q = 0; q < data.length; q++) {
    i = (i + 1) % 256;
    u = (u + p[i]) % 256;
    const t = p[i];
    p[i] = p[u];
    p[u] = t;
    o[q] = data[q] ^ p[(p[i] + p[u]) % 256];
  }
  return o;
}

// 从页面 HTML 里提取 bdstoken（备用路径，主路径用 gettemplatevariable 接口）
function extractBdstoken(html) {
  const m = String(html || '').match(/"bdstoken"\s*:\s*"([0-9a-f]{16,})"/i);
  return m ? m[1] : null;
}

module.exports = { sign2, extractBdstoken };
