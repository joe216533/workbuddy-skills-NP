'use strict';
// 删除（受 guard 调用的底层接口）
//
// 接口：POST /api/filemanager?opera=delete  body: filelist=["/path"]&async=0&ondup=0
// 实测：单文件、空目录、非空目录递归删除均 errno 0；删除后进入网页端回收站（可恢复），
//       但回收站仍占用容量 —— 因此失败提示里必须包含"回收站也要清"。
const { SkillError, explain } = require('../utils/errors');
const { normalize } = require('../storage/paths');

async function deletePaths(client, paths) {
  const list = (paths || []).map((p) => normalize(p));
  if (!list.length) throw new SkillError('BAD_PARAM', '没有指定要删除的路径。');

  let r;
  try {
    r = await client.api(
      '/api/filemanager',
      { opera: 'delete' },
      new URLSearchParams({ filelist: JSON.stringify(list), async: '0', ondup: '0' }).toString()
    );
  } catch (e) {
    // 关键：请求已发出但结果未知，绝不能报成功
    throw new SkillError(
      'DELETE_UNKNOWN',
      `删除请求已发出，但未收到服务端结果（${e.message}）。请先执行 list 确认目标是否还在，不要直接重复删除。`
    );
  }

  const j = r.j;
  if (!j) {
    throw new SkillError('DELETE_UNKNOWN', `删除返回非 JSON（HTTP ${r.http}）：${r.text || ''}。结果未知，请用 list 复核。`);
  }

  const info = Array.isArray(j.info) ? j.info : [];
  const perItem = info.map((x) => ({
    path: x.path,
    errno: Number(x.errno),
    ok: Number(x.errno) === 0,
  }));

  if (j.errno !== 0) {
    const e = explain(j.errno, j);
    return { ok: false, errno: j.errno, code: e.code, text: e.text, exit: e.exit, items: perItem };
  }
  const failed = perItem.filter((x) => !x.ok);
  if (failed.length) {
    return {
      ok: false,
      errno: 12,
      code: 'PARTIAL_FAIL',
      text: '部分对象删除失败，请检查是否被占用或权限不足。',
      exit: 1,
      items: perItem,
    };
  }
  return { ok: true, errno: 0, items: perItem, request_id: j.request_id || null };
}

module.exports = { deletePaths };
