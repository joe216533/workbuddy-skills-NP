'use strict';
// 分享：创建（/share/pset）、撤销（/share/cancel）
//
// 关键实测：
//   period=0 → expiredType=0 / expiretime=0（永久）
//   period=7 → expiredType=7 / expiretime=ctime+604800
//   pwd 固定 4 位，链接形式 https://pan.baidu.com/s/1xxxx?pwd=abcd（带 ?pwd= 时浏览器自动填码）
//   撤销：POST /share/cancel  body: shareid_list=[123]（数字数组）
//         错误写法：query 带 shareid=、body 传 JSON 对象 —— 均返回 errno 2「参数错误」
const { normalize } = require('../storage/paths');
const { SkillError, explain } = require('../utils/errors');

const PERIOD_TEXT = { 0: '永久有效', 7: '7 天', 1: '1 天' };

// 生成 4 位提取码（百度要求 4 位，字母数字）
function makePwd() {
  const chars = 'abcdefghijkmnpqrstuvwxyz23456789';
  let s = '';
  for (let i = 0; i < 4; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

async function createShare(client, paths, { pwd, period = 0 } = {}) {
  const list = paths.map((p) => normalize(p));
  if (!list.length) throw new SkillError('BAD_PARAM', '至少需要一个网盘路径');
  const password = pwd || makePwd();
  if (!/^[A-Za-z0-9]{4}$/.test(password)) {
    throw new SkillError('BAD_PWD_FORMAT', '百度提取码必须是 4 位字母或数字');
  }

  const r = await client.api('/share/pset', {}, new URLSearchParams({
    path_list: JSON.stringify(list),
    schannel: '4',
    channel_list: '[]',
    period: String(period),
    pwd: password,
    share_type: '9',
  }).toString());
  const j = r.j || {};
  if (j.errno !== 0) {
    const e = explain(j.errno, j);
    throw new SkillError(e.code, `创建分享失败：${e.text}`, { errno: j.errno, exit: e.exit });
  }

  const link = j.link || '';
  const shareid = j.shareid ? Number(j.shareid) : null;
  return {
    share_id: shareid,
    short_url: link,
    full_url: link ? `${link}?pwd=${password}` : '',
    password,
    period: Number(j.period != null ? j.period : period),
    period_text: PERIOD_TEXT[Number(j.period != null ? j.period : period)] || `${period} 天`,
    expired_type: Number(j.expiredType != null ? j.expiredType : 0),
    expire_time: Number(j.expiretime != null ? j.expiretime : 0),
    share_status: Number(j.expiredType || 0) === 0 ? 'permanent' : 'temporary',
  };
}

// 撤销分享。成功返回 {ok:true}
async function cancelShares(client, shareIds) {
  const ids = (shareIds || []).map(Number).filter((n) => Number.isFinite(n) && n > 0);
  if (!ids.length) return { ok: false, reason: '没有可撤销的 share_id' };
  const r = await client.api('/share/cancel', {}, `shareid_list=${encodeURIComponent(JSON.stringify(ids))}`);
  const j = r.j || {};
  if (j.errno !== 0) {
    const e = explain(j.errno, j);
    return { ok: false, errno: j.errno, text: e.text };
  }
  return { ok: true, cancelled: ids };
}

// 查询某条分享在我这边的状态（通过短链回读，验证是否真的失效）
async function probeShare(client, shortUrl) {
  const m = String(shortUrl || '').match(/pan\.baidu\.com\/s\/([A-Za-z0-9_-]+)/);
  if (!m) return { ok: false, reason: '无法解析短链' };
  const shorturl = m[1];
  const surl = shorturl.startsWith('1') ? shorturl.slice(1) : shorturl;
  const url =
    `https://pan.baidu.com/share/list?shorturl=${surl}&web=5&app_id=250528&desc=1&showempty=0` +
    `&page=1&num=10&order=time&root=1&view_mode=1&channel=chunlei&clienttype=0` +
    `&bdstoken=${encodeURIComponent(client.bdstoken || '')}`;
  const r = await client.getAbsolute(url);
  const j = r.j || {};
  return { ok: j.errno === 0, errno: j.errno, text: j.show_msg || '' };
}

module.exports = { createShare, cancelShares, probeShare, makePwd, PERIOD_TEXT };
