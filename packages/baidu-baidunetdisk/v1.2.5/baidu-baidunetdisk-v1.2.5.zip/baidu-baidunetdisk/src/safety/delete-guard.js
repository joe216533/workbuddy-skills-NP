'use strict';
// 删除安全闸门（本技能风险最高的模块，规则来自顾问第 35 轮裁决）
//
// 硬规则（全部强制，无绕过开关）：
//   1. 只接受网盘绝对路径
//   2. 禁止通配符 * ? [ ] { }
//   3. 禁止根目录 / 与空路径
//   4. 默认只允许技能目录 /来自：WorkBuddy/baidu-baidunetdisk 之内，且不允许删除该目录本身
//   5. 必须传 --yes 才执行
//   6. 非空目录必须额外传 --recursive
//   7. 执行前必须 list 预览：文件名、大小、修改时间、服务端 fs_id、数量、总大小
//   8. 执行前用 fs_id 二次核对目标未变（防"预览是 A、删的是 B"）
//   9. 删除后必须重新 list，确认目标已消失；只有服务端成功且复查通过才算成功
//  10. 不提供 --allow-outside，首版没有任何外部目录删除通道
const { SkillError } = require('../utils/errors');
const paths = require('../storage/paths');
const { stat, walk } = require('../api/file-list');
const { deletePaths } = require('../api/delete');
const { humanSize } = require('../storage/integrity');
const log = require('../utils/logger');

const GUARD_ROOT = paths.SKILL_ROOT;

function refuse(code, text) {
  return new SkillError(code, text, { exit: 4 });
}

// 闸门 1~4：路径合法性
function validateTarget(rawPath) {
  const raw = String(rawPath == null ? '' : rawPath).trim();
  if (!raw) throw refuse('REFUSED_EMPTY', '拒绝删除：没有指定路径。');
  if (paths.hasWildcard(raw)) {
    throw refuse('REFUSED_WILDCARD', `拒绝删除：路径里含通配符（* ? [ ] { }），本技能不支持批量删除。请逐个指定完整路径。收到：${raw}`);
  }
  if (!raw.startsWith('/')) {
    throw refuse('REFUSED_RELATIVE', `拒绝删除：必须使用网盘绝对路径（以 / 开头）。收到：${raw}`);
  }
  let p;
  try {
    p = paths.normalize(raw);
  } catch (e) {
    throw refuse('REFUSED_TRAVERSAL', `拒绝删除：${e.message}`);
  }
  if (p === '/') throw refuse('REFUSED_ROOT', '拒绝删除：不允许删除网盘根目录。');
  if (!paths.isUnder(p, GUARD_ROOT)) {
    throw refuse(
      'REFUSED_OUTSIDE',
      `拒绝删除：${p} 不在本技能允许的目录内。首版只允许删除 ${GUARD_ROOT} 下的内容，这是防止误删的硬限制，没有绕过开关。`
    );
  }
  if (paths.normalize(p) === paths.normalize(GUARD_ROOT)) {
    throw refuse('REFUSED_SKILL_ROOT', `拒绝删除：不允许删除技能目录本身（${GUARD_ROOT}）。请指定该目录下的具体文件或子目录。`);
  }
  return p;
}

/**
 * 预览：读取待删除对象并生成清单（闸门 7）
 * @returns 预览对象，供确认与二次核对使用
 */
async function previewDelete(client, rawPath, { recursive = false } = {}) {
  const target = validateTarget(rawPath);
  const item = await stat(client, target);

  if (!item) {
    throw new SkillError('NOT_FOUND', `网盘上找不到要删除的对象：${target}。请先用 list 确认路径。`, { exit: 1 });
  }

  const preview = {
    target_path: target,
    target_type: item.isdir ? 'directory' : 'file',
    target_file_id: item.fs_id,
    target_size: item.size,
    target_mtime: item.mtime,
    recursive: Boolean(recursive),
    preview_item_count: 1,
    preview_total_size: item.size,
    children: [],
    dirs: [],
    need_recursive: false,
  };

  if (item.isdir) {
    const w = await walk(client, target);
    preview.children = w.files.map((f) => ({
      name: f.name,
      path: f.path,
      size: f.size,
      mtime: f.mtime,
      fs_id: f.fs_id,
    }));
    preview.dirs = w.dirs;
    preview.preview_item_count = w.files.length + w.dirs.length + 1; // 含目录自身
    preview.preview_total_size = w.totalSize;
    preview.need_recursive = w.files.length > 0 || w.dirs.length > 0;
    preview.truncated = w.truncated;

    // 闸门 6：非空目录必须显式 --recursive
    if (preview.need_recursive && !recursive) {
      throw refuse(
        'REFUSED_NEED_RECURSIVE',
        `拒绝删除：${target} 是非空目录（含 ${w.files.length} 个文件、${w.dirs.length} 个子目录，合计 ${humanSize(w.totalSize)}）。` +
          `确认要连内容一起删，请加 --recursive --yes 重新执行。`
      );
    }
  } else if (recursive) {
    log.warn('目标是文件，--recursive 对文件无意义，已忽略。');
  }

  return preview;
}

// 闸门 8：执行前用 fs_id 二次核对
async function recheck(client, preview) {
  const again = await stat(client, preview.target_path);
  if (!again) {
    throw refuse('REFUSED_VANISHED', `拒绝删除：预览之后目标 ${preview.target_path} 已不存在，可能有其他操作在同时改动。已中止。`);
  }
  if (Number(again.fs_id) !== Number(preview.target_file_id)) {
    throw refuse(
      'REFUSED_ID_CHANGED',
      `拒绝删除：目标已变化。预览时 fs_id=${preview.target_file_id}，现在 fs_id=${again.fs_id}。` +
        `为防误删，已中止。请重新执行预览确认对象后再删。`
    );
  }
  if (Number(again.size) !== Number(preview.target_size)) {
    throw refuse(
      'REFUSED_SIZE_CHANGED',
      `拒绝删除：目标大小已变化（预览 ${preview.target_size} 字节，现在 ${again.size} 字节），可能有其他程序在写入。已中止。`
    );
  }
  return true;
}

/**
 * 执行删除（闸门 5、8、9）
 */
async function executeDelete(client, preview, { yes = false } = {}) {
  if (!yes) {
    throw refuse('REFUSED_NO_YES', '拒绝删除：必须显式传入 --yes 才执行。上面的预览清单就是将被删除的内容，请核对后再确认。');
  }
  await recheck(client, preview);

  const res = await deletePaths(client, [preview.target_path]);
  const result = {
    account_alias: client.alias,
    target_path: preview.target_path,
    target_type: preview.target_type,
    target_file_id: preview.target_file_id,
    preview_item_count: preview.preview_item_count,
    preview_total_size: preview.preview_total_size,
    recursive: preview.recursive,
    delete_status: 'failed',
    remaining_items: null,
    recycle_bin: 'deleted_items_go_to_recycle_bin',
  };

  if (!res.ok) {
    result.delete_status = 'failed';
    result.error = res.text;
    result.server_items = res.items;
    return result;
  }

  // 闸门 9：删除后复查
  const after = await stat(client, preview.target_path);
  result.remaining_items = after ? 1 : 0;
  if (after) {
    result.delete_status = 'unverified';
    result.error = '服务端报告删除成功，但复查仍能查到该对象。请勿重复删除，先手动 list 核实。';
    return result;
  }

  result.delete_status = 'success';
  result.note =
    '已移入网页端回收站，可在 pan.baidu.com 回收站恢复；回收站内容仍占用网盘容量，需要腾空间时请在网页端清空回收站。';
  return result;
}

module.exports = { GUARD_ROOT, validateTarget, previewDelete, recheck, executeDelete };
