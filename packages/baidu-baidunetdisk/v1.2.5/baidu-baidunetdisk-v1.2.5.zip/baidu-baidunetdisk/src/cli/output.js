'use strict';
// 统一输出格式与状态码
//
// 默认输出 key: value 逐行（人和智能体都能读），--json 输出结构化 JSON。
// 规则：失败绝不输出成功字样；未执行的项目输出 SKIP，不假报 PASS。
const { redact } = require('../safety/redaction');

const MAX_ARRAY_PREVIEW = 50;

function fmtScalar(v) {
  if (v === null || v === undefined) return '-';
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'number') return String(v);
  const s = String(v);
  return s === '' ? '""' : redact(s);
}

function printObject(obj, indent = 0, keyWidth = 0) {
  const pad = ' '.repeat(indent);
  const entries = Object.entries(obj);
  const width = keyWidth || Math.max(...entries.map(([k]) => k.length), 0);
  for (const [k, v] of entries) {
    if (v === undefined) continue;
    if (Array.isArray(v)) {
      if (!v.length) {
        process.stdout.write(`${pad}${k.padEnd(width)} : (空)\n`);
        continue;
      }
      process.stdout.write(`${pad}${k.padEnd(width)} : ${v.length} 项\n`);
      const shown = v.slice(0, MAX_ARRAY_PREVIEW);
      for (const item of shown) {
        if (item && typeof item === 'object') {
          const line = Object.entries(item)
            .map(([ik, iv]) => `${ik}=${fmtScalar(iv)}`)
            .join('  ');
          process.stdout.write(`${pad}  - ${line}\n`);
        } else {
          process.stdout.write(`${pad}  - ${fmtScalar(item)}\n`);
        }
      }
      if (v.length > shown.length) process.stdout.write(`${pad}  … 另有 ${v.length - shown.length} 项未显示（用 --json 看全部）\n`);
      continue;
    }
    if (v && typeof v === 'object') {
      process.stdout.write(`${pad}${k.padEnd(width)} :\n`);
      printObject(v, indent + 2);
      continue;
    }
    process.stdout.write(`${pad}${k.padEnd(width)} : ${fmtScalar(v)}\n`);
  }
}

function print(result, { json = false } = {}) {
  if (json) {
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
    return;
  }
  printObject(result);
}

// 错误输出：同时给出给人看的说明和给程序用的 code
function printError(code, text, extra = {}, { json = false } = {}) {
  if (json) {
    process.stdout.write(JSON.stringify({ ok: false, code, error: text, ...extra }, null, 2) + '\n');
    return;
  }
  process.stdout.write(`status                       : FAILED\n`);
  process.stdout.write(`error_code                   : ${code}\n`);
  process.stdout.write(`error                        : ${text}\n`);
  for (const [k, v] of Object.entries(extra)) {
    if (v === undefined || v === null) continue;
    process.stdout.write(`${k.padEnd(28)} : ${fmtScalar(v)}\n`);
  }
}

module.exports = { print, printError, printObject, fmtScalar };
