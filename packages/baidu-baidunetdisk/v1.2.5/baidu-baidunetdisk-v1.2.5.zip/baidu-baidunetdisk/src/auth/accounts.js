'use strict';
// 多账号别名与切换
//
// 规则（顾问第 35 轮裁决）：
//   - 别名由老板指定，绝不自动读取百度昵称（昵称含个人信息、会变、会重名）
//   - 别名只用于本机区分账号，不进普通日志
//   - 每个操作都必须能明确识别当前账号；不存在"授权失效就自动换另一个账号"的逻辑
//   - auth logout --as 只清该账号，不影响其他账号
const fs = require('node:fs');
const path = require('node:path');
const { ensureDataDir } = require('../utils/platform');
const { SkillError } = require('../utils/errors');

const ALIAS_RE = /^[A-Za-z0-9_-]{1,32}$/;

function indexPath() {
  return path.join(ensureDataDir(), 'accounts.json');
}

function readIndex() {
  const f = indexPath();
  if (!fs.existsSync(f)) return { version: 1, current: null, accounts: {} };
  let j;
  try {
    j = JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch {
    throw new SkillError('BAD_INDEX', `账号索引文件损坏：${f}。可删除该文件后重新授权（不影响网盘上的文件）。`);
  }
  return { version: 1, current: null, accounts: {}, ...j };
}

function writeIndex(idx) {
  fs.writeFileSync(indexPath(), JSON.stringify(idx, null, 2), { mode: 0o600 });
}

function assertAlias(alias) {
  const a = String(alias == null ? '' : alias).trim();
  if (!ALIAS_RE.test(a)) {
    throw new SkillError('BAD_ALIAS', `账号别名只能包含字母、数字、下划线、短横线，长度 1-32，收到：${alias || '(空)'}`);
  }
  return a;
}

// 注册（或更新）账号记录
function register(alias, meta = {}) {
  const a = assertAlias(alias);
  const idx = readIndex();
  const prev = idx.accounts[a] || {};
  idx.accounts[a] = {
    alias: a,
    createdAt: prev.createdAt || new Date().toISOString(),
    lastVerifiedAt: meta.lastVerifiedAt || null,
    store: meta.store || prev.store || null,
    note: meta.note || prev.note || null,
  };
  if (!idx.current) idx.current = a;
  writeIndex(idx);
  return idx.accounts[a];
}

function touch(alias, verifiedAt) {
  const a = assertAlias(alias);
  const idx = readIndex();
  if (!idx.accounts[a]) return null;
  idx.accounts[a].lastVerifiedAt = verifiedAt || new Date().toISOString();
  writeIndex(idx);
  return idx.accounts[a];
}

function unregister(alias) {
  const a = assertAlias(alias);
  const idx = readIndex();
  const existed = Boolean(idx.accounts[a]);
  delete idx.accounts[a];
  if (idx.current === a) {
    const rest = Object.keys(idx.accounts);
    idx.current = rest.length ? rest[0] : null;
  }
  writeIndex(idx);
  return existed;
}

function setCurrent(alias) {
  const a = assertAlias(alias);
  const idx = readIndex();
  if (!idx.accounts[a]) {
    throw new SkillError('NO_ACCOUNT', `本机没有登记账号 ${a}。现有账号：${Object.keys(idx.accounts).join('、') || '（无）'}`);
  }
  idx.current = a;
  writeIndex(idx);
  return idx;
}

function getCurrent() {
  const idx = readIndex();
  return idx.current;
}

// 解析本次要用的账号：显式 --as 优先，否则用 current。绝不自动跨账号回退。
function resolve(alias) {
  const idx = readIndex();
  if (alias) {
    const a = assertAlias(alias);
    if (!idx.accounts[a]) {
      throw new SkillError(
        'NO_ACCOUNT',
        `本机没有登记账号 ${a}。${Object.keys(idx.accounts).length ? '现有账号：' + Object.keys(idx.accounts).join('、') : '请先执行 auth login --as ' + a}`
      );
    }
    return a;
  }
  if (!idx.current) {
    throw new SkillError('NO_ACCOUNT', '本机还没有授权任何百度网盘账号。请先执行：auth login --as <别名>（别名由你指定，例如 159）');
  }
  return idx.current;
}

function list() {
  const idx = readIndex();
  return {
    current: idx.current,
    accounts: Object.values(idx.accounts).map((a) => ({ ...a, is_current: a.alias === idx.current })),
  };
}

function hasAny() {
  return Object.keys(readIndex().accounts).length > 0;
}

module.exports = { assertAlias, register, touch, unregister, setCurrent, getCurrent, resolve, list, hasAny, readIndex, indexPath };
