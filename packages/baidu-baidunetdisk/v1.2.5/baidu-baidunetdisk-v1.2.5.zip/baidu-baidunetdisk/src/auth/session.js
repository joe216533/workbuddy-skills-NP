'use strict';
// 授权有效性检查：打开会话、验证登录态、刷新 lastVerifiedAt
const { PanClient } = require('../api/client');
const credentialStore = require('./credential-store');
const accounts = require('./accounts');
const { SkillError } = require('../utils/errors');
const log = require('../utils/logger');

/**
 * 用指定账号（或当前账号）建立可用会话
 * @param {object} opts
 * @param {string} [opts.as] 账号别名
 */
async function openSession({ as } = {}) {
  const alias = accounts.resolve(as);
  const cred = credentialStore.load(alias);
  const client = new PanClient(cred, alias);
  await client.init();
  return client;
}

/**
 * 只查状态，不抛错（供 auth status 使用）
 */
async function checkSession(alias) {
  const out = {
    account_alias: alias,
    login_status: 'unknown',
    authorization_status: 'unknown',
    uk: null,
    quota: null,
    checked_at: new Date().toISOString(),
  };
  try {
    const cred = credentialStore.load(alias);
    const client = new PanClient(cred, alias);
    await client.init();
    const q = await client.quota();
    out.login_status = 'logged_in';
    out.authorization_status = 'valid';
    out.uk = client.uk;
    if (q && q.errno === 0) {
      out.quota = {
        total_bytes: Number(q.total || 0),
        used_bytes: Number(q.used || 0),
        free_bytes: Number(q.total || 0) - Number(q.used || 0),
      };
    }
    accounts.touch(alias, out.checked_at);
  } catch (e) {
    if (e.code === 'NO_CRED' || e.code === 'CRED_UNDECRYPTABLE' || e.code === 'CRED_EMPTY') {
      out.login_status = 'no_credential';
      out.authorization_status = 'missing';
    } else if (e.code === 'NOT_LOGIN' || /登录/.test(e.message)) {
      out.login_status = 'expired';
      out.authorization_status = 'expired';
    } else {
      out.login_status = 'error';
      out.authorization_status = 'error';
      log.warn(`状态检查失败：${e.message}`);
    }
    out.error = e.message;
  }
  return out;
}

// 登录后立即验证一次，验证不通过就不落盘（避免存下无效凭据）
async function verifyCredential(cred) {
  const client = new PanClient(cred, '(pending)');
  await client.init();
  const r = await client.api('/api/list', { dir: '/', num: '1', page: '1', order: 'name', desc: '0', showempty: '0' });
  if (!r.j || r.j.errno !== 0) {
    throw new SkillError('CRED_INVALID', `凭据验证未通过（errno ${r.j ? r.j.errno : '?'}），本次不保存。请重新授权。`);
  }
  const q = await client.quota();
  return {
    uk: client.uk,
    quota: q && q.errno === 0 ? { total: Number(q.total || 0), used: Number(q.used || 0) } : null,
  };
}

module.exports = { openSession, checkSession, verifyCredential };
