'use strict';
// 专用浏览器授权流程（方案 B）
//
// 安全设计（每一条都是硬要求，不提供关闭开关）：
//   1. 独立 Chrome 实例 + 独立临时 Profile，不碰你日常浏览器
//   2. 窗口必须可见（windowsHide:false），由你本人扫码/登录，程序不代输密码
//   3. --proxy-server=direct:// + --proxy-bypass-list=* ：只让这一个浏览器走国内直连，
//      不影响系统全局 VPN —— 开了 VPN 只需要这个浏览器直连，不需要把 VPN 全关
//   4. CDP 只监听 127.0.0.1 的随机端口
//   5. 登录成功只提取 BDUSS(.baidu.com) 与 STOKEN(.pan.baidu.com) 两个字段，其余全部丢弃
//   6. 提取后立即关闭浏览器并删除临时 Profile
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { findChrome } = require('../utils/platform');
const { SkillError } = require('../utils/errors');
const log = require('../utils/logger');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function freePort(start = 9500, end = 9700) {
  for (let p = start; p <= end; p++) {
    const ok = await new Promise((res) => {
      const s = net.createServer();
      s.once('error', () => res(false));
      s.once('listening', () => s.close(() => res(true)));
      s.listen(p, '127.0.0.1');
    });
    if (ok) return p;
  }
  throw new SkillError('NO_PORT', '9500-9700 端口全被占用，无法启动调试端口。');
}

async function waitCdp(port, timeoutMs = 30000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/json/version`, { signal: AbortSignal.timeout(1500) });
      if (r.ok) return await r.json();
    } catch {
      /* 继续等 */
    }
    await sleep(400);
  }
  throw new SkillError('CDP_TIMEOUT', '浏览器调试端口未就绪，可能被杀毒软件拦截或 Chrome 启动失败。');
}

class Cdp {
  constructor(wsUrl) {
    this.wsUrl = wsUrl;
    this.id = 0;
    this.pending = new Map();
  }

  async open() {
    this.ws = new WebSocket(this.wsUrl);
    await new Promise((res, rej) => {
      this.ws.onopen = res;
      this.ws.onerror = () => rej(new SkillError('WS_FAIL', 'CDP WebSocket 连接失败'));
    });
    this.ws.onmessage = (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id && this.pending.has(m.id)) {
        this.pending.get(m.id)(m);
        this.pending.delete(m.id);
      }
    };
    return this;
  }

  send(method, params = {}) {
    const id = ++this.id;
    return new Promise((res, rej) => {
      const to = setTimeout(() => {
        this.pending.delete(id);
        rej(new SkillError('CDP_CMD_TIMEOUT', 'CDP 命令超时：' + method));
      }, 20000);
      this.pending.set(id, (m) => {
        clearTimeout(to);
        if (m.error) rej(new SkillError('CDP_ERROR', method + ': ' + m.error.message));
        else res(m.result);
      });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  close() {
    try {
      this.ws.close();
    } catch {
      /* ignore */
    }
  }
}

// 同名 cookie 在多个域下取值不同，必须按域精确挑（取错 STOKEN 会 errno=-6 未登录）
function pickCookies(cookies) {
  const byName = (n) => cookies.filter((c) => c.name === n);
  const prefer = (n, domains) => {
    for (const d of domains) {
      const hit = byName(n).find((c) => c.domain === d);
      if (hit) return hit;
    }
    return byName(n).find((c) => String(c.domain).includes('baidu.com'));
  };
  const bduss = prefer('BDUSS', ['.baidu.com']);
  const stoken = prefer('STOKEN', ['.pan.baidu.com', '.pcs.baidu.com', '.baidu.com']);
  return {
    bduss: bduss ? bduss.value : null,
    stoken: stoken ? stoken.value : null,
    detail: {
      total_cookies: cookies.length,
      bduss_domain: bduss ? bduss.domain : null,
      stoken_domain: stoken ? stoken.domain : null,
      stoken_candidates: byName('STOKEN').map((c) => c.domain),
    },
  };
}

/**
 * 打开专用浏览器等待人工登录，成功后返回两个凭据字段（仅内存）
 * @param {object} opts
 * @param {number} opts.timeoutMs 登录等待上限，默认 10 分钟
 * @param {function} opts.onNotice 进度回调（给 CLI 打提示用）
 */
async function loginWithDedicatedBrowser({ timeoutMs = 10 * 60 * 1000, onNotice = () => {} } = {}) {
  const chrome = findChrome();
  if (!chrome) {
    throw new SkillError(
      'NO_BROWSER',
      '未找到 Chrome 或 Edge。请安装 Chrome，或用环境变量 BD_CHROME_PATH 指定浏览器可执行文件路径。'
    );
  }

  const port = await freePort();
  const profile = path.join(os.tmpdir(), `bdskill-login-${Date.now()}`);
  fs.mkdirSync(profile, { recursive: true });

  log.info(`浏览器：${chrome}`);
  log.info(`调试端口：${port}（仅绑 127.0.0.1）`);
  log.info(`临时 Profile：${profile}`);

  const args = [
    `--remote-debugging-port=${port}`,
    '--remote-debugging-address=127.0.0.1',
    `--user-data-dir=${profile}`,
    '--no-first-run',
    '--no-default-browser-check',
    '--disable-sync',
    '--disable-extensions',
    '--disable-background-networking',
    '--proxy-server=direct://',
    '--proxy-bypass-list=*',
    '--window-size=1180,820',
    '--window-position=70,40',
    'https://pan.baidu.com/',
  ];

  const child = spawn(chrome, args, { detached: true, stdio: 'ignore', windowsHide: false });
  child.unref();

  let browser = null;
  let tab = null;
  let cleaned = false;

  const cleanup = async () => {
    if (cleaned) return;
    cleaned = true;
    try {
      if (browser) await browser.send('Browser.close');
    } catch {
      /* ignore */
    }
    tab && tab.close();
    browser && browser.close();
    await sleep(800);
    try {
      fs.rmSync(profile, { recursive: true, force: true });
      log.info('临时 Profile 已删除');
    } catch (e) {
      log.warn(`临时 Profile 删除失败（可手动删）：${profile}`);
    }
  };

  try {
    const ver = await waitCdp(port);
    log.info(`CDP 就绪：${ver.Browser}`);

    browser = await new Cdp(ver.webSocketDebuggerUrl).open();
    const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    const page =
      targets.find((t) => t.type === 'page' && String(t.url).includes('baidu.com')) ||
      targets.find((t) => t.type === 'page');

    try {
      const { windowId } = await browser.send('Browser.getWindowForTarget', { targetId: page.id });
      await browser.send('Browser.setWindowBounds', {
        windowId,
        bounds: { windowState: 'normal', left: 70, top: 40, width: 1180, height: 820 },
      });
    } catch {
      /* 某些平台不支持设置窗口位置，忽略 */
    }

    tab = await new Cdp(page.webSocketDebuggerUrl).open();

    onNotice('已打开专用浏览器窗口，请在该窗口里扫码或登录百度网盘。');
    onNotice('这个浏览器单独走国内直连，不需要关掉系统全局 VPN。');

    // 只观察 URL 是否进入网盘主页，不读取任何凭据
    const t0 = Date.now();
    let loggedIn = false;
    while (Date.now() - t0 < timeoutMs) {
      await sleep(2500);
      let href = '';
      try {
        const r = await tab.send('Runtime.evaluate', { expression: 'location.href', returnByValue: true });
        href = String(r.result.value || '');
      } catch {
        /* 页面切换中，继续等 */
      }
      if (href.includes('/disk/main') || href.includes('/disk/home')) {
        loggedIn = true;
        log.info('检测到已进入网盘主页');
        break;
      }
      const left = Math.max(0, Math.round((timeoutMs - (Date.now() - t0)) / 1000));
      if (Math.round((Date.now() - t0) / 1000) % 20 < 3) onNotice(`等待登录中…剩余 ${left} 秒`);
    }

    if (!loggedIn) {
      throw new SkillError(
        'LOGIN_TIMEOUT',
        '等待登录超时，没有检测到网盘主页。如果是网络问题，请确认这个浏览器能直连 pan.baidu.com 后重试。'
      );
    }

    // 登录成功后稍等，让 cookie 落全
    await sleep(2500);
    const { cookies } = await browser.send('Storage.getCookies');
    const picked = pickCookies(cookies);
    log.info(
      `Cookie 提取：共 ${picked.detail.total_cookies} 条，只保留 BDUSS(${picked.detail.bduss_domain}) 与 STOKEN(${picked.detail.stoken_domain})`
    );

    if (!picked.bduss || !picked.stoken) {
      throw new SkillError(
        'CRED_MISSING',
        `登录页已进入，但没有取到 ${!picked.bduss ? 'BDUSS' : 'STOKEN'}。可能登录未完全完成，请重试一次。`
      );
    }

    return { bduss: picked.bduss, stoken: picked.stoken, detail: picked.detail };
  } finally {
    await cleanup();
  }
}

module.exports = { loginWithDedicatedBrowser, pickCookies, freePort };
