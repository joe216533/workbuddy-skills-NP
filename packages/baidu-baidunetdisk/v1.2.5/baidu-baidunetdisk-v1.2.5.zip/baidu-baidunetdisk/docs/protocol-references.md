# 接口来源与协议参考

本文件记录本技能依赖的全部接口、参数形态，以及寻找过程中踩过的坑。
所有条目都来自真实调用验证，不是从文档抄的。

## 一、通用约定

- 域名：`pan.baidu.com`；分片上传走 `c3.pcs.baidu.com`
- 鉴权：Cookie `BDUSS` + `STOKEN`，**不需要 access_token**
- 公共查询参数：`clienttype=0&app_id=250528&web=1&channel=chunlei&bdstoken=<bdstoken>`
- `bdstoken` 与 `uk` 通过下面的接口取，每次会话取一次即可
- 所有写操作以返回 JSON 的 `errno` 为唯一成功依据，`errno=0` 才算成功

---

## 二、接口清单

### 取会话令牌

```
GET /api/gettemplatevariable?clienttype=0&app_id=250528&web=1&fields=["bdstoken","uk"]
→ { errno:0, result:{ bdstoken, uk, ... } }
```

### 列目录

```
GET /api/list?order=name&desc=0&showempty=1&page=1&num=200&dir=/&bdstoken=<>&t=<ms>
→ { errno:0, list:[{ fs_id, server_filename, isdir, size, server_mtime, md5, path }] }
```

`showempty=1` 才能看到空目录。`t` 是防缓存时间戳。

### 创建目录

```
POST /api/create
body: path=/绝对路径&isdir=1&block_list=[]&size=0&rtype=0
→ { errno:0, fs_id }
```

`errno=-8` 表示目录已存在，按成功处理。

### 容量

```
GET /api/quota?checkfree=1&checkexpire=1&bdstoken=<>
→ { errno:0, total, used, free }
```

`total` / `used` 单位是字节。上传前用它预判空间。

### 上传（三步）

```
① POST /api/precreate
   body: path=/目录/文件名&size=<字节>&isdir=0&autoinit=1&block_list=["md5","md5",...]&rtype=3&contentCrc32=0
   → { errno:0, uploadid, return_type, block_list:[需要上传的分片序号] }

② POST https://c3.pcs.baidu.com/rest/2.0/pcs/superfile2
        ?method=upload&type=tmpfile&path=<>&partseq=<序号>&uploadid=<>& app_id/clienttype/web/channel/bdstoken
   body: multipart/form-data，字段名 file
   → { md5 } 成功；{ error_code } 失败

③ POST /api/create
   body: path=<>&size=<>&isdir=0&block_list=[...]&uploadid=<>&rtype=3
   → { errno:0, fs_id, md5, category, path }
```

要点：

- `block_list` 是**4MB 分片 MD5 的 JSON 数组字符串**
- `return_type=2` 表示命中秒传，跳过第 ② 步直接第 ③ 步
- 分片只传 `precreate` 在 `block_list` 里点名要的那几片，不是无脑全传
- `fs_id` 只有第 ③ 步才拿得到

### 创建分享

```
POST /share/pset
body: path_list=["/路径"]&schannel=4&channel_list=[]&period=<0|1|7>&pwd=<4位>&share_type=9
→ { errno:0, shareid, link, pwd, period, expiredType, expiretime, ctime }
```

有效期映射（实测）：

| 请求 | 返回 |
|-|-|
| `period=0` | `expiredType=0`、`expiretime=0`（永久） |
| `period=7` | `expiredType=7`、`expiretime=ctime+604800` |

`link` 形如 `https://pan.baidu.com/s/1xxxxxxx`，拼上 `?pwd=xxxx` 后，
**在无 Cookie 的干净浏览器里打开，页面不会出现提取码输入框，直接进入下载页**（已实测）。

### 撤销分享

```
POST /share/cancel?clienttype=0&app_id=250528&web=1&channel=chunlei&bdstoken=<>
body: shareid_list=[29581629787]        ← 数字数组，必须是数组
→ { errno:0 }
```

**这是唯一有效的写法**。已实测的错误写法：

| 写法 | 结果 |
|-|-|
| `?shareid=<id>` 查询参数 + 空 body | `errno 2 参数错误` |
| `?shareid=<id>` + body `shareid=<id>` | `errno 2 参数错误` |
| body 传 JSON 对象 `{"shareid_list":[...]}`（Content-Type: application/json） | `errno 2 参数错误` |
| body `shareid_list=[29581629787]`（表单编码） | `errno 0` ✅ |

### 下载直链

```
GET /rest/2.0/xpan/file?method=filemetas&dlink=1&fsids=[<fs_id>]&app_id=250528
→ { errno:0, info:[{ fs_id, filename, size, md5, dlink }] }
```

拿到 `dlink` 后带 Cookie + 浏览器 UA 直接 GET，返回文件流。
`dlink` 有时效，失败重试一次通常可恢复。

### 转存（四步）

```
① surl = 短链 "1xxxxxxxx" 去掉首字符 '1'
② POST /share/verify?t=<ms>&bioc=1&surl=<surl>&channel=chunlei&web=1&app_id=250528&bdstoken=<>
   body: pwd=<4位>&vcode=&vcode_str=
   → { errno:0, randsk }
③ GET /share/list?shorturl=<surl>&web=5&app_id=250528&desc=1&showempty=0&page=1&num=100
        &order=time&root=1&view_mode=1&channel=chunlei&clienttype=0&bdstoken=<>
   Cookie: BDUSS=..; STOKEN=..; BDCLND=<randsk>
   → { errno:0, share_id, uk, title, expired_type, list:[{ fs_id, server_filename, isdir, size }] }
④ POST /share/transfer?shareid=<>&from=<uk>&ondup=newcopy&channel=chunlei&web=1
        &app_id=250528&clienttype=0&bdstoken=<>&sekey=<randsk>
   body: fsidlist=[<fs_id>,...]&path=/目标目录
   → { errno:0, extra:{ list:[{ from, from_fs_id, to, to_fs_id }] } }
```

转存响应里 **`extra.list[].to` 是服务端实际落点，不一定等于"目标目录 + 原文件名"**。
同目录已存在同名文件时会被自动改名：

```
to: "/来自：WorkBuddy/baidu-baidunetdisk/发布包/百度网盘操作-baidunetdisk-v1.0.0(1).zip"
to_fs_id: 1037817423576232
```

所以 `transfer` 命令必须回报 `target_file_path` 与 `renamed`，否则使用者以为文件叫原名，实际叫 `(1)`。
`extra.to_fs_id` 只在部分响应形态下存在，取值时优先 `extra.list[0].to_fs_id`。

### 删除

```
POST /api/filemanager?opera=delete&clienttype=0&app_id=250528&web=1&channel=chunlei&bdstoken=<>
body: filelist=["/路径"]&async=0&ondup=0
→ { errno:0, info:[{ errno:0, path:"/路径" }] }
```

单文件、空目录、非空目录递归删除都能用同一接口（`filelist` 里放目录路径即递归）。
返回的 `info[].errno` 才是逐项结果，`errno:12` 时要看子错误码。

---

## 三、错误码

| errno | 含义 | 本技能处理 |
|-|-|-|
| 0 | 成功 | — |
| -6 | 未登录 | 提示重新授权 |
| -7 | 路径不存在 / 参数不合法 | 提示检查路径 |
| -8 | 目录已存在 | 视为成功 |
| -9 | 提取码错误 | 提示确认提取码 |
| 2 | 参数错误（同名冲突或格式错） | 区分提示 |
| 12 | 部分失败 | **必须看 `info[].errno`**：`-32` 空间不足，`-30` 同名冲突 |
| 105 | 需要图形验证码 | 提示手动处理 |
| 113 | 下载签名失效 | 可重试 |
| 140 | 分享链接无效/已取消 | 提示找分享方 |
| 200025 | 转存时提取码不匹配 | 提示确认提取码 |
| 31326 | 需要开放平台授权 | 本技能不走这条路，属预期外 |

---

## 四、踩坑清单（这一节最值钱）

1. **`STOKEN` 必须取 `.pan.baidu.com` 域。** `.passport` / `.pcs` / `.pcsdata` 下同名不同值，
   取错直接 `errno=-6 未登录`。
2. **`BDUSS` 取 `.baidu.com`。** `.yoojia.com`、`.apollo.auto` 里也有同名 cookie，但那是别的站点。
3. **`pcs.baidu.com` 的 `method=locatedownload` 不可用。** 返回 `31326 user is not authorized,
   hitcode:125` —— 该接口要开放平台 token，纯 cookie 走不通。改用 `xpan/file?method=filemetas`。
4. **新版 `/disk/home` 页面已不再下发 `sign1` / `sign3`。** 老的 web 下载签名算法彻底失效，
   不要浪费时间在页面里正则找签名参数。
5. **转存的 `surl` 是短链去掉首字符 `1`。** 用完整短链会得到 `errno=140「链接出错了」`。
   `share/list` 的 `shorturl` 也用去掉首字符的值。
6. **`?pwd=` 对服务端抓取无效。** 服务端 GET 分享页只会拿到「请输入提取码」页面，`fs_id` 列表为空。
   必须走 `POST /share/verify` 换 `randsk`，Cookie 追加 `BDCLND=<randsk>`，
   转存还要带 `sekey=<randsk>`，否则报 `200025 提取码输入错误`。
7. **客户端 UA `netdisk;P2SP;3.0.0.8;...` 才能拿到真实分享页**，浏览器 UA 会被导向登录页。
   （本技能的抓取走接口而非页面，但排查时要知道这点。）
8. **`precreate` 的 `block_list` 是 4MB 分片 MD5 数组的 JSON 字符串**，`rtype=3`；
   命中秒传时 `return_type=2`，跳过上传分片直接 `create`。
9. **Git Bash 会把裸 `/` 参数重写成 Git 安装目录**（`node ... list /` 实际收到 `D:/.../PortableGit/`）。
   在 Git Bash 里测试必须 `export MSYS_NO_PATHCONV=1`。
10. **`/share/cancel` 只认表单编码的 `shareid_list=[数字]`**，query 带 `shareid` 或 JSON body 都是参数错误。
11. **删除是进回收站的。** 删除成功后对象仍在回收站里占容量，空间提示必须包含"回收站也要清"。

---

## 五、没有采用的路

| 方案 | 为什么不用 |
|-|-|
| 百度开放平台 API | 转存等能力属付费接口；需要 `access_token`；目录被限制在 `/apps` 下 |
| 官方 MCP / 连接器 | 明确不提供"下载到本地""本地文件上传""删除"；分享强制有效期 + 固定 4 位提取码 |
| `pcs.baidu.com` 下载接口 | 需要开放平台 token（31326） |
| 页面 DOM 自动化 | 页面结构随时变，且慢、易碎；接口稳定得多 |
| 第三方 npm 包 | 违背"零依赖、任何电脑免费可用"的要求，且大多已失修 |
