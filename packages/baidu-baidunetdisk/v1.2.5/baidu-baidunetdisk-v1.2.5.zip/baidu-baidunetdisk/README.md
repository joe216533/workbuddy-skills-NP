# 百度网盘操作（baidu-baidunetdisk）

给 WorkBuddy 用的百度网盘技能。**纯 Node 实现，零第三方依赖，不需要百度开放平台权限**，
任何电脑装好 Node 18+ 就能免费使用。

## 能做什么

- 上传文件（自动 4MB 分片，命中秒传会走秒传）
- 下载文件（带 SHA256 完整性校验）
- 创建分享链接（永久 / 1 天 / 7 天，链接自带提取码，打开自动填）
- 转存别人给的分享链接
- 受限删除（严格白名单目录 + 预览 + 二次核对 + 删后复查）
- 多账号（每个账号独立凭据，互不干扰）

## 不能做什么

不支持下载整个目录、不支持重命名/移动/复制、不支持在线解压、不支持 `bdpan://` 秒传链接。
完整清单见 [docs/limitations.md](docs/limitations.md)。

## 快速开始

```bash
# 1. 环境检查（不需要 npm install）
node scripts/install.js

# 2. 授权（会打开一个可见的浏览器窗口，在里面扫码登录）
node scripts/baidu-baidunetdisk.cjs auth login --as 159

# 3. 看看能不能用
node scripts/baidu-baidunetdisk.cjs verify --as 159

# 4. 传个文件
node scripts/baidu-baidunetdisk.cjs upload ./报告.pdf --to "/来自：WorkBuddy/baidu-baidunetdisk" --as 159

# 5. 生成永久分享（链接会自动带提取码）
node scripts/baidu-baidunetdisk.cjs share "/来自：WorkBuddy/baidu-baidunetdisk/报告.pdf" --period 0 --as 159
```

## 三件必须先知道的事

**第一，授权用的是专用浏览器，不是你日常的浏览器。**
程序会起一个独立 Chrome 实例（独立临时 Profile），窗口是可见的，你自己扫码登录。
用完立即关闭并删除临时 Profile，不碰你的日常浏览器数据。

**第二，开了 VPN 不用关全局 VPN。**
这个专用浏览器带 `--proxy-server=direct://`，只有它走国内直连，其他程序不受影响。

**第三，凭据不能复制到别的电脑。**
Windows 用 DPAPI 绑定当前用户加密，换个用户名或换台机器都解不开。换电脑请重新 `auth login`。

## 删除为什么这么麻烦

因为删除是唯一不可逆的操作。所以本技能给删除加了十道闸：

绝对路径、禁通配符、禁根目录、只允许技能目录内、必须 `--yes`、非空目录必须 `--recursive`、
执行前必须列预览清单、执行前用 `fs_id` 二次核对目标没变、执行后必须复查目标消失、
结果未知时绝不报成功。

删除后文件进入网页端回收站可以恢复，但**回收站仍占容量**，腾空间时要到网页端清空。
详见 [docs/security.md](docs/security.md)。

## 目录说明

```
SKILL.md        给智能体看的完整说明（命令、目录树、复现步骤）
manifest.json   技能元数据（ID、中文名、版本、入口、最低 Node 版本）
scripts/        入口与安装/验证/发布门禁
src/            业务代码（auth / api / storage / safety / verify / utils / cli）
docs/           架构、安全、协议参考、已知限制
tests/          离线单元测试
```

完整目录树与每个文件的职责见 [SKILL.md](SKILL.md) 第二节。

## 测试

```bash
node --test tests/                                          # 离线单元测试，不需要登录
node scripts/verify.js --as 159                             # 只读在线验证
node scripts/verify.js --deep --yes --as 159                # 端到端（会传、会分享、会删）
node scripts/preflight.js                                   # 发布前门禁
```

## 许可

本技能自身使用 MIT 许可，见 [LICENSE](LICENSE)。
零第三方运行时依赖，声明见 [THIRD-PARTY-NOTICES](THIRD-PARTY-NOTICES)。

本技能不是百度官方产品，与百度公司无隶属关系。
