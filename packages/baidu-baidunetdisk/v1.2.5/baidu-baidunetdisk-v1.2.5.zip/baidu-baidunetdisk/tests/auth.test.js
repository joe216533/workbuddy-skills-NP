'use strict';
// 授权与账号（离线部分：别名校验、脱敏、凭据存储方式识别）
const test = require('node:test');
const assert = require('node:assert');
const accounts = require('../src/auth/accounts');
const { redact, redactObject } = require('../src/safety/redaction');
const credentialStore = require('../src/auth/credential-store');

test('别名必须是字母数字下划线短横线，长度 1-32', () => {
  assert.strictEqual(accounts.assertAlias('159'), '159');
  assert.strictEqual(accounts.assertAlias('156'), '156');
  assert.strictEqual(accounts.assertAlias('work_01'), 'work_01');
  assert.throws(() => accounts.assertAlias(''), (e) => e.code === 'BAD_ALIAS');
  assert.throws(() => accounts.assertAlias('has space'), (e) => e.code === 'BAD_ALIAS');
  assert.throws(() => accounts.assertAlias('中文别名'), (e) => e.code === 'BAD_ALIAS');
  assert.throws(() => accounts.assertAlias('a'.repeat(33)), (e) => e.code === 'BAD_ALIAS');
});

test('未指定别名且没有当前账号时，resolve 报 NO_ACCOUNT 而不是乱选一个', () => {
  // 只在索引为空时断言，避免污染已授权的机器
  const idx = accounts.readIndex();
  if (Object.keys(idx.accounts).length > 0) return;
  assert.throws(() => accounts.resolve(), (e) => e.code === 'NO_ACCOUNT');
});

test('指定不存在的别名时报 NO_ACCOUNT', () => {
  assert.throws(() => accounts.resolve('不存在的别名'), (e) => e.code === 'BAD_ALIAS' || e.code === 'NO_ACCOUNT');
  assert.throws(() => accounts.resolve('nobody_999'), (e) => e.code === 'NO_ACCOUNT');
});

test('redact 抹掉鉴权类 cookie，但不碰分享提取码', () => {
  const s = redact('Cookie: BDUSS=abcdefghijk; STOKEN=1234567890; pwd=ab12');
  assert.ok(!s.includes('abcdefghijk'), 'BDUSS 值必须被抹掉');
  assert.ok(!s.includes('1234567890'), 'STOKEN 值必须被抹掉');
  assert.ok(s.includes('pwd=ab12'), '提取码是发给对方的公开信息，不能被抹掉');
});

test('分享链接里的提取码必须原样保留（打码会让链接作废）', () => {
  const url = 'https://pan.baidu.com/s/1LhqCyYGgXFabAAnT_T2-Mg?pwd=gk2p';
  assert.strictEqual(redact(url), url, 'full_url 一旦被打码成 ?pwd=***，接收方永远打不开');
});

test('redact 不能误伤技能 ID 与发布包文件名', () => {
  const name = 'kuake-quarkclouddrive-v1.1.3.zip';
  assert.strictEqual(redact(name), name, '技能 ID 是公开信息，被打码会让用户以为文件名传坏了');
  const path = '/来自：WorkBuddy/baidu-baidunetdisk/镜像-v1.2.3-v1.1.2/kuake-quarkclouddrive-v1.1.3.zip';
  assert.ok(redact(path).includes('kuake-quarkclouddrive-v1.1.3.zip'), '路径里的包名必须可读');
  assert.strictEqual(redact('baidu-baidunetdisk-v1.2.5.zip'), 'baidu-baidunetdisk-v1.2.5.zip');
});

test('redact 仍然要打码真正的凭据长串', () => {
  const token = 'aB3dE5fG7hI9jK1lM3nO5pQ7rS9tU1vW';
  assert.ok(!redact('value: ' + token).includes(token), '混合大小写长串仍必须打码');
});

test('redactObject 只对鉴权字段打码', () => {
  const o = redactObject({ bduss: 'x'.repeat(40), password: 'gk2p', path: '/来自：WorkBuddy/a.txt' });
  assert.ok(o.bduss.startsWith('***'), 'cookie 必须打码');
  assert.strictEqual(o.password, 'gk2p', '提取码必须可读');
  assert.strictEqual(o.path, '/来自：WorkBuddy/a.txt', '路径不应被打码');
});

test('redact 不能误伤哈希值（SHA256 必须可读）', () => {
  const sha = 'a3f5c9d1b7e24680f1a2b3c4d5e6f708192a3b4c5d6e7f8091a2b3c4d5e6f708';
  assert.strictEqual(redact(sha), sha, '纯十六进制是校验值，必须原样输出');
  assert.strictEqual(redact('123456789012345678901234'), '123456789012345678901234', '纯数字不该打码');
  assert.ok(redact('AbC3dEfGh1JkLmN2pQrStUvW3xYz').startsWith('***'), '字母数字混合的长串仍应打码');
});

test('凭据存储方式在已知集合内', () => {
  const k = credentialStore.storeKind();
  assert.ok(
    ['dpapi-currentuser', 'macos-keychain', 'linux-secret-service', 'linux-file-0600'].includes(k),
    `未知的存储方式：${k}`
  );
});

test('credFile 落在本机数据目录的 accounts 下，且文件名用别名', () => {
  const f = credentialStore.credFile('159');
  assert.ok(f.includes('accounts'), f);
  assert.ok(f.endsWith('159.cred'), f);
});

test('参数解析：--as 取值与 --json 开关', () => {
  const { parseArgs } = require('../src/cli/commands');
  assert.deepStrictEqual(parseArgs(['auth', 'status', '--as', '156']), {
    pos: ['auth', 'status'],
    flags: { as: '156' },
  });
  assert.deepStrictEqual(parseArgs(['list', '/', '--as=159', '--json']), {
    pos: ['list', '/'],
    flags: { as: '159', json: true },
  });
  assert.throws(() => parseArgs(['list', '--as']), (e) => e.code === 'USAGE');
  assert.throws(() => parseArgs(['list', '--nope']), (e) => e.code === 'USAGE');
});

// 回归测试：调度器统一以 (args, flags) 调用，函数签名少一个参数会静默丢掉 --as，
// 导致"查 156 却显示了 159"这种极难察觉的错。
test('所有命令函数都必须接收 (pos, flags) 两个参数', () => {
  const { COMMANDS } = require('../src/cli/commands');
  const exempt = new Set(['auth list', 'auth use']); // 这两个命令只吃位置参数，不需要 flags
  for (const [name, fn] of Object.entries(COMMANDS)) {
    if (exempt.has(name)) continue;
    assert.ok(
      fn.length >= 2,
      `命令 ${name} 的函数签名不足两个参数（当前 ${fn.length}），会导致 --as/--yes/--deep 等参数丢失`
    );
  }
});
