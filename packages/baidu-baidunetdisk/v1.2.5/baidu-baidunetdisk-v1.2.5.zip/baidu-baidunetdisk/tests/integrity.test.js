'use strict';
// 路径规范化与安全检查（纯函数，离线可跑）
const test = require('node:test');
const assert = require('node:assert');
const paths = require('../src/storage/paths');

test('normalize 补前导斜杠并折叠重复斜杠', () => {
  assert.strictEqual(paths.normalize('a/b'), '/a/b');
  assert.strictEqual(paths.normalize('//a///b//'), '/a/b');
  assert.strictEqual(paths.normalize('/a/./b'), '/a/b');
  assert.strictEqual(paths.normalize(''), '/');
  assert.strictEqual(paths.normalize('/'), '/');
});

test('normalize 保留全角冒号与中文，不做编码', () => {
  const p = paths.normalize('/来自：WorkBuddy/baidu-baidunetdisk/报告 终版(1).pdf');
  assert.strictEqual(p, '/来自：WorkBuddy/baidu-baidunetdisk/报告 终版(1).pdf');
});

test('normalize 拒绝 .. 越界', () => {
  assert.throws(() => paths.normalize('/../etc'), /越界/);
  assert.strictEqual(paths.normalize('/a/b/../c'), '/a/c');
});

test('hasWildcard 识别通配符', () => {
  assert.ok(paths.hasWildcard('/a/*.txt'));
  assert.ok(paths.hasWildcard('/a/b?.txt'));
  assert.ok(paths.hasWildcard('/a/[abc]'));
  assert.ok(!paths.hasWildcard('/a/普通文件.txt'));
});

test('isUnder 边界正确', () => {
  const root = '/来自：WorkBuddy/baidu-baidunetdisk';
  assert.ok(paths.isUnder(root, root), '根自身算在范围内');
  assert.ok(paths.isUnder(root + '/a.txt', root));
  assert.ok(paths.isUnder(root + '/sub', root));
  // 前缀相似但不是子目录，必须判为不在范围内
  assert.ok(!paths.isUnder(root + '-evil/a.txt', root));
  assert.ok(!paths.isUnder('/来自：WorkBuddy/other/a.txt', root));
});

test('assertAbsolute 拒绝相对路径', () => {
  assert.throws(() => paths.assertAbsolute('a/b'), /绝对路径/);
  assert.strictEqual(paths.assertAbsolute('/a/b'), '/a/b');
});

test('basename / dirname / join', () => {
  assert.strictEqual(paths.basename('/a/b/c.txt'), 'c.txt');
  assert.strictEqual(paths.dirname('/a/b/c.txt'), '/a/b');
  assert.strictEqual(paths.dirname('/a'), '/');
  assert.strictEqual(paths.join('/a', 'b.txt'), '/a/b.txt');
  assert.strictEqual(paths.join('/', 'b.txt'), '/b.txt');
});

test('技能根目录常量使用全角冒号', () => {
  assert.strictEqual(paths.SKILL_ROOT, '/来自：WorkBuddy/baidu-baidunetdisk');
  assert.ok(paths.SKILL_ROOT.includes('：'), '必须是全角冒号，不能改成 ASCII');
  assert.strictEqual(paths.VERIFY_DIR, paths.SKILL_ROOT + '/.verify');
});
