'use strict';
// 转存：分享链接解析（surl 去掉首字符 '1' 是最容易踩的坑，必须有回归测试）
const test = require('node:test');
const assert = require('node:assert');
const { parseShareUrl, mapTransferExtra } = require('../src/api/transfer');

test('解析标准短链并去掉首字符 1', () => {
  const r = parseShareUrl('https://pan.baidu.com/s/1daX01abcdefg');
  assert.strictEqual(r.shorturl, '1daX01abcdefg');
  assert.strictEqual(r.surl, 'daX01abcdefg', 'surl 必须去掉首个 1');
  assert.strictEqual(r.pwdFromUrl, null);
});

test('从链接里取 4 位提取码', () => {
  assert.strictEqual(parseShareUrl('https://pan.baidu.com/s/1abc?pwd=ab12').pwdFromUrl, 'ab12');
  assert.strictEqual(parseShareUrl('https://pan.baidu.com/s/1abc?x=1&pwd=Zz99').pwdFromUrl, 'Zz99');
});

test('兼容不带协议的粘贴形式', () => {
  const r = parseShareUrl('pan.baidu.com/s/1xyz123');
  assert.strictEqual(r.shorturl, '1xyz123');
  assert.strictEqual(r.surl, 'xyz123');
});

test('不带前导 1 的短链原样保留', () => {
  const r = parseShareUrl('https://pan.baidu.com/s/abc123');
  assert.strictEqual(r.surl, 'abc123');
});

test('非法链接明确报错', () => {
  assert.throws(() => parseShareUrl('https://example.com/x'), (e) => e.code === 'BAD_SHARE_URL');
  assert.throws(() => parseShareUrl(''), (e) => e.code === 'BAD_SHARE_URL');
  assert.throws(() => parseShareUrl(null), (e) => e.code === 'BAD_SHARE_URL');
});

// 真实响应结构：extra.list[] = [{ from, from_fs_id, to, to_fs_id }]
// 回归点：result 必须给出实际落点，同名冲突被改名时要能看出来
test('转存结果取 extra.list[0] 的 to_fs_id 与 to', () => {
  const extra = {
    list: [
      {
        from: '/百度网盘操作-baidu-baidunetdisk-v1.0.0.zip',
        from_fs_id: 728573992349071,
        to: '/来自：WorkBuddy/baidu-baidunetdisk/发布包/百度网盘操作-baidu-baidunetdisk-v1.0.0.zip',
        to_fs_id: 1037817423576232,
      },
    ],
  };
  const r = mapTransferExtra(extra, {
    shareUrl: 'https://pan.baidu.com/s/1abc?pwd=ab12',
    files: [{ fs_id: 728573992349071, name: '百度网盘操作-baidu-baidunetdisk-v1.0.0.zip' }],
    target: '/来自：WorkBuddy/baidu-baidunetdisk/发布包',
  });
  assert.strictEqual(r.target_file_id, 1037817423576232);
  assert.strictEqual(r.target_file_path, extra.list[0].to);
  assert.strictEqual(r.renamed, false, '路径与原文件名一致时不算改名');
  assert.strictEqual(r.transfer_status, 'success');
});

test('同名冲突被服务端改名时必须标记 renamed 并给出真实路径', () => {
  const extra = {
    list: [
      {
        from: '/a.zip',
        from_fs_id: 1,
        to: '/来自：WorkBuddy/baidu-baidunetdisk/发布包/a(1).zip',
        to_fs_id: 999,
      },
    ],
  };
  const r = mapTransferExtra(extra, {
    shareUrl: 'https://pan.baidu.com/s/1abc',
    files: [{ fs_id: 1, name: 'a.zip' }],
    target: '/来自：WorkBuddy/baidu-baidunetdisk/发布包',
  });
  assert.strictEqual(r.renamed, true);
  assert.strictEqual(r.target_file_path, '/来自：WorkBuddy/baidu-baidunetdisk/发布包/a(1).zip');
  assert.strictEqual(r.target_file_id, 999);
});

test('extra 缺 list 时不崩，字段置空但不冒充成功路径', () => {
  const r = mapTransferExtra({}, { shareUrl: 'x', files: [{ name: 'a.zip' }], target: '/d' });
  assert.strictEqual(r.target_file_id, null);
  assert.strictEqual(r.target_file_path, null);
});
