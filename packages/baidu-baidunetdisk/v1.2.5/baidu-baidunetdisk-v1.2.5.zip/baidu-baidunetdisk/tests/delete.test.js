'use strict';
// 删除安全闸门（离线部分：路径校验、--yes、递归要求都能在触网前拦下）
const test = require('node:test');
const assert = require('node:assert');
const guard = require('../src/safety/delete-guard');
const paths = require('../src/storage/paths');

const ROOT = paths.SKILL_ROOT;
// 传 null 作为 client：所有被测分支都必须在触网前抛错，才能证明拦截点在网络之前
const NO_CLIENT = null;

test('拒绝空路径', () => {
  assert.throws(() => guard.validateTarget(''), (e) => e.code === 'REFUSED_EMPTY' && e.exit === 4);
  assert.throws(() => guard.validateTarget('   '), (e) => e.code === 'REFUSED_EMPTY');
});

test('拒绝相对路径', () => {
  assert.throws(() => guard.validateTarget('a/b.txt'), (e) => e.code === 'REFUSED_RELATIVE');
  assert.throws(() => guard.validateTarget('./x'), (e) => e.code === 'REFUSED_RELATIVE');
});

test('拒绝通配符', () => {
  for (const p of [`${ROOT}/*`, `${ROOT}/a?.txt`, `${ROOT}/[abc]`, `${ROOT}/{a,b}`]) {
    assert.throws(() => guard.validateTarget(p), (e) => e.code === 'REFUSED_WILDCARD', `应拒绝：${p}`);
  }
});

test('拒绝根目录', () => {
  assert.throws(() => guard.validateTarget('/'), (e) => e.code === 'REFUSED_ROOT');
});

test('拒绝技能目录之外的路径', () => {
  assert.throws(() => guard.validateTarget('/我的文档/a.txt'), (e) => e.code === 'REFUSED_OUTSIDE');
  assert.throws(() => guard.validateTarget('/来自：WorkBuddy/其他技能/a.txt'), (e) => e.code === 'REFUSED_OUTSIDE');
  // 前缀相似的目录不能蒙混过关
  assert.throws(() => guard.validateTarget(`${ROOT}-evil/a.txt`), (e) => e.code === 'REFUSED_OUTSIDE');
});

test('拒绝删除技能目录本身', () => {
  assert.throws(() => guard.validateTarget(ROOT), (e) => e.code === 'REFUSED_SKILL_ROOT');
  assert.throws(() => guard.validateTarget(ROOT + '/'), (e) => e.code === 'REFUSED_SKILL_ROOT');
});

test('拒绝 .. 越界', () => {
  assert.throws(() => guard.validateTarget(`${ROOT}/../../etc/passwd`), (e) => e.code === 'REFUSED_OUTSIDE' || e.code === 'REFUSED_TRAVERSAL');
});

test('允许技能目录内的合法路径', () => {
  assert.strictEqual(guard.validateTarget(`${ROOT}/a.txt`), `${ROOT}/a.txt`);
  assert.strictEqual(guard.validateTarget(`${ROOT}/子目录/b.txt`), `${ROOT}/子目录/b.txt`);
  assert.strictEqual(guard.validateTarget(`${ROOT}//a.txt`), `${ROOT}/a.txt`);
});

test('previewDelete 在触网前就拦下非法路径（client 为 null 也能抛）', async () => {
  await assert.rejects(() => guard.previewDelete(NO_CLIENT, '/'), (e) => e.code === 'REFUSED_ROOT');
  await assert.rejects(() => guard.previewDelete(NO_CLIENT, `${ROOT}/*`), (e) => e.code === 'REFUSED_WILDCARD');
  await assert.rejects(() => guard.previewDelete(NO_CLIENT, '/别的地方/x'), (e) => e.code === 'REFUSED_OUTSIDE');
});

test('executeDelete 缺 --yes 时在二次核对之前就拒绝', async () => {
  const preview = {
    target_path: `${ROOT}/a.txt`,
    target_type: 'file',
    target_file_id: 1,
    target_size: 10,
    preview_item_count: 1,
    preview_total_size: 10,
    recursive: false,
  };
  await assert.rejects(() => guard.executeDelete(NO_CLIENT, preview, { yes: false }), (e) => e.code === 'REFUSED_NO_YES');
});

test('REFUSED 类错误统一使用退出码 4', () => {
  try {
    guard.validateTarget('/');
  } catch (e) {
    assert.strictEqual(e.exit, 4);
  }
});
