'use strict';
// 分享：提取码格式、有效期映射、撤销请求体格式（撤销的 body 格式是实测出来的，回归测试必须盯着）
const test = require('node:test');
const assert = require('node:assert');
const { makePwd, cancelShares, PERIOD_TEXT } = require('../src/api/share');

test('提取码固定 4 位，只含字母数字', () => {
  for (let i = 0; i < 50; i++) {
    const p = makePwd();
    assert.strictEqual(p.length, 4, p);
    assert.match(p, /^[A-Za-z0-9]{4}$/, p);
  }
});

test('有效期文案映射', () => {
  assert.strictEqual(PERIOD_TEXT[0], '永久有效');
  assert.strictEqual(PERIOD_TEXT[7], '7 天');
});

test('空列表不发起撤销请求', async () => {
  let called = false;
  const client = { api: async () => { called = true; return { j: { errno: 0 } }; } };
  const r = await cancelShares(client, []);
  assert.strictEqual(r.ok, false);
  assert.strictEqual(called, false, '没有 share_id 时不应触网');
});

test('撤销请求体必须是表单编码的 shareid_list=[数字]', async () => {
  let captured = null;
  const client = {
    api: async (_path, _params, body) => {
      captured = { path: _path, params: _params, body };
      return { j: { errno: 0 } };
    },
  };
  const r = await cancelShares(client, [29581629787]);
  assert.strictEqual(r.ok, true);
  assert.strictEqual(captured.path, '/share/cancel');
  // 解码后应当等于 shareid_list=[29581629787]
  assert.strictEqual(decodeURIComponent(captured.body), 'shareid_list=[29581629787]');
  assert.ok(!captured.body.includes('shareid='), '不能用 query shareid 写法，实测会返回参数错误');
});

test('撤销失败时返回 ok:false 而不是抛错', async () => {
  const client = { api: async () => ({ j: { errno: 2, show_msg: '参数错误' } }) };
  const r = await cancelShares(client, [123]);
  assert.strictEqual(r.ok, false);
  assert.strictEqual(r.errno, 2);
});

test('撤销时过滤掉非法 id', async () => {
  let ids = null;
  const client = {
    api: async (_p, _q, body) => {
      ids = JSON.parse(decodeURIComponent(body).replace('shareid_list=', ''));
      return { j: { errno: 0 } };
    },
  };
  await cancelShares(client, [0, -1, 'abc', 456]);
  assert.deepStrictEqual(ids, [456]);
});
