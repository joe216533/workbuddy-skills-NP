'use strict';
// 重命名（离线部分：参数校验、扩展名变化提示、同名短路）
const test = require('node:test');
const assert = require('node:assert');
const { renamePath, splitExt } = require('../src/api/rename');

// 假 client：记录调用参数，返回预设结果
function fakeClient(resp) {
  const calls = [];
  return {
    calls,
    async api(pathname, query, body) {
      calls.push({ pathname, query, body });
      if (resp instanceof Error) throw resp;
      return resp;
    },
  };
}

const OK_RESP = {
  http: 200,
  j: {
    errno: 0,
    info: [{ errno: 0, path: '/a/b.txt', to_path: '/a/c.txt' }],
    request_id: 123,
  },
};

test('splitExt 正确拆出主名与后缀', () => {
  assert.deepStrictEqual(splitExt('a.txt'), { stem: 'a', ext: '.txt' });
  assert.deepStrictEqual(splitExt('a.tar.gz'), { stem: 'a.tar', ext: '.gz' });
  assert.deepStrictEqual(splitExt('noext'), { stem: 'noext', ext: '' });
  assert.deepStrictEqual(splitExt('.hidden'), { stem: '.hidden', ext: '' });
});

test('新名字带路径分隔符直接拒绝（防止被当成移动）', async () => {
  const c = fakeClient(OK_RESP);
  await assert.rejects(
    () => renamePath(c, '/a/b.txt', 'sub/c.txt'),
    (e) => e.code === 'BAD_PARAM'
  );
  await assert.rejects(
    () => renamePath(c, '/a/b.txt', 'sub\\c.txt'),
    (e) => e.code === 'BAD_PARAM'
  );
  assert.strictEqual(c.calls.length, 0, '校验失败不应发出请求');
});

test('新名字为空或点目录拒绝', async () => {
  const c = fakeClient(OK_RESP);
  await assert.rejects(() => renamePath(c, '/a/b.txt', '   '), (e) => e.code === 'BAD_PARAM');
  await assert.rejects(() => renamePath(c, '/a/b.txt', '.'), (e) => e.code === 'BAD_PARAM');
  await assert.rejects(() => renamePath(c, '/a/b.txt', '..'), (e) => e.code === 'BAD_PARAM');
});

test('新名字超长拒绝', async () => {
  const c = fakeClient(OK_RESP);
  await assert.rejects(() => renamePath(c, '/a/b.txt', 'x'.repeat(256)), (e) => e.code === 'BAD_PARAM');
});

test('新旧名相同直接返回 unchanged，不发请求', async () => {
  const c = fakeClient(OK_RESP);
  const r = await renamePath(c, '/a/b.txt', 'b.txt');
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.unchanged, true);
  assert.strictEqual(c.calls.length, 0);
});

test('正常改名发出 opera=rename 且 filelist 形态正确', async () => {
  const c = fakeClient(OK_RESP);
  const r = await renamePath(c, '/a/b.txt', 'c.txt');
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.to, '/a/c.txt');
  assert.strictEqual(r.old_name, 'b.txt');
  assert.strictEqual(r.new_name, 'c.txt');
  assert.strictEqual(c.calls.length, 1);
  const call = c.calls[0];
  assert.strictEqual(call.pathname, '/api/filemanager');
  assert.strictEqual(call.query.opera, 'rename');
  const params = new URLSearchParams(call.body);
  const list = JSON.parse(params.get('filelist'));
  assert.deepStrictEqual(list, [{ path: '/a/b.txt', newname: 'c.txt' }]);
  assert.strictEqual(params.get('async'), '0');
  assert.strictEqual(params.get('ondup'), '0');
});

test('改后缀会被标记 ext_changed', async () => {
  const c = fakeClient({
    http: 200,
    j: { errno: 0, info: [{ errno: 0, to_path: '/a/c.exe' }] },
  });
  const r = await renamePath(c, '/a/b.txt', 'c.exe');
  assert.strictEqual(r.ext_changed, true);
  assert.ok(r.note && r.note.includes('后缀'));
});

test('服务端 errno 非 0 时抛出而不是报成功', async () => {
  const c = fakeClient({ http: 200, j: { errno: -8, info: [{ errno: -8 }] } });
  await assert.rejects(() => renamePath(c, '/a/b.txt', 'c.txt'));
});

test('请求抛出异常时报 RENAME_UNKNOWN，绝不报成功', async () => {
  const c = fakeClient(new Error('ECONNRESET'));
  await assert.rejects(
    () => renamePath(c, '/a/b.txt', 'c.txt'),
    (e) => e.code === 'RENAME_UNKNOWN' && /不要直接重复改名/.test(e.message)
  );
});

test('返回非 JSON 时报 RENAME_UNKNOWN', async () => {
  const c = fakeClient({ http: 502, j: null, text: '<html>bad gateway</html>' });
  await assert.rejects(
    () => renamePath(c, '/a/b.txt', 'c.txt'),
    (e) => e.code === 'RENAME_UNKNOWN'
  );
});
