'use strict';
// 自检前置钩子：每天第一次调用本技能时，自动执行一次真实云端保存自检。
// 设计约束：
//   1. 自检是技能内置必要能力，不再因缺少本机私有配置而跳过；
//   2. 自检失败只提示，不阻断业务命令；
//   3. 环境变量防止自检内部再次触发钩子；
//   4. 每日去重只锁定 PASS；NEEDS_AUTH / BLOCKED / FAIL / ERROR 允许条件变化后重试。
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawnSync } = require('node:child_process');

const ROOT = path.join(os.homedir(), '.workbuddy', 'keep-agent');
const CFG = path.join(ROOT, 'config.json');
const STATE = path.join(ROOT, 'state', 'quark.json');
const RUNNER = path.join(__dirname, 'index.js');

function today(tz) {
  const zone = tz || 'Asia/Shanghai';
  try {
    return new Intl.DateTimeFormat('en-CA', { timeZone: zone }).format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

function readPrivateConfig() {
  try {
    if (fs.existsSync(CFG)) return JSON.parse(fs.readFileSync(CFG, 'utf8'));
  } catch {}
  return null;
}

function doneToday(cfg) {
  try {
    const st = JSON.parse(fs.readFileSync(STATE, 'utf8'));
    const ok = st && (st.status === 'PASS' || st.kind === 'ok');
    return Boolean(st && st.date === today(cfg && cfg.timezone) && ok);
  } catch {
    return false;
  }
}

/**
 * 判断本次调用是否应该触发自动自检。
 * 仅递归保护、显式自检命令、授权命令、当日 PASS 不触发；不再有 UNCONFIGURED / OPT_OUT 跳过。
 */
function shouldRun(sub, flags) {
  if (process.env.WB_SELFCHECK_RUNNING === '1') return { run: false, reason: 'RECURSION_GUARD' };
  if (sub === 'selfcheck') return { run: false, reason: 'SELFCHECK_COMMAND' };
  if (String(sub).startsWith('auth')) return { run: false, reason: 'AUTH_COMMAND' };
  const cfg = readPrivateConfig();
  if (doneToday(cfg)) return { run: false, reason: 'DONE_TODAY' };
  return { run: true };
}

function maybeRun(sub, flags) {
  const decide = shouldRun(sub, flags);
  if (!decide.run) return { notRun: decide.reason };

  const r = spawnSync(process.execPath, [RUNNER, 'run', '--platform', 'quark'], {
    env: Object.assign({}, process.env, { WB_SELFCHECK_RUNNING: '1' }),
    encoding: 'utf8',
    timeout: 90000,
    windowsHide: true,
  });

  return {
    code: r.status == null ? -1 : r.status,
    stdout: r.stdout || '',
    stderr: r.stderr || (r.error ? String(r.error.message) : ''),
    timedOut: Boolean(r.error && (r.error.code === 'ETIMEDOUT' || r.error.code === 'ABORT_ERR')),
  };
}

function notice(res) {
  if (!res || res.notRun) return '';
  if (res.timedOut) return '[自检] 今日自检超时未完成，不影响本次命令。可手动重跑：selfcheck\n';
  if (res.code === 0) return '';
  if (res.code === 4) return '[自检] 今日自检未通过，不影响本次命令。查看详情：selfcheck --json\n';
  return `[自检] 自检执行异常（退出码 ${res.code}），不影响本次命令。可手动重跑：selfcheck\n`;
}

module.exports = { maybeRun, notice, shouldRun, ROOT, CFG, STATE };
