#!/usr/bin/env node
'use strict';
// 夸大网盘技能启动自检入口。
//
// 用法：
//   node scripts/selfcheck.cjs          惰性自检（当天已成功则跳过）
//   node scripts/selfcheck.cjs force    强制重跑
//   node scripts/selfcheck.cjs --json   机器可读输出
//
// 为什么需要显式调用：本技能属于托管安装型，实际业务命令由夸克官方 CLI 提供，
// 我们不修改官方 CLI，因此无法在它内部挂前置钩子。改为在 SKILL.md 里要求
// 智能体在每天第一次调用夸克技能前先执行本脚本。
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const RUNNER = path.join(__dirname, 'selfcheck', 'index.js');
const argv = process.argv.slice(2);
const isForce = argv[0] === 'force';
const rest = isForce ? argv.slice(1) : argv;
const cmd = isForce ? 'force' : 'run';

const r = spawnSync(process.execPath, [RUNNER, cmd, '--platform', 'quark', ...rest], {
  env: Object.assign({}, process.env, { WB_SELFCHECK_RUNNING: '1' }),
  stdio: 'inherit',
  timeout: 60000,
  windowsHide: true,
});

if (r.error && (r.error.code === 'ETIMEDOUT' || r.error.code === 'ABORT_ERR')) {
  process.stderr.write('[自检] 执行超时（60s）\n');
  process.exit(5);
}
process.exit(r.status == null ? 5 : r.status);
