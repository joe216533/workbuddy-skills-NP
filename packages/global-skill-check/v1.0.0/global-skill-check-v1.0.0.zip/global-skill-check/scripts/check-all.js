#!/usr/bin/env node
/**
 * global-skill-check check-all.js v2（管理范围收窄 + L0/L1/L2 报告）
 * 只读：枚举 5 个自建门禁技能，逐个调用其 check-version.js v3，汇总 L0。
 * L1 由对话侧自报（本程序输出提示，不替对话判断）；L2 平台接口若无则 UNAVAILABLE。
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const cp = require('node:child_process');

const AS_JSON = process.argv.includes('--json');
const SKILLS_DIR = path.join(os.homedir(), '.workbuddy', 'skills');

// 唯一管理名单（00C 权威，与 release-index 对照）
const MANAGED = [
  { id: 'kuake-quarkclouddrive', target: '1.1.6' },
  { id: 'baidu-baidunetdisk', target: '1.2.8' },
  { id: 'browser-cli-dual-vpn', target: '1.0.4' },
  { id: 'feishu-readwrite', target: '1.0.4' },
  { id: 'global-skill-check', target: '1.0.0' },
];

function stripV(v) { return String(v || '').trim().replace(/^v/, ''); }

function invokeChecker(item) {
  const dir = path.join(SKILLS_DIR, item.id);
  const checker = path.join(dir, 'scripts', 'check-version.js');
  if (!fs.existsSync(checker)) {
    return { ...item, local_version: null, integrity: 'MISSING', version_status: 'CHECK_FAILED',
      execution_allowed: false, exit_code: null, note: 'check-version.js 缺失' };
  }
  const r = cp.spawnSync(process.execPath, [checker, '--json'], {
    cwd: dir, encoding: 'utf8', timeout: 30000, maxBuffer: 4 * 1024 * 1024,
  });
  const code = r.status === null ? -1 : r.status;
  let parsed = null;
  const txt = (r.stdout || '').trim();
  const j = txt.indexOf('{');
  if (j >= 0) { try { parsed = JSON.parse(txt.slice(j)); } catch (_) {} }
  return {
    ...item,
    local_version: parsed ? (parsed.local_version || null) : null,
    integrity: parsed ? (parsed.integrity || '待核验') : '无法校验',
    version_status: parsed ? (parsed.version_status || '待核验') : '无法校验',
    execution_allowed: parsed ? !!parsed.execution_allowed : false,
    exit_code: code,
    note: r.stderr && r.stderr.trim() ? r.stderr.trim().slice(0, 120) : undefined,
  };
}

const report = {
  checker: 'global-skill-check', checker_version: '2.0-managed',
  generated_at: new Date().toISOString(), readonly: true,
  scope: MANAGED.map((m) => m.id),
  L0: [], L1: { mode: '对话侧自报（本程序不替对话判断）', items: [] },
  L2: { status: 'UNAVAILABLE', note: '平台未提供当前会话实际加载版本接口；不得用 L0/L1 冒充' },
};

for (const m of MANAGED) {
  report.L0.push(invokeChecker(m)); // 单技能失败不阻断
  report.L1.items.push({ id: m.id, target: m.target,
    self_reported_version: '由对话侧从当前实际可用技能定义独立读取',
    status: 'UNKNOWN（本程序不推断，须对话侧提供）' });
}

const s = { managed: MANAGED.length,
  verified: report.L0.filter((x) => x.integrity === 'VERIFIED').length,
  modified_local: report.L0.filter((x) => x.integrity === 'MODIFIED_LOCAL').length,
  issues: report.L0.filter((x) => ['MISSING','HASH_MISMATCH','无法校验','待核验'].includes(x.integrity)).length };
report.summary = s;

if (AS_JSON) {
  console.log(JSON.stringify(report, null, 2));
} else {
  console.log('================================');
  console.log('全局技能自查报告 v2（只读）');
  console.log('检查时间：' + report.generated_at);
  console.log('管理范围：' + s.managed + ' 个自建门禁技能（第三方/其他本地技能未检查）');
  console.log('================================');
  console.log('一、本机安装 L0');
  console.log('技能 | 目标版本 | 本机版本 | 完整性 | 版本状态 | 执行允许');
  console.log('--------------------------------');
  for (const x of report.L0) {
    console.log([x.id, x.target, stripV(x.local_version || '?'), x.integrity,
      x.version_status, x.execution_allowed ? 'YES' : 'NO'].join(' | '));
  }
  console.log('--------------------------------');
  console.log('二、当前对话自报 L1：须由对话侧从当前实际可用技能定义独立读取版本与版本标记');
  console.log('    禁止用磁盘 manifest / release-index / 暗语版本 / 历史记录代替。');
  console.log('三、平台直接验证 L2：' + report.L2.status + '（' + report.L2.note + '）');
  console.log('四、汇总：已验证 ' + s.verified + '；已登记本地修改 ' + s.modified_local + '；异常/待核验 ' + s.issues);
  console.log('结论：L0 通过不等于 L1 通过；L0+L1 通过不等于 L2 通过。');
  console.log('非管理范围：其他技能未检查。');
  console.log('只读：未安装、未升级、未覆盖、未修改任何文件');
  console.log('================================');
}
process.exitCode = report.L0.some((x) => ['MISSING','HASH_MISMATCH','无法校验'].includes(x.integrity)) ? 1 : 0;
