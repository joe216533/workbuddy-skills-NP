#!/usr/bin/env node
/**
 * global-skill-check：全局技能自查管理器 v1.0
 *
 * 职责：枚举本机全部已安装自建技能 → 逐个调用其 check-version.js → 统一汇总。
 * 只读：不安装、不升级、不覆盖、不修改任何技能文件。
 *
 * 用法：node check-all.js [--json] [--skills <dir>]
 *   --json   结构化输出
 *   --skills 指定技能根目录（默认 ~/.workbuddy/skills）
 */
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const cp = require('node:child_process');

const AS_JSON = process.argv.includes('--json');
const SKILLS_DIR = (() => {
  const i = process.argv.indexOf('--skills');
  return i >= 0 ? process.argv[i + 1] : path.join(os.homedir(), '.workbuddy', 'skills');
})();

// 自建技能判定：有 manifest.json 且含 skill_id/id 的目录；排除备份/临时/非技能目录
const EXCLUDE = /(^|[._-])(bak|backup|old|copy|tmp|temp|removed|install_tmp)([._-]|$)|^global-skill-check$/i;

// check-version.js v2 退出码语义
const EXIT_MAP = {
  0: { status: 'UP_TO_DATE', note: '版本检查通过' },
  1: { status: 'UPDATE_AVAILABLE', note: '版本不一致或本地落后' },
  2: { status: 'INTEGRITY_FAILED', note: '本地文件缺失/格式错误' },
  3: { status: 'NETWORK_ERROR', note: '本地通过但远程不可用' },
  4: { status: 'CHECK_FAILED', note: '检查器自身异常' },
  10: { status: 'INTEGRITY_FAILED', note: '完整性检查失败' },
};

function discover() {
  const out = [];
  if (!fs.existsSync(SKILLS_DIR)) return out;
  for (const name of fs.readdirSync(SKILLS_DIR)) {
    if (EXCLUDE.test(name)) continue;
    const dir = path.join(SKILLS_DIR, name);
    if (!fs.statSync(dir).isDirectory()) continue;
    const mf = path.join(dir, 'manifest.json');
    if (!fs.existsSync(mf)) continue;
    let data = null;
    try { data = JSON.parse(fs.readFileSync(mf, 'utf8')); } catch (_) { continue; }
    const sid = data.skill_id || data.id || data.name;
    if (!sid) continue;
    out.push({ dir_name: name, skill_id: sid, version: data.version || null,
      has_checker: fs.existsSync(path.join(dir, 'scripts', 'check-version.js')) });
  }
  return out.sort((a, b) => a.skill_id.localeCompare(b.skill_id));
}

function invoke(item) {
  const checker = path.join(SKILLS_DIR, item.dir_name, 'scripts', 'check-version.js');
  if (!item.has_checker || !fs.existsSync(checker)) {
    return { ...item, gate_status: 'CHECK_FAILED', execution_allowed: false,
      detail: '缺少 scripts/check-version.js', raw_exit: null };
  }
  let r;
  try {
    r = cp.spawnSync(process.execPath, [checker, '--json'], {
      cwd: path.join(SKILLS_DIR, item.dir_name),
      encoding: 'utf8', timeout: 30000, maxBuffer: 4 * 1024 * 1024,
    });
  } catch (e) {
    return { ...item, gate_status: 'CHECK_FAILED', execution_allowed: false, detail: String(e.message) };
  }
  const code = r.status === null ? -1 : r.status;
  let parsed = null;
  const txt = (r.stdout || '').trim();
  const j = txt.indexOf('{');
  if (j >= 0) { try { parsed = JSON.parse(txt.slice(j)); } catch (_) {} }
  const mapped = EXIT_MAP[code] || { status: 'CHECK_FAILED', note: '未知退出码 ' + code };
  return {
    ...item,
    gate_status: (parsed && parsed.status) || mapped.status,
    execution_allowed: parsed ? !!parsed.execution_allowed : (code === 0),
    remote_version: parsed ? (parsed.latest_version || parsed.remote_version || null) : null,
    integrity: parsed && parsed.integrity ? parsed.integrity.status : 'UNKNOWN',
    exit_code: code,
    detail: mapped.note + (r.stderr && r.stderr.trim() ? ' | stderr: ' + r.stderr.trim().slice(0, 160) : ''),
  };
}

const report = {
  checker: 'global-skill-check',
  checker_version: '1.0',
  generated_at: new Date().toISOString(),
  skills_dir: SKILLS_DIR,
  note: '只读全局自查。当前对话加载状态需由对话侧另行提供，本程序不推断。',
  skills: [],
  summary: {},
};

const items = discover();
for (const it of items) {
  report.skills.push(invoke(it)); // 单个失败不影响其他
}
const c = {};
for (const s of report.skills) c[s.gate_status] = (c[s.gate_status] || 0) + 1;
report.summary = {
  discovered: report.skills.length,
  by_status: c,
  need_upgrade: c.UPDATE_AVAILABLE || 0,
  integrity_failed: (c.INTEGRITY_FAILED || 0),
  check_failed: (c.CHECK_FAILED || 0),
  network_error: (c.NETWORK_ERROR || 0),
  current: c.UP_TO_DATE || 0,
  readonly: true,
};

if (AS_JSON) {
  console.log(JSON.stringify(report, null, 2));
} else {
  console.log('================================');
  console.log('全局技能自查（只读）— ' + report.generated_at);
  console.log('技能目录：' + SKILLS_DIR);
  console.log('================================');
  console.log('技能ID | 本机版本 | 远程版本 | 完整性 | 版本门禁 | 执行允许');
  console.log('--------------------------------');
  for (const s of report.skills) {
    console.log([s.skill_id, s.version || '?', s.remote_version || '?', s.integrity,
      s.gate_status, s.execution_allowed ? 'YES' : 'NO'].join(' | '));
  }
  console.log('--------------------------------');
  console.log('发现 ' + report.summary.discovered + ' 个技能；最新 ' + report.summary.current +
    '；需升级 ' + report.summary.need_upgrade + '；完整性异常 ' + report.summary.integrity_failed +
    '；检查失败 ' + report.summary.check_failed + '；网络不可用 ' + report.summary.network_error);
  console.log('当前对话加载状态：本程序不推断，须由对话侧独立提供（无证据=当前未知）');
  console.log('只读：未安装、未升级、未覆盖、未修改任何技能文件');
  console.log('================================');
}
process.exitCode = (report.summary.check_failed || report.summary.integrity_failed) ? 2 : 0;
