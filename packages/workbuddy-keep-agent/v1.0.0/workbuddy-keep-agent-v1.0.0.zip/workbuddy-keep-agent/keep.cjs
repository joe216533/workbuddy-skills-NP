'use strict';
// 技能启动自检 —— 每天首次调用时执行一次真实转存，验证链路是否可用
// 用法：
//   node keep.cjs run            惰性自检（当天已成功则跳过）
//   node keep.cjs force          强制自检（忽略当天记录）
//   node keep.cjs status         查看今日状态
//   node keep.cjs history        查看历史
//   node keep.cjs init           检查配置与初始化项
const fs = require('node:fs');
const path = require('node:path');

const C = require('./lib/common.cjs');
const { quark, baidu } = require('./lib/adapters.cjs');

const ADAPTERS = { quark, baidu };
const CFG_PATH = path.join(C.ROOT, 'config.json');
const MANIFEST_PATH = path.join(C.ROOT, 'manifest.json');

// 版本号单一来源：manifest.json。读不到时降级为 0.0.0，不阻断自检。
function readAgentVersion() {
  try {
    return JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8')).version || '0.0.0';
  } catch {
    return '0.0.0';
  }
}
const AGENT_VERSION = readAgentVersion();

function loadConfig() {
  if (!fs.existsSync(CFG_PATH)) {
    throw new Error(`${C.E.LOCAL_CONFIG_MISSING}: 找不到配置 ${CFG_PATH}`);
  }
  return JSON.parse(fs.readFileSync(CFG_PATH, 'utf8'));
}

function pickPlatforms(cfg, want) {
  const keys = want && want !== 'all' ? [want] : Object.keys(cfg.platforms);
  return keys
    .filter((k) => ADAPTERS[k])
    .map((k) => ({ id: k, cfg: cfg.platforms[k] }))
    .filter((p) => p.cfg && p.cfg.enabled !== false);
}

// 跑一个平台的自检，返回结构化结果
function selfCheck(cfg, platformId, pc, platformCfg) {
  const ad = ADAPTERS[platformId];
  const th = cfg.thresholds;
  const probeName = cfg.probe.filename;
  const steps = [];
  const t0 = Date.now();

  // ① 本地状态
  let s = ad.checkLocal(pc);
  steps.push({ n: 1, name: '本地状态', ...s });
  if (!s.ok) {
    return finish(C.KIND.CLEAR_FAULT, s.error);
  }

  // ② 保存方账号 + 容量
  const saver = ad.checkSaver(pc);
  if (!saver.ok) {
    steps.push({ n: 2, name: '保存方账号', ok: false, error: saver.error, raw: saver.raw });
    return finish(C.KIND.CLEAR_FAULT, saver.error, { steps });
  }
  const space = C.classifySpace(saver.free, th);
  steps.push({
    n: 2, name: '保存方账号', ok: true,
    detail: `${saver.nickname || pc.saver_alias} · 剩余 ${C.humanSize(saver.free)} · ${space.status}`,
    space,
  });
  if (space.level === 'deny') {
    return finish(C.KIND.CLEAR_FAULT, C.E.SPACE_INSUFFICIENT, { steps, saver, space });
  }

  // ③ 分享链接
  const link = ad.checkLink(pc);
  if (!link.ok) {
    steps.push({ n: 3, name: '分享链接', ok: false, error: link.error, raw: link.raw });
    return finish(C.KIND.CLEAR_FAULT, link.error, { steps, saver, space });
  }
  steps.push({
    n: 3, name: '分享链接',
    ok: true,
    skipped: link.skipped === true,
    detail: link.skipped
      ? `跳过（${link.reason}）`
      : `${link.expired_type === 1 ? '永久有效' : `有效期 ${link.expired_type}`} · ${link.file_num} 个文件`,
  });

  // ④ 真实转存
  const save = ad.doSave(pc);
  if (!save.ok) {
    steps.push({ n: 4, name: '真实转存', ok: false, error: save.error, raw: save.raw });
    // 关键：只有「各环都正常 + 报无法解释的错」才算疑似技能异常
    const explainable = [
      C.E.AUTH_EXPIRED, C.E.AUTH_INVALID, C.E.SPACE_INSUFFICIENT,
      C.E.LINK_INVALID, C.E.PASSCODE_INVALID, C.E.PERMISSION_DENIED,
      C.E.RATE_LIMITED, C.E.NETWORK_ERROR, C.E.PLATFORM_ERROR, C.E.QUOTA_EXCEEDED,
    ];
    const kind = explainable.includes(save.error) ? C.KIND.CLEAR_FAULT : C.KIND.SUSPECT_SKILL;
    return finish(kind, save.error, { steps, saver, space, raw: save.raw });
  }
  steps.push({
    n: 4, name: '真实转存', ok: true,
    detail: `${((Date.now() - t0) / 1000).toFixed(1)}s`,
  });

  // ⑤ 结果核验（不能只看退出码）
  const vr = ad.verifyResult(pc, probeName);
  if (!vr.ok) {
    steps.push({ n: 5, name: '结果核验', ok: false, error: vr.error });
    return finish(C.KIND.SUSPECT_SKILL, vr.error, { steps, saver, space, save });
  }
  steps.push({
    n: 5, name: '结果核验', ok: true,
    detail: `${vr.filename} · ${C.humanSize(vr.size)} · 归档共 ${vr.count} 个`,
  });

  // ⑥ 归档改名：只是为了让用户一眼看出哪批能删，失败不影响自检结论
  const rn = cfg.keep_rename || {};
  if (rn.enabled && ad.renameSaved) {
    const dateStamp = (cfg.__today || '').replace(/-/g, '');
    const target = String(rn.pattern || '可删除_{date}_自检副本')
      .replace('{date}', dateStamp) + '.txt';
    const rr = ad.renameSaved(pc, vr, target);
    if (rr.ok) {
      steps.push({
        n: 6, name: '归档改名', ok: true,
        detail: rr.unchanged ? '无需改名' : `→ ${rr.to}`,
      });
    } else {
      steps.push({
        n: 6, name: '归档改名', ok: true, degraded: true,
        detail: `未改名（${rr.error || rr.reason || '未知原因'}），不影响自检结论`,
      });
    }
  }

  return finish(C.KIND.OK, null, { steps, saver, space, save, vr });

  function finish(kind, errorCode, extra = {}) {
    return {
      platform: platformId,
      label: ad.label,
      kind,
      errorCode: errorCode || null,
      hint: errorCode ? (C.HINT[errorCode] || '') : '',
      steps: extra.steps || steps,
      account: extra.saver ? {
        alias: pc.saver_alias, nickname: extra.saver.nickname,
        free: extra.saver.free, total: extra.saver.total, used: extra.saver.used,
        spaceStatus: extra.space?.status || 'UNKNOWN',
      } : null,
      spaceWarning: extra.space ? extra.space.level === 'warn' : false,
      elapsedMs: Date.now() - t0,
      rawTail: extra.raw || undefined,
    };
  }
}

function printResult(r, opts = {}) {
  if (opts.json) return;
  const mark = (s) => (s.ok === false ? 'FAIL' : s.skipped ? 'SKIP' : 'PASS');
  console.log(`\n[自检] ${r.label} · ${r.account?.nickname || ''}`);
  for (const s of r.steps || []) {
    const extra = s.detail ? `  ${s.detail}` : '';
    const err = s.error ? `  [${s.error}]` : '';
    console.log(`  ${'①②③④⑤⑥'[s.n - 1]} ${s.name.padEnd(10, ' ')} ${mark(s).padEnd(4, ' ')}${extra}${err}`);
  }
  const head = r.kind === C.KIND.OK
    ? '结论：正常'
    : r.kind === C.KIND.CLEAR_FAULT
      ? `结论：明确故障 · ${r.errorCode}`
      : `结论：疑似技能异常 · ${r.errorCode}`;
  console.log(`  ${head}`);
  if (r.hint) console.log(`  提示：${r.hint}`);
  if (r.spaceWarning && r.kind === C.KIND.OK) {
    console.log('  注意：保存方空间偏低，建议关注');
  }
}

function cmdRun(argv) {
  const opts = parseArgs(argv);
  const cfg = loadConfig();
  const tz = cfg.timezone;
  const today = C.todayStamp(tz);
  cfg.__today = today;
  const targets = pickPlatforms(cfg, opts.platform);
  const out = [];

  for (const { id, cfg: pc } of targets) {
    const st = C.readState(id);
    // 惰性：当天已成功则跳过（force 不看）
    if (!opts.force && st && st.date === today && st.kind === C.KIND.OK) {
      out.push({ platform: id, skippedBecauseDoneToday: true, state: st });
      if (!opts.json && !opts.quiet) {
        console.log(`\n[自检] ${ADAPTERS[id].label} · 今天已完成（${st.checkedAt}），跳过`);
      }
      continue;
    }

    const lock = C.acquireLock(id);
    if (!lock) {
      out.push({ platform: id, skippedBecauseLocked: true });
      if (!opts.json && !opts.quiet) console.log(`\n[自检] ${ADAPTERS[id].label} · 另一个自检正在运行，跳过`);
      continue;
    }

    let r;
    try {
      r = selfCheck(cfg, id, pc, cfg);
    } catch (e) {
      r = {
        platform: id, label: ADAPTERS[id].label,
        kind: C.KIND.SUSPECT_SKILL, errorCode: C.E.SAVE_FAILED,
        hint: '自检执行异常：' + e.message, steps: [],
      };
    } finally {
      lock.release();
    }

    const rec = {
      date: today,
      checkedAt: C.nowISO(tz),
      agentVersion: AGENT_VERSION,
      kind: r.kind,
      errorCode: r.errorCode,
      account: r.account?.alias || pc.saver_alias,
      spaceStatus: r.account?.spaceStatus || 'UNKNOWN',
      elapsedMs: r.elapsedMs,
      hint: r.hint,
    };
    C.writeState(id, rec);
    C.appendHistory(id, { ...rec, rawTail: r.rawTail });

    out.push(r);
    if (!opts.json) printResult(r, opts);
  }

  if (opts.json) console.log(JSON.stringify(out, null, 2));

  const bad = out.filter((x) => x.kind && x.kind !== C.KIND.OK);
  return bad.length === 0 ? 0 : 4; // 4 = 自检未通过（不阻断调用方）
}

function cmdStatus(argv) {
  const opts = parseArgs(argv);
  const cfg = loadConfig();
  const today = C.todayStamp(cfg.timezone);
  const rows = Object.keys(cfg.platforms).map((id) => {
    const st = C.readState(id);
    return { platform: id, label: ADAPTERS[id]?.label || id, today, state: st };
  });
  if (opts.json) { console.log(JSON.stringify(rows, null, 2)); return 0; }
  console.log(`\n自检状态（今天 ${today}）`);
  for (const r of rows) {
    if (!r.state) { console.log(`  ${r.label.padEnd(6)} 尚未自检`); continue; }
    const okToday = r.state.date === today;
    const tag = r.state.kind === C.KIND.OK ? '正常' : r.state.errorCode || '异常';
    console.log(`  ${r.label.padEnd(6)} ${okToday ? '今天已做' : '今天未做'} · 最近 ${r.state.date} ${r.state.checkedAt?.slice(11, 19)} · ${tag}`);
  }
  return 0;
}

function cmdHistory(argv) {
  const opts = parseArgs(argv);
  const cfg = loadConfig();
  const limit = Number(opts.limit || 20);
  for (const id of Object.keys(cfg.platforms)) {
    if (opts.platform && opts.platform !== 'all' && opts.platform !== id) continue;
    const h = C.readHistory(id, limit);
    console.log(`\n${ADAPTERS[id]?.label || id} · 最近 ${h.length} 次`);
    if (!h.length) { console.log('  （无记录）'); continue; }
    for (const x of h.slice(-limit)) {
      const tag = x.kind === C.KIND.OK ? 'OK  ' : (x.errorCode || 'ERR ');
      console.log(`  ${x.date} ${x.checkedAt?.slice(11, 19) || ''}  ${tag}  ${x.spaceStatus || ''}  ${x.elapsedMs || ''}ms`);
    }
    // 连续失败统计
    let streak = 0;
    for (let i = h.length - 1; i >= 0; i--) {
      if (h[i].kind === C.KIND.OK) break;
      streak++;
    }
    if (streak > 0) console.log(`  连续失败 ${streak} 次`);
  }
  return 0;
}

function cmdInit() {
  if (!fs.existsSync(CFG_PATH)) {
    const tpl = path.join(__dirname, 'config.example.json');
    console.log('\n自检配置检查');
    console.log(`  配置：${CFG_PATH}`);
    console.log('  状态：未初始化（config.json 不存在）');
    console.log('\n首次使用请执行：');
    console.log(`    mkdir -p "${C.ROOT}"`);
    console.log(`    cp "${tpl}" "${CFG_PATH}"`);
    console.log('  然后编辑 config.json，替换所有 <FILL_ME: ...> 占位符后再运行 init。');
    return 5;
  }
  const cfg = loadConfig();
  console.log('\n自检配置检查');
  console.log(`  配置：${CFG_PATH}`);
  console.log(`  时区：${cfg.timezone}`);
  console.log(`  探针：${cfg.probe.filename}（${cfg.probe.expected_min_bytes}-${cfg.probe.expected_max_bytes} B）`);
  for (const [id, pc] of Object.entries(cfg.platforms)) {
    const ad = ADAPTERS[id];
    const localOk = ad ? ad.checkLocal(pc).ok : false;
    console.log(`  ${(ad?.label || id).padEnd(6)} 脚本 ${localOk ? 'PASS' : 'MISSING'} · 分享 ${pc.share_url}`);
  }
  return 0;
}

function parseArgs(argv) {
  const o = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--json') o.json = true;
    else if (a === '--quiet') o.quiet = true;
    else if (a === '--force') o.force = true;
    else if (a === '--platform') o.platform = argv[++i];
    else if (a === '--limit') o.limit = argv[++i];
  }
  return o;
}

const cmd = process.argv[2] || 'run';
const rest = process.argv.slice(3);
let code = 0;
try {
  if (cmd === 'run') code = cmdRun(rest);
  else if (cmd === 'force') code = cmdRun(['--force', ...rest]);
  else if (cmd === 'status') code = cmdStatus(rest);
  else if (cmd === 'history') code = cmdHistory(rest);
  else if (cmd === 'init') code = cmdInit();
  else if (cmd === 'version' || cmd === '--version' || cmd === '-v') {
    console.log(`workbuddy-keep-agent v${AGENT_VERSION}`);
    code = 0;
  } else {
    console.log('用法：node keep.cjs <run|force|status|history|init|version> [--platform quark|baidu|all] [--json]');
    code = 1;
  }
} catch (e) {
  console.error('自检失败：' + e.message);
  code = 5;
}
process.exit(code);
