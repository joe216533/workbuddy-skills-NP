# workbuddy-keep-agent

WorkBuddy 技能的**启动前置自检**模块。每天首次调用技能时执行一次真实转存，验证「本地状态 → 保存方账号 → 分享链接 → 真实转存 → 结果核验」整条链路是否可用，并按层级定位故障环节。

## 设计原则

1. **与官方技能包隔离**：本模块不进夸克、百度等官方技能目录，官方包一行不改，官方升级不会被覆盖。
2. **配置与代码分离**：代码在安装目录，配置与状态固定在 `~/.workbuddy/keep-agent/`。重装或升级本模块不会丢历史状态。
3. **包内零凭据**：分发包只含配置模板，不含分享链接、提取码、账号令牌。真实 `config.json` 由使用方本地生成。
4. **自检不阻断业务**：自检失败只提示，不锁死技能。自检是前置检查，不是新的单点故障。

## 环境要求

- Node.js >= 16
- 零第三方依赖，不需要 `npm install`

## 安装

解压后把 `keep.cjs`、`lib/`、`manifest.json`、`config.example.json` 放到同一目录，例如 `~/.workbuddy/keep-agent-src/`。

首次使用需要生成配置：

```bash
mkdir -p ~/.workbuddy/keep-agent
cp config.example.json ~/.workbuddy/keep-agent/config.json
```

然后编辑 `config.json`，把所有 `<FILL_ME: ...>` 占位符替换为实际值。至少需要：

| 字段 | 含义 |
|-|-|
| `platforms.<平台>.share_url` | 分享方账号创建的固定分享链接 |
| `platforms.<平台>.passcode` | 提取码，无则留空字符串 |
| `platforms.<平台>.saver_cli` | 执行保存的 CLI 绝对路径 |
| `platforms.<平台>.archive_fid` / `archive_path` | 归档目录标识，用于直接存入归档目录 |
| `thresholds.deny_free_bytes` | 低于此剩余空间直接判空间不足，默认 20MB |

配置完成后自检初始化项：

```bash
node keep.cjs init
```

## 用法

```bash
node keep.cjs run                 # 惰性自检：当天已成功则跳过
node keep.cjs run --platform quark
node keep.cjs force               # 强制重跑，忽略当天记录
node keep.cjs status              # 查看今日状态
node keep.cjs history --limit 20  # 查看历史
node keep.cjs init                # 检查配置完整性
node keep.cjs version             # 输出版本号
node keep.cjs run --json          # 机器可读输出
```

退出码：

| 码 | 含义 |
|-|-|
| 0 | 自检通过 |
| 4 | 自检未通过（调用方应继续业务，不要中断） |
| 5 | 执行异常 |

## 五层检查

| 层 | 检查内容 | 能得出的结论 | 不能得出的结论 |
|-|-|-|-|
| ① 本地状态 | 脚本、配置、命令是否存在 | 本地环境是否完整 | 远端服务是否可用 |
| ② 保存方账号 | 令牌有效、可读取账号与配额 | 保存方登录态是否有效 | 分享方账号是否正常 |
| ③ 分享链接 | 固定链接可访问、提取码正确、文件存在 | 当前分享是否可访问 | 分享方账号登录态是否有效 |
| ④ 真实转存 | 实际执行一次转存 | 当前转存接口是否成功 | 所有文件类型、所有场景均可转存 |
| ⑤ 结果核验 | 目标目录是否出现本次文件、核对名称与大小 | 本次落盘是否真实发生 | 平台接口是否永久稳定 |

第⑤层不依赖命令退出码。必须核对实际保存结果，否则无法区分「命令成功但没存上」。

## 分层诊断

错误码覆盖本地、鉴权、空间、链接、权限、限流、网络、平台、命名、结果缺失等类别，最终归为两类结论：

- **明确故障**：已定位到具体原因（登录态过期、空间不足、链接失效、提取码错误、网络不通等），提示对应处理方式。
- **疑似技能异常**：账号有效、空间充足、分享可访问、网络正常，但转存仍返回无法解释的错误。只有这种情况才提示检查技能版本或更新脚本。

不把「空间充足但保存失败」一律判为脚本问题——平台限流、账号限制、分享权限变化、服务端 5xx、目标目录权限不足都可能发生在脚本完全正常时。

## 状态与历史

```
~/.workbuddy/keep-agent/
├── config.json          配置（含链接与账号信息，禁止提交或分发）
├── state/
│   ├── quark.json       当日状态，按平台分开
│   └── baidu.json
└── history/
    ├── quark.jsonl      历史记录，每次追加一行
    └── baidu.jsonl
```

- 状态按平台分别记录，一个平台通过不代表另一个也通过。
- 历史为 JSON Lines 格式，追加写入，不重写整个文件。
- 每条记录含 `date`、`checkedAt`、`agentVersion`、`kind`、`errorCode`、`account`、`spaceStatus`、`elapsedMs`。
- 自然日按 `config.json` 的 `timezone` 计算，不依赖各机器系统时区。
- 同一台机器用文件锁避免并发重复触发；锁超过 10 分钟视为陈旧锁。

## 安全

- `config.json` 含分享链接与账号别名，**不要提交到 Git、不要打包分发、不要截图外传**。
- 分发包内只有 `config.example.json` 模板。
- 归档副本统一放入「自检归档-可删除」目录并按日期命名，由用户自行决定何时清理。

## 版本

当前 `1.0.0`。版本号以 `manifest.json` 为唯一来源。

## 许可

见包内 `LICENSES/THIRD-PARTY-NOTICES.md`。
