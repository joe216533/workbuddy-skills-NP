# 飞书读写技能 v1.0.0

本包轻量 CLI + 官方全局 `lark-cli` 后端。覆盖飞书文档、多维表格（Base）、电子表格（Sheets）的常用读写，附带操作规范、写后回读与自检。

## 安装

1. 解压到技能目录 `feishu-readwrite/`（目录名必须与 name 一致）
2. Node ≥ 18
3. 安装并授权官方 lark-cli（本包不复制、不重新实现飞书 API）
4. 跑 `node bin/feishu.js doctor` 确认依赖和鉴权
5. 跑 `node bin/feishu.js selfcheck` 看自检状态

## 命令

```bash
node bin/feishu.js doctor                       # 依赖/鉴权/版本
node bin/feishu.js selfcheck                    # F1–F8 自检
node bin/feishu.js cli docs +fetch --doc <URL> --doc-format markdown
node bin/feishu.js verify-doc <URL> <文本>       # 文档写入回读
node bin/feishu.js verify-cell <token> <range> <值...>
```

完整命令映射见 `references/command-map.md`，操作规则见 `references/operation-rules.md`（必读）。

## 首版范围

- **Docs**：新建/读取/搜索/非破坏性更新/附件/重命名/历史
- **Base**：新建/建表/字段/记录增改查/视图/重命名
- **Sheets**：新建/单元格读写/清空/批量更新/重命名
- **Drive**：文件夹创建/列表/移动/复制/改名；删除默认禁止自动执行

不支持：官方 200+ 命令的完整封装、白板/图表/复杂格式、历史版本恢复、自动批量清理业务数据。

## 自检诚实性

没有配置专用测试资源（`tests/test-resources.json`）时，F8 写入闭环标 BLOCKED、整体 PARTIAL，不假 PASS。不拿正式业务资料做自检写入。
