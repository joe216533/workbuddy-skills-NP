# 飞书读写技能 · 官方命令映射（v1.0.0）

核实方式：逐条读 `lark-cli <域> --help` 与子命令 `--help`（lark-cli v1.0.98，2026-11-27）。
**不得凭命令名猜参数**；新增命令必须先核实真实帮助。

## 0. 调用方式（本机实测踩坑）

- `lark-cli` 是 bash 包装脚本：Python `subprocess` 调用必须用 `["bash", "<lark-cli路径>", ...]`，直接调会 `FileNotFoundError`
- `--content @file` 经 bash 传中文/绝对路径会被拆错：用 shell 循环 + 相对文件名最稳
- 含中文的 JSON 参数（`sheets +cells-set --cells`、`base +record-upsert --json`）**不能内联**，必须写文件后 `@./payload.json`；CLI 会明确报错提示这一点
- `base +record-upsert` 里 `--json` 既是数据参数又是输出格式 flag：数据用 `--json '{...}'`，输出格式用 `--format json`（不能两个 `--json`）
- 写命令有 `Risk: write / high-risk-write`；高风险需 `--yes`，且必须老板确认（本技能默认不自动删除）
- 自检写入必须幂等：用 `docs +update --command append` 追加唯一标记，不要用 `str_replace` 替换固定文本（第二次跑会因旧文本已变而 FAIL）

## 1. Docs 文档

| 能力 | 命令 | 关键参数 | 核实状态 |
|-|-|-|-|
| 新建 | `docs +create` | `--title` `--content @file` `--doc-format xml\|markdown` `--parent-token` | 已核实 |
| 读取 | `docs +fetch` | `--doc` `--doc-format markdown\|xml` `--detail with-ids` `--scope keyword\|section\|range` | 已实测 |
| 搜索 | `docs +search` | 见 `--help` | 已核实存在 |
| 更新 | `docs +update` | `--command str_replace\|block_replace\|block_insert_after\|block_delete\|block_move_after\|append` | 已实测 |
| 重命名 | `drive +update-title` | `--url <URL> --title <新名>` | 已核实（docs 域无 rename） |
| 附件上传 | `docs +media-upload` | `--doc-id --parent-node --parent-type docx_file --file` | 已实测 |
| 附件插入 | `docs +media-insert` | 见 `--help` | 已核实 |
| 附件下载 | `docs +media-download` | 见 `--help` | 已核实 |
| 历史 | `docs +history-list` | `--doc` | 已核实 |

**禁止**：`docs +update --command overwrite` 作为默认更新方式（会清掉附件）。只有老板明确授权整体替换才允许。

### docs +update 五种已实测操作

| 操作 | 必填参数 | 用途 |
|-|-|-|
| `str_replace` | `--pattern` + `--content`（可为空=删除） | 纯文本替换，不改结构 |
| `block_replace` | `--block-id` + `--content` | 整块替换；ID 保持稳定 |
| `block_insert_after` | `--block-id` + `--content` | 插入新块；可一次插多个 |
| `block_delete` | `--block-id` | 删除块 |
| `block_move_after` | `--block-id` + `--src-block-ids`（逗号分隔） | 整章移动，不删除重建 |

**XML 模式硬坑**：`<p>` 里写 `**text**` 是字面星号，加粗必须用 `<b>`。写完回读 `**` 计数应为 0（故意示例除外）。

## 2. Base 多维表格

| 能力 | 命令 | 关键参数 | 核实状态 |
|-|-|-|-|
| 新建 Base | `base +base-create` | `--title` `--folder-token` `--fields` `--table-name` | 已核实 |
| 读取 Base | `base +base-get` | 见 `--help` | 已核实 |
| 新建数据表 | `base +table-create` | `--base-token --name --fields` | 已核实 |
| 重命名表 | `base +table-update` | 见 `--help` | 已核实 |
| 新建字段 | `base +field-create` | `--base-token --table-id --json` | 已核实 |
| 更新字段 | `base +field-update` | 见 `--help` | 已核实 |
| 新增/更新记录 | `base +record-upsert` | 见 `--help` | 已核实（**不是** record-create） |
| 批量更新 | `base +record-batch-update` | 见 `--help` | 已核实 |
| 查询记录 | `base +record-list` | `--base-token --table-id --limit --filter-json --sort-json` | 已核实 |
| 单条读取 | `base +record-get` | 见 `--help` | 已核实 |
| 搜索记录 | `base +record-search` | 见 `--help` | 已核实 |
| 视图列表/改名 | `base +view-*` / `+view-rename` | 见 `--help` | 已核实 |
| 重命名 Base | `drive +update-title --url <URL>` | `--type bitable` | 已核实 |

**写入硬规则**：
- 写枚举字段前先读字段定义和合法选项，不得猜枚举值
- 批量写入返回 ok 不代表全部成功，必须逐条回读
- 写完等 15–20 秒再验（最终一致），不要立刻重写

## 3. Sheets 电子表格

| 能力 | 命令 | 关键参数 | 核实状态 |
|-|-|-|-|
| 读取单元格 | `sheets +cells-get` | `--range A1:F10` `--sheet-id/--sheet-name` `--output-path` | 已核实 |
| 写入单元格 | `sheets +cells-set` | `--range` `--cells '[[{value:...}]]'` `--allow-overwrite` | 已核实 |
| 清空 | `sheets +cells-clear` | 见 `--help` | 已核实（**破坏性，需授权**） |
| 批量更新 | `sheets +batch-update` | 见 `--help` | 已核实 |
| 调整列宽 | `sheets +cols-resize` | `--range`（列字母）+ `--width` 像素 | 已核实 |
| 子表改名 | `sheets +sheet-rename` | 见 `--help` | 已核实 |
| 文件改名 | `drive +update-title --url <URL>` | `--type sheet` | 已核实 |
| 新建电子表格 | `sheets +workbook-create` | `--values` 或 `--sheets`（可一步创建+写入） | 已核实（不是 drive +import） |

写入硬规则：写后回读；清空必须明确范围并经授权。

## 4. Drive 文件管理

| 能力 | 命令 | 核实状态 |
|-|-|-|
| 创建文件夹 | `drive +create-folder` | 已核实 |
| 文件列表 | `drive files list --folder-token --page-all` | 已实测 |
| 移动 | `drive +move` | 已核实 |
| 复制 | `drive +copy` | 已核实 |
| 删除 | `drive +delete` | 已核实（**默认禁止自动执行**） |
| 重命名（通用） | `drive +update-title --url\|--token --type --title` | 已实测核实 |
| 导入/导出 | `drive +import` / `+export` | 已核实，扩展能力 |

`+update-title` 支持类型：`docx|sheet|bitable|base|slides|file|folder|wiki|apps|doc|mindnote`。
注意：wikinode 改名用 wiki token（`/wiki/` URL 里的），不是底层文档 token；批量改名为限流操作，必须串行。

## 5. 鉴权与健康检查

| 能力 | 命令 |
|-|-|
| 当前身份 | `lark-cli whoami` |
| 鉴权状态 | `lark-cli auth status` |
| 健康检查 | `lark-cli doctor` |

**误报处理**：状态脚本报 `not_installed` 时，必须再用 `lark-cli auth status` 复核；复核结果优先于脚本误判。
