# 飞书读写操作规则（违反即失败）

## 1. 非破坏性更新（最高优先级）

- 文档更新只用 `str_replace` / `block_replace` / `block_insert_after` / `block_delete` / `block_move_after`
- **禁止把 `overwrite` 当默认更新方式**——会清掉附件和历史结构
- 只有老板明确说"整篇替换"时才允许 overwrite，且执行前必须提醒风险

## 2. 附件两步法

上传附件必须：定位目标块 → `docs +media-upload` 拿 token → `block_insert_after` 插 `<figure><source .../></figure>` → 回读核对 name/size/token。
`docs +media-insert` 只能追加到文末，不能指定位置。

## 3. 写后回读

写操作返回成功 ≠ 写对了。必须回读核对：

| 对象 | 回读方式 |
|-|-|
| 文档 | `docs +fetch --doc <url> --doc-format markdown`，核对期望文本/块结构 |
| Base 记录 | `base +record-get`，逐字段比对实际值 |
| Sheets 单元格 | `sheets +cells-get --range`，核对写入值 |

Base 写入最终一致：写完等 15–20 秒再验，不要立刻重写；返回 ok 不代表全部成功，要逐条回读。

## 4. Base 枚举预读

写枚举/单选/多选字段前，先 `base +field-list` 或 `+base-get` 读字段定义和合法选项，**不得猜枚举值**。
本轮实测踩坑：写了不存在的枚举值会导致整批拒绝且不指明字段。失败时用最小字段集二分定位。

## 5. 破坏性操作需授权

以下默认禁止自动执行，必须老板明确授权：
- `drive +delete`（删除文件/文件夹）
- `sheets +cells-clear`（清空单元格）
- `base +record-delete`
- 任何批量修改已有业务数据

## 6. 错误处理

- `lark-cli` 是外部依赖：找不到时报 `CLI_MISSING/BLOCKED`，不假装成功
- 状态脚本报 `not_installed` 时，必须用 `lark-cli auth status` 复核，复核优先
- 保留官方 CLI 原始退出码、stdout、stderr，不把失败包装成成功
- 错误分类见 `lib/errors.js`：PASS/PARTIAL/FAIL/BLOCKED/UNKNOWN

## 7. XML 模式硬坑

`<p>` 里写 Markdown 的 `**text**` 是字面星号，不会变粗体；加粗必须用 `<b>`。
写完用回读检查字面 `**` 计数（故意示例除外）。

## 8. 自检诚实性

- 命令帮助可达 ≠ 读写成功；必须真实读固定资源、在专用测试资源写入回读
- 没配置测试资源 → F8 标 BLOCKED，整体 PARTIAL，不假 PASS
- 不得拿老板正式业务资料做自检写入
