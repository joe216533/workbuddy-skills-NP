---
name: feishu-readwrite
description: 飞书读写技能。覆盖飞书文档（新建/读取/搜索/非破坏性更新 str_replace·block_replace·block_insert_after·block_delete·block_move_after/改名/附件上传插入下载/历史）、多维表格 Base（新建 Base/建表/字段创建更新删除/记录新增更新批量更新查询搜索/视图读写与可见字段/字段选项分页/公式字段与跨表复刻/改名）、电子表格 Sheets（新建/单元格读写/清空/批量更新/列宽/子表与文件改名）、Drive（文件夹创建/列表/移动/复制/改名/导入导出）。内置非破坏性更新、Base 枚举预读与字段坑处理、写后回读、受阻报告、F1–F8 自检和顾问协作规则。本包提供轻量 CLI，底层调用官方 lark-cli。当需要读写飞书文档、多维表格、电子表格，或做跨表复刻、字段/记录批量处理时使用。 当用户发送「【全局技能自查】」时，必须转交 global-skill-check 全局自查入口，检查本机全部已安装自建技能，不得只检查当前技能。
display_name: "飞书读写技能"
display_name_en: "Feishu Read Write"
description_zh: "飞书文档（新建/读取/搜索/非破坏性更新/改名/附件/历史）、多维表格 Base（建库建表/字段/记录/视图/选项分页/公式与跨表复刻）、电子表格（新建/单元格读写/批量更新/改名）、Drive 文件管理；内置字段坑处理、枚举预读、写后回读、受阻报告与自检。"
description_en: "Feishu Docs (create/read/search/non-destructive update/rename/attachments/history), Base (create base & tables, fields, records, views, option pagination, formulas and cross-table replication), Sheets (create, cell read/write, batch update, rename), Drive file management; includes field pitfalls, enum pre-read, read-back verification, blocked-report template and selfcheck."
version: 1.0.4
version_token: "c6c7de8f33daf811"
---

# 飞书读写技能

## 定位

**本包自有轻量 CLI + 官方 lark-cli 后端**。本包负责统一入口、依赖检查、操作规范、写后回读、自检与错误报告；官方 lark-cli 负责实际飞书 API 调用。

- `lark-cli` 是外部依赖，**允许调用**；不复制进包、不重新实现飞书 API
- **不借用 `lark-unified` skill 的目录**，不读取其他自建技能目录
- 技能四「飞书技能（第三方安装语言）」与本技能互相独立，本技能不得依赖技能四
- 账号凭据使用官方 lark-cli 当前授权，不打包、不复制

## 前置条件

- Node ≥ 18
- 本机已安装并授权 `lark-cli`（v1.0.98 实测可用）
- 写操作在专用测试资源上验证；不得拿正式业务资料做自检

## 统一入口

```bash
node bin/feishu.js doctor                       # 依赖 + 鉴权 + 版本概览
node bin/feishu.js selfcheck                    # F1–F8 自检
node bin/feishu.js cli <lark-cli 参数...>        # 官方命令透传（保留原退出码）
node bin/feishu.js verify-doc <URL> <文本>       # 文档写入回读
node bin/feishu.js verify-cell <token> <range> <值...>  # 表格回读
```

具体命令映射见 `references/command-map.md`（逐条核实过真实参数）。
操作规则见 `references/operation-rules.md`（**必读**，违反即失败）。

## 首版支持的能力

### Docs 文档
新建、读取、搜索、更新（str_replace / block_replace / block_insert_after / block_delete / block_move_after）、重命名（docs 域无 rename，用 `drive +update-title`）、附件上传+插入+下载、历史列表。
**禁止默认 overwrite**。

### Base 多维表格
新建 Base、读取、建表、表改名、字段创建/更新/删除、记录新增/更新/批量更新/查询/搜索、视图读写与可见字段、字段选项分页搜索、公式字段与跨表复刻、Base 改名（`drive +update-title --type bitable`）。

**八条实测坑（详见 `references/operation-rules.md` 第4.1节）**：
1. 字段无移动/插入接口，位置只由创建顺序定；改顺序要删列重建（丢数据），建表时就要排好序
2. `field-list` 是随机序，真实显示序走 `base +view-get-visible-fields`
3. `field-list` 选项只给 50 个，多的用 `base +field-search-options --limit` 分页（上限 200）
4. 主字段强制第一，不可删不可移
5. 公式跨表复制必须替换表达式里的硬编码表名；建公式字段前先读官方建字段指南（不要编造 `--i-have-read-guide`，本机 v1.0.98 无此参数）
6. 删字段无批量，单条 `field-delete` + 高危写 `--yes`，35 列约两分钟
7. 公式列不能写值，写入前按字段类型跳过
8. datetime 自动创建时间字段：复刻时**不带** `record_created_time` 占位符，直接写源记录真实时间，否则被盖成本表创建时间

**写枚举前必须预读字段定义**；写后逐条回读。

### Sheets 电子表格
新建（`sheets +workbook-create`）、单元格读取/写入/清空、批量更新、列宽调整、子表改名、文件改名。
**清空属破坏性操作，需授权**。

### Drive
创建文件夹、文件列表、移动、复制、文件改名、导入导出。
**删除默认禁止自动执行**。

## 硬规则

1. 非破坏性更新是默认；overwrite 只有老板明确授权才允许
2. 附件两步法：定位块 → media-upload → block_insert_after → 回读
3. 写后必须回读，不能只看 CLI 返回成功
4. Base 枚举字段写入前预读合法选项，不猜
5. **批量业务数据修改**：目标/范围/计算规则明确时视为已授权，不得仅以"默认禁止"拒绝；目标不明确才追问。删文件/清单元格/删记录仍需再次确认。详见 `references/operation-rules.md` 第5节
6. 状态脚本报 not_installed 时用 `lark-cli auth status` 复核，复核优先
7. XML 模式加粗用 `<b>`，不是 `**text**`
8. 自检不假 PASS：没测试资源标 BLOCKED，帮助可达不算读写成功
9. **【最高优先级】后端不可用（无 CLI / 无授权 / 调用失败 / 未真实写入）时，禁止使用"已创建/已建好/已更新/已改名/已上传/已共享/已生成链接"等完成态表述**。本地 JSON/草稿/计算/计划一律标【本地草稿，未提交飞书】；链接必须来自真实创建或读取结果，禁止拼接。按第5.2节输出受阻报告（任务目标/执行状态/阻塞原因/已有产物/下一步条件），受阻报告不算业务完成
10. **部署边界**：本技能依赖本机已安装并授权的官方 lark-cli；已在本机验证，**WorkBuddy 平台隔离环境未预装 CLI 也无授权，平台版未通过、暂不支持平台内真实飞书读写**。平台恢复条件：提供可用的飞书连接器 / MCP / 受控 API 接入

## 自检 F1–F8 与退出码

| 项 | 内容 |
|-|-|
| F1 | 本包完整性 |
| F2 | Node 环境 ≥18 |
| F3 | 官方 lark-cli 可定位、版本可读 |
| F4 | 鉴权有效 |
| F5 | Docs 命令域可达 |
| F6 | Base 命令域可达 |
| F7 | Sheets 命令域可达 |
| F8 | 专用测试资源写入+回读闭环 |

状态：`PASS / PARTIAL / FAIL / BLOCKED / UNKNOWN`
退出码：PASS=0、FAIL=1、BLOCKED=2、PARTIAL=3

## 自检诚实性

- 帮助可达 ≠ 读写成功；必须真实读固定资源
- 没配置 `tests/test-resources.json` → F8 标 BLOCKED，整体 PARTIAL，不假 PASS
- 不拿正式业务资料做自检写入
- 自检写入带唯一标识，回读确认后按规定清理，清理失败要报告遗留


## 版本检查（只读，独立于自检）

本技能带统一只读版本检查器。按 00A 第21节，版本唯一权威是 GitHub 正式发布 Tag，manifest.json / SKILL.md / 00C / 安装语言 / 包名都是镜像。

```bash
node scripts/check-version.js            # 本地 + 远程（网络失败自动降级）
node scripts/check-version.js --offline  # 仅本地，主动离线
node scripts/check-version.js --json     # JSON 输出
```

退出码：0=通过；1=版本不一致或本地落后；2=本地文件异常；3=本地通过但远程不可用（主动离线不返回 3）；4=检查器异常。

硬边界：检查器**只读**，不修改/下载/覆盖任何文件，不启动 VPN、不改代理。发现新版只提示，绝不自行升级。升级必须走 00A 第20节（用户确认 + 备份 + 迁移 + 回滚）。远程不可用时只做本地检查，不得误判技能损坏或已最新。版本检查不改变原有 verify/selfcheck 行为与退出码。


## 调用版本门禁（强制）

本技能内置只读版本门禁检查器。**每次技能调用开始时，必须先执行一次：**

```bash
node scripts/check-version.js
```

门禁判定（`EXECUTION_ALLOWED`）：
- `YES`（VERSION_STATUS=CURRENT 且 INTEGRITY_STATUS=PASS）→ 允许执行业务操作
- `NO` → **STOP，禁止执行任何业务操作**，按提示升级或修复后再试

STOP 情形：本地版本落后 / 本地版本高于最新 Tag（异常）/ manifest 与 SKILL.md 版本不一致 / 关键文件缺失 / 远程查询不可用（含主动离线）。

规则：
- 检查器只读，不改文件、不下载、不启动 VPN、不改代理
- 一次技能调用只查一次，本轮多个子步骤共用结果；网络超时 8 秒，失败不无限重试
- 远程不可用时**不允许默默使用旧版**
- 门禁是协议级约束（SKILL.md 指令），不是平台底层不可绕过的锁；执行方必须如实遵守


## 技能版本主动检查与老对话热升级（00A 第22节）

### 触发条件
老板明确发出以下固定指令时，启动本技能版本检查：
- **检查本技能版本**（推荐固定口令）
- 检查技能更新 / 技能版本检查 / 是否有最新版 / "技能更新了，检查一下"
- `/技能检查`（仅当平台支持该命令时）

判定意图：只在老板**明确要求检查或升级**时触发。若老板只是讨论技能更新、询问方案，或明确说"先不要动"，**不得自动启动安装或升级**。只要求检查时，只检查不安装。

### 执行动作
收到指令后：①确认当前技能 ID；②确认当前对话已加载的技能身份及可读版本；③运行 `node scripts/check-version.js`；④检查本机版本、远程版本、完整性、门禁；⑤输出统一报告；⑥发现新版进入"等待老板审批"状态。

### 结果处理
- 同版本且完整 → 报告无需升级，不下载、不备份、不覆盖
- 发现新版 → 报告差异，等待老板批准（**发现新版 ≠ 获得升级授权**）
- 本机版本高于目标 → STOP，禁止降级
- 版本不明 / 网络失败 / 完整性异常 → STOP
- 检查脚本无法运行 → 报告检查未完成，不得猜测结果

### 老对话热升级衔接
老板批准升级后：按正式 SOP 执行 → 不得自动覆盖当前对话上下文 → 本机升级完成后**重新读取最新版 SKILL.md 及必要参考文件** → 重新执行调用门禁 → 分别报告三个独立状态：【本机升级成功】【当前对话已加载】【业务验证成功】。

平台边界：若当前对话无法重新读取最新版技能说明，必须明确报告"本机已升级，但当前对话尚未完成新版加载"，**不得谎称热升级成功**。SKILL.md 只能要求智能体执行这些动作，不能保证 WorkBuddy 一定清空旧上下文或自动刷新技能定义——这一能力须经实际平台测试确认。

### 权限限制
本规则只授权检查和报告。任何覆盖安装、恢复、降级均须老板明确批准，且批准必须对应具体技能 ID 和目标版本。


## 版本自报（L1 间接验证，00A 第24节）

收到【全局技能自查】时，除运行本机检查外，必须独立执行本对话的版本自报：

1. 只从**当前对话实际可用的技能定义**（本 SKILL.md frontmatter）读取 `version` 与 `version_token`，不得从磁盘 manifest、release-index、暗语中的目标版本或历史聊天记录取值。
2. 报告：官方目标版本（暗语给出）｜当前对话自报版本｜版本标记是否匹配｜证据来源（当前可访问的 SKILL.md）｜L1 状态。
3. 无法读取当前实际可用技能定义时，报 `UNKNOWN`，不得猜测、不得用磁盘版本代替。
4. L1 是间接证据。不得把 L1 MATCH 说成平台已确认加载最新版（L2）。

本技能版本标记 `version_token` 随正式版本发布；发新版时必须同步更新 frontmatter、release-index、checksums 与 00C 暗语。
