---
name: feishu-readwrite
description: 飞书读写技能。覆盖飞书文档（新建/读取/搜索/非破坏性更新 str_replace·block_replace·block_insert_after·block_delete·block_move_after/改名/附件上传插入下载/历史）、多维表格 Base（新建 Base/建表/字段创建更新删除/记录新增更新批量更新查询搜索/视图读写与可见字段/字段选项分页/公式字段与跨表复刻/改名）、电子表格 Sheets（新建/单元格读写/清空/批量更新/列宽/子表与文件改名）、Drive（文件夹创建/列表/移动/复制/改名/导入导出）。内置非破坏性更新、Base 枚举预读与字段坑处理、写后回读、受阻报告、F1–F8 自检和顾问协作规则。本包提供轻量 CLI，底层调用官方 lark-cli。当需要读写飞书文档、多维表格、电子表格，或做跨表复刻、字段/记录批量处理时使用。
display_name: "飞书读写技能"
display_name_en: "Feishu Read Write"
description_zh: "飞书文档（新建/读取/搜索/非破坏性更新/改名/附件/历史）、多维表格 Base（建库建表/字段/记录/视图/选项分页/公式与跨表复刻）、电子表格（新建/单元格读写/批量更新/改名）、Drive 文件管理；内置字段坑处理、枚举预读、写后回读、受阻报告与自检。"
description_en: "Feishu Docs (create/read/search/non-destructive update/rename/attachments/history), Base (create base & tables, fields, records, views, option pagination, formulas and cross-table replication), Sheets (create, cell read/write, batch update, rename), Drive file management; includes field pitfalls, enum pre-read, read-back verification, blocked-report template and selfcheck."
version: 1.0.4
---

# 飞书读写技能

## 定位

**本包自有轻量 CLI + 官方 lark-cli 后端**。本包负责统一入口、依赖检查、操作规范、写后回读、自检与错误报告；官方 lark-cli 负责实际飞书 API 调用。

- `lark-cli` 是外部依赖，**允许调用**；不复制进包、不重新实现飞书 API
- **不借用 `lark-unified` skill 的目录**，不读取其他自建技能目录
- 技能四「飞书技能（第三方安装语言）」与本技能互相独立，本技能不得依赖技能四
- 账号凭据使用官方 lark-cli 当前授权，不打包、不复制

## 前置条件

- Node ≥ 18
- 本机已安装并授权 `lark-cli`（v1.0.98 实测可用）
- 写操作在专用测试资源上验证；不得拿正式业务资料做自检

## 统一入口

```bash
node bin/feishu.js doctor                       # 依赖 + 鉴权 + 版本概览
node bin/feishu.js selfcheck                    # F1–F8 自检
node bin/feishu.js cli <lark-cli 参数...>        # 官方命令透传（保留原退出码）
node bin/feishu.js verify-doc <URL> <文本>       # 文档写入回读
node bin/feishu.js verify-cell <token> <range> <值...>  # 表格回读
```

具体命令映射见 `references/command-map.md`（逐条核实过真实参数）。
操作规则见 `references/operation-rules.md`（**必读**，违反即失败）。

## 首版支持的能力

### Docs 文档
新建、读取、搜索、更新（str_replace / block_replace / block_insert_after / block_delete / block_move_after）、重命名（docs 域无 rename，用 `drive +update-title`）、附件上传+插入+下载、历史列表。
**禁止默认 overwrite**。

### Base 多维表格
新建 Base、读取、建表、表改名、字段创建/更新/删除、记录新增/更新/批量更新/查询/搜索、视图读写与可见字段、字段选项分页搜索、公式字段与跨表复刻、Base 改名（`drive +update-title --type bitable`）。

**八条实测坑（详见 `references/operation-rules.md` 第4.1节）**：
1. 字段无移动/插入接口，位置只由创建顺序定；改顺序要删列重建（丢数据），建表时就要排好序
2. `field-list` 是随机序，真实显示序走 `base +view-get-visible-fields`
3. `field-list` 选项只给 50 个，多的用 `base +field-search-options --limit` 分页（上限 200）
4. 主字段强制第一，不可删不可移
5. 公式跨表复制必须替换表达式里的硬编码表名；建公式字段前先读官方建字段指南（不要编造 `--i-have-read-guide`，本机 v1.0.98 无此参数）
6. 删字段无批量，单条 `field-delete` + 高危写 `--yes`，35 列约两分钟
7. 公式列不能写值，写入前按字段类型跳过
8. datetime 自动创建时间字段：复刻时**不带** `record_created_time` 占位符，直接写源记录真实时间，否则被盖成本表创建时间

**写枚举前必须预读字段定义**；写后逐条回读。

### Sheets 电子表格
新建（`sheets +workbook-create`）、单元格读取/写入/清空、批量更新、列宽调整、子表改名、文件改名。
**清空属破坏性操作，需授权**。

### Drive
创建文件夹、文件列表、移动、复制、文件改名、导入导出。
**删除默认禁止自动执行**。

## 硬规则

1. 非破坏性更新是默认；overwrite 只有老板明确授权才允许
2. 附件两步法：定位块 → media-upload → block_insert_after → 回读
3. 写后必须回读，不能只看 CLI 返回成功
4. Base 枚举字段写入前预读合法选项，不猜
5. **批量业务数据修改**：目标/范围/计算规则明确时视为已授权，不得仅以"默认禁止"拒绝；目标不明确才追问。删文件/清单元格/删记录仍需再次确认。详见 `references/operation-rules.md` 第5节
6. 状态脚本报 not_installed 时用 `lark-cli auth status` 复核，复核优先
7. XML 模式加粗用 `<b>`，不是 `**text**`
8. 自检不假 PASS：没测试资源标 BLOCKED，帮助可达不算读写成功
9. **【最高优先级】后端不可用（无 CLI / 无授权 / 调用失败 / 未真实写入）时，禁止使用"已创建/已建好/已更新/已改名/已上传/已共享/已生成链接"等完成态表述**。本地 JSON/草稿/计算/计划一律标【本地草稿，未提交飞书】；链接必须来自真实创建或读取结果，禁止拼接。按第5.2节输出受阻报告（任务目标/执行状态/阻塞原因/已有产物/下一步条件），受阻报告不算业务完成
10. **部署边界**：本技能依赖本机已安装并授权的官方 lark-cli；已在本机验证，**WorkBuddy 平台隔离环境未预装 CLI 也无授权，平台版未通过、暂不支持平台内真实飞书读写**。平台恢复条件：提供可用的飞书连接器 / MCP / 受控 API 接入

## 自检 F1–F8 与退出码

| 项 | 内容 |
|-|-|
| F1 | 本包完整性 |
| F2 | Node 环境 ≥18 |
| F3 | 官方 lark-cli 可定位、版本可读 |
| F4 | 鉴权有效 |
| F5 | Docs 命令域可达 |
| F6 | Base 命令域可达 |
| F7 | Sheets 命令域可达 |
| F8 | 专用测试资源写入+回读闭环 |

状态：`PASS / PARTIAL / FAIL / BLOCKED / UNKNOWN`
退出码：PASS=0、FAIL=1、BLOCKED=2、PARTIAL=3

## 自检诚实性

- 帮助可达 ≠ 读写成功；必须真实读固定资源
- 没配置 `tests/test-resources.json` → F8 标 BLOCKED，整体 PARTIAL，不假 PASS
- 不拿正式业务资料做自检写入
- 自检写入带唯一标识，回读确认后按规定清理，清理失败要报告遗留


## 版本检查（只读，独立于自检）

本技能带统一只读版本检查器。按 00A 第21节，版本唯一权威是 GitHub 正式发布 Tag，manifest.json / SKILL.md / 00C / 安装语言 / 包名都是镜像。

```bash
node scripts/check-version.js            # 本地 + 远程（网络失败自动降级）
node scripts/check-version.js --offline  # 仅本地，主动离线
node scripts/check-version.js --json     # JSON 输出
```

退出码：0=通过；1=版本不一致或本地落后；2=本地文件异常；3=本地通过但远程不可用（主动离线不返回 3）；4=检查器异常。

硬边界：检查器**只读**，不修改/下载/覆盖任何文件，不启动 VPN、不改代理。发现新版只提示，绝不自行升级。升级必须走 00A 第20节（用户确认 + 备份 + 迁移 + 回滚）。远程不可用时只做本地检查，不得误判技能损坏或已最新。版本检查不改变原有 verify/selfcheck 行为与退出码。
