---
name: feishu-readwrite
description: 飞书读写技能。统一封装飞书文档（新建/读取/非破坏性更新/搜索/附件/重命名）、多维表格 Base（新建/建表/字段/记录增改查/视图）、电子表格 Sheets（新建/单元格读写/批量更新/重命名）和 Drive 文件管理的常用操作。本包提供统一 CLI 与自检，底层调用官方全局 lark-cli。当需要读写飞书文档、多维表格或电子表格时使用。
display_name: "飞书读写技能"
display_name_en: "Feishu Read Write"
description_zh: "飞书文档、多维表格 Base、电子表格 Sheets 与 Drive 的常用读写操作封装，含非破坏性更新、写后回读与自检；底层调用官方 lark-cli。"
description_en: "Feishu Docs, Base, Sheets and Drive read/write operations with non-destructive updates, read-back verification and selfcheck; backed by official lark-cli."
version: 1.0.1
---

# 飞书读写技能

## 定位

**本包自有轻量 CLI + 官方 lark-cli 后端**。本包负责统一入口、依赖检查、操作规范、写后回读、自检与错误报告；官方 lark-cli 负责实际飞书 API 调用。

- `lark-cli` 是外部依赖，**允许调用**；不复制进包、不重新实现飞书 API
- **不借用 `lark-unified` skill 的目录**，不读取其他自建技能目录
- 技能四「飞书技能（第三方安装语言）」与本技能互相独立，本技能不得依赖技能四
- 账号凭据使用官方 lark-cli 当前授权，不打包、不复制

## 前置条件

- Node ≥ 18
- 本机已安装并授权 `lark-cli`（v1.0.98 实测可用）
- 写操作在专用测试资源上验证；不得拿正式业务资料做自检

## 统一入口

```bash
node bin/feishu.js doctor                       # 依赖 + 鉴权 + 版本概览
node bin/feishu.js selfcheck                    # F1–F8 自检
node bin/feishu.js cli <lark-cli 参数...>        # 官方命令透传（保留原退出码）
node bin/feishu.js verify-doc <URL> <文本>       # 文档写入回读
node bin/feishu.js verify-cell <token> <range> <值...>  # 表格回读
```

具体命令映射见 `references/command-map.md`（逐条核实过真实参数）。
操作规则见 `references/operation-rules.md`（**必读**，违反即失败）。

## 首版支持的能力

### Docs 文档
新建、读取、搜索、更新（str_replace / block_replace / block_insert_after / block_delete / block_move_after）、重命名（docs 域无 rename，用 `drive +update-title`）、附件上传+插入+下载、历史列表。
**禁止默认 overwrite**。

### Base 多维表格
新建 Base、读取、建表、表改名、字段创建/更新、记录新增/更新/批量更新/查询/搜索、视图操作、Base 改名（`drive +update-title --type bitable`）。
**写枚举前必须预读字段定义**；写后逐条回读。

### Sheets 电子表格
新建（`sheets +workbook-create`）、单元格读取/写入/清空、批量更新、列宽调整、子表改名、文件改名。
**清空属破坏性操作，需授权**。

### Drive
创建文件夹、文件列表、移动、复制、文件改名、导入导出。
**删除默认禁止自动执行**。

## 硬规则

1. 非破坏性更新是默认；overwrite 只有老板明确授权才允许
2. 附件两步法：定位块 → media-upload → block_insert_after → 回读
3. 写后必须回读，不能只看 CLI 返回成功
4. Base 枚举字段写入前预读合法选项，不猜
5. 破坏性操作（删文件/清单元格/删记录/批量改业务数据）默认禁止
6. 状态脚本报 not_installed 时用 `lark-cli auth status` 复核，复核优先
7. XML 模式加粗用 `<b>`，不是 `**text**`
8. 自检不假 PASS：没测试资源标 BLOCKED，帮助可达不算读写成功

## 自检 F1–F8 与退出码

| 项 | 内容 |
|-|-|
| F1 | 本包完整性 |
| F2 | Node 环境 ≥18 |
| F3 | 官方 lark-cli 可定位、版本可读 |
| F4 | 鉴权有效 |
| F5 | Docs 命令域可达 |
| F6 | Base 命令域可达 |
| F7 | Sheets 命令域可达 |
| F8 | 专用测试资源写入+回读闭环 |

状态：`PASS / PARTIAL / FAIL / BLOCKED / UNKNOWN`
退出码：PASS=0、FAIL=1、BLOCKED=2、PARTIAL=3

## 自检诚实性

- 帮助可达 ≠ 读写成功；必须真实读固定资源
- 没配置 `tests/test-resources.json` → F8 标 BLOCKED，整体 PARTIAL，不假 PASS
- 不拿正式业务资料做自检写入
- 自检写入带唯一标识，回读确认后按规定清理，清理失败要报告遗留
