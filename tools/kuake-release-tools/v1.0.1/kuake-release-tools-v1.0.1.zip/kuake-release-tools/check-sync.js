#!/usr/bin/env node
/**
 * check-sync.js —— 检查技能发布三处是否同步
 *
 * 用法:
 *   node check-sync.js [技能英文名]
 *   默认 kuake-quarkclouddrive
 *
 * 比对三处:
 *   ① GitHub 最新 tag 与根目录 zip
 *   ② 夸克当前目录里的包名与字节数
 *   ③ 飞书目录指南第 4 项版本 / 第 6 项直链 tag
 *
 * 退出码: 0 三处一致 / 1 存在不一致 / 2 检查过程受阻
 */
const https = require('https');
const { execFileSync } = require('child_process');
const fs = require('fs');

// 环境配置：全部可用环境变量覆盖；默认值仅为发布者本机示例，其他机器必须显式设置。
//   KQ_OWNER / KQ_DOC / KQ_LARK / KQ_QCLI / KQ_QUARK_DIR / KQ_PROXY
const SKILL = process.argv[2] || process.env.KQ_SKILL || 'kuake-quarkclouddrive';
const OWNER = process.env.KQ_OWNER || 'joe216533';
const REPO = process.env.KQ_REPO || SKILL;
const DOC = process.env.KQ_DOC || 'https://e0undhzt9zh.feishu.cn/docx/UVgedPwzMoPzwvx75OHcLtCEngc';
const LARK = process.env.KQ_LARK || 'C:\\Users\\2019joe\\.workbuddy\\binaries\\node\\cli-connector-packages\\lark-cli.cmd';
const QCLI = process.env.KQ_QCLI || 'C:/Users/2019joe/.workbuddy/skills/quarkclouddrive/scripts/quark-drive.cjs';
const QUARK_DIR = process.env.KQ_QUARK_DIR || '~1wf7MrD2JFYgv2g9J2joX9MCwUfcjwJzdItq7jmH0-DP6kqMclKZQgNh2V3dEBOgJrSKRGBThxUuQBy6XxbSF2I|BIUzk_CShA8';
const PROXY = process.env.KQ_PROXY || 'http://127.0.0.1:11719';

// 用 curl 走代理访问 GitHub（git 已配仓库级代理 11719，但 Node 原生 https 不走它）
// curl -L 自动跟随重定向，-w 取状态码，body 写 stdout
function get(url, headers = {}, redirects = 0) {
  try {
    const out = execFileSync('curl', [
      '-sL', '--proxy', PROXY, '-m', '40',
      '-w', '\n__HTTP_CODE__%{http_code}',
      '-H', 'User-Agent: sync-check', url
    ], { encoding: 'utf8', timeout: 50000, maxBuffer: 20 * 1024 * 1024 });
    const idx = out.lastIndexOf('\n__HTTP_CODE__');
    if (idx < 0) return null;
    const code = Number(out.slice(idx + '__HTTP_CODE__'.length + 1).trim());
    const body = out.slice(0, idx);
    return { code, body };
  } catch { return null; }
}

function run(cmd, args, enc = 'utf8') {
  try {
    // lark-cli 在 Windows 是 .cmd，需要 shell 才能执行
    const opts = { encoding: enc, timeout: 60000, stdio: ['ignore', 'pipe', 'pipe'], maxBuffer: 20 * 1024 * 1024 };
    if (cmd.toLowerCase().endsWith('.cmd')) opts.shell = true;
    return execFileSync(cmd, args, opts);
  } catch (e) { return null; }
}

const rows = [];
let blocked = false;
function add(item, value, status) { rows.push({ item, value, status }); }

(async () => {
  console.log(`=== 三处同步检查：${SKILL} ===\n`);

  // ① GitHub
  let ghTag = null, ghZip = null, ghSize = null;
  const tags = await get(`https://api.github.com/repos/${OWNER}/${REPO}/tags`, { 'User-Agent': 'sync-check' });
  if (tags && tags.code === 200) {
    try {
      const list = JSON.parse(tags.body);
      if (list.length) ghTag = list[0].name;
    } catch { /* ignore */ }
  }
  if (!ghTag) { blocked = true; add('GitHub 最新 tag', '读取失败（网络或鉴权）', 'BLOCKED'); }
  else add('GitHub 最新 tag', ghTag, 'OK');

  const contents = await get(`https://api.github.com/repos/${OWNER}/${REPO}/contents/`, { 'User-Agent': 'sync-check' });
  if (contents && contents.code === 200) {
    try {
      const files = JSON.parse(contents.body).filter((f) => f.name.endsWith('.zip'));
      if (files.length === 1) { ghZip = files[0].name; ghSize = files[0].size; add('仓库根目录 zip', `${ghZip}（${ghSize} B）`, 'OK'); }
      else if (files.length === 0) add('仓库根目录 zip', '未找到', 'BAD');
      else add('仓库根目录 zip', `发现 ${files.length} 个（应只留最新）: ${files.map(f => f.name).join(', ')}`, 'BAD');
    } catch { add('仓库根目录 zip', '解析失败', 'BAD'); }
  } else { blocked = true; add('仓库根目录 zip', '读取失败', 'BLOCKED'); }

  // ② 夸克
  let quarkZip = null, quarkSize = null;
  const out = run('node', [QCLI, 'browse', '--parent-fid', QUARK_DIR, '--session-id', 'syncchk', '--session-input', '同步检查']);
  if (out) {
    for (const line of out.split('\n')) {
      const s = line.trim();
      if (!s.startsWith('{')) continue;
      try {
        const j = JSON.parse(s);
        if (j.action === 'browse' && j.type === 'result') {
          // 只统计本技能的分发包，排除发布工具包等其它交付物（它们也放在同一正式目录）
          const zips = j.data.file_list.filter((f) => f.filename.endsWith('.zip') && f.filename.startsWith(SKILL + '-v'));
          if (zips.length === 1) { quarkZip = zips[0].filename; quarkSize = zips[0].size; }
          else if (zips.length > 1) { quarkZip = zips.map(z => z.filename).join(' | '); }
        }
      } catch { /* ignore */ }
    }
  }
  if (!quarkZip) { blocked = true; add('夸克当前目录 zip', '读取失败（可能需国内直连）', 'BLOCKED'); }
  else if (quarkZip.includes('|')) add('夸克当前目录 zip', `发现多个: ${quarkZip}`, 'BAD');
  else add('夸克当前目录 zip', `${quarkZip}（${quarkSize} B）`, 'OK');

  // ③ 飞书指南
  let docVer = null, docTag = null;
  const raw = run(LARK, ['docs', '+fetch', '--doc', DOC, '--doc-format', 'markdown', '--format', 'json', '--as', 'user']);
  if (raw) {
    try {
      const j = JSON.parse(raw.slice(raw.indexOf('{')));
      const c = j.data.document.content;
      // 只解析「一、夸克网盘相关操作」区段，避免误匹配到「二、模板技能」里的占位版本 v1.0
      const sec = c.split(/二、/)[0];
      const m4 = sec.match(/当前有效版本：\s*v?([0-9.]+)/);
      if (m4) docVer = m4[1];
      const m6 = sec.match(/kuake-quarkclouddrive\/v([0-9.]+)\//);
      if (m6) docTag = m6[1];
    } catch { /* ignore */ }
  }
  if (!docVer && !docTag) { blocked = true; add('飞书指南版本', '读取失败', 'BLOCKED'); }
  else {
    add('飞书第 4 项版本', docVer ? 'v' + docVer : '未找到', docVer ? 'OK' : 'BAD');
    add('飞书第 6 项直链 tag', docTag ? 'v' + docTag : '未找到', docTag ? 'OK' : 'BAD');
  }

  // 汇总比对
  const versions = [];
  if (ghTag) versions.push(ghTag.replace(/^v/, ''));
  if (docVer) versions.push(docVer);
  if (docTag) versions.push(docTag);
  const uniq = [...new Set(versions)];

  let zipMatch = null;
  if (ghZip && quarkZip && !quarkZip.includes('|')) zipMatch = ghZip === quarkZip;
  let sizeMatch = null;
  if (ghSize && quarkSize) sizeMatch = ghSize === quarkSize;

  console.log('项目                        值');
  console.log('-'.repeat(78));
  for (const r of rows) {
    const flag = r.status === 'OK' ? 'PASS' : r.status === 'BAD' ? 'FAIL' : 'WAIT';
    console.log(`${flag}  ${r.item.padEnd(22)} ${r.value}`);
  }
  if (zipMatch !== null) console.log(`${zipMatch ? 'PASS' : 'FAIL'}  ${'两处包名一致'.padEnd(22)} ${zipMatch ? '是' : '否'}`);
  if (sizeMatch !== null) console.log(`${sizeMatch ? 'PASS' : 'FAIL'}  ${'两处字节数一致'.padEnd(22)} ${sizeMatch ? '是' : '否'}`);
  console.log(`${uniq.length === 1 ? 'PASS' : 'FAIL'}  ${'版本号三处一致'.padEnd(22)} ${uniq.length === 1 ? '是（' + uniq[0] + '）' : '否：' + uniq.join(' / ')}`);

  const bad = rows.some((r) => r.status === 'BAD') || uniq.length > 1 || zipMatch === false || sizeMatch === false;
  console.log('\n' + '='.repeat(78));
  if (blocked && !bad) { console.log('结论：部分检查受阻，结果不完整。'); process.exit(2); }
  if (bad) { console.log('结论：三处不一致，需要同步。'); process.exit(1); }
  console.log('结论：三处一致，发布状态正常。');
  process.exit(0);
})();
