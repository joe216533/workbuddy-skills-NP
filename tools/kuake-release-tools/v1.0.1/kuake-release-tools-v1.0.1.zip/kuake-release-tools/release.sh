#!/usr/bin/env bash
# 技能发布标准流程：一次完成 GitHub + 夸克 + 校验，并输出指南待填块
# 用法: ./release.sh <版本号> [--delete-old-quark]
#   例: ./release.sh 1.0.2
set -euo pipefail

VERSION="${1:-}"; shift || true
DELETE_OLD="false"
for a in "$@"; do [[ "$a" == "--delete-old-quark" ]] && DELETE_OLD="true"; done

if [[ -z "$VERSION" ]]; then echo "用法: $0 <版本号> [--delete-old-quark]"; exit 1; fi

# ---- 环境配置：全部可用环境变量覆盖；默认值仅为发布者本机示例，其他机器必须显式设置 ----
# 用法示例：
#   KQ_BASE=/path/to/发布包 KQ_QCLI=/path/to/quark-drive.cjs \
#   KQ_SKILL_CREATOR=/path/to/skill-creator KQ_PROXY=http://127.0.0.1:11719 \
#   ./release.sh 1.0.4 --delete-old-quark
BASE="${KQ_BASE:-$(cd "$(dirname "$0")" && pwd)}"
SKILL_DIR="$BASE/kuake-quarkclouddrive"
REPO_DIR="${KQ_REPO_DIR:-$BASE/gh-repo}"
OWNER="${KQ_OWNER:-joe216533}"; REPO="${KQ_REPO:-kuake-quarkclouddrive}"
ZIP="kuake-quarkclouddrive-v${VERSION}.zip"; TAG="v${VERSION}"
QUARK_DIR="${KQ_QUARK_DIR:-~1wf7MrD2JFYgv2g9J2joX9MCwUfcjwJzdItq7jmH0-DP6kqMclKZQgNh2V3dEBOgJrSKRGBThxUuQBy6XxbSF2I|BIUzk_CShA8}"
QCLI="${KQ_QCLI:-C:/Users/2019joe/.workbuddy/skills/quarkclouddrive/scripts/quark-drive.cjs}"
SC="${KQ_SKILL_CREATOR:-D:/1、ruanjiananzhuang/wordbudy/WorkBuddy/resources/app.asar.unpacked/resources/plugins/workbuddy-builtin/skills/skill-creator}"
PROXY="${KQ_PROXY:-http://127.0.0.1:11719}"
# git 提交身份（可用环境变量覆盖）
GIT_EMAIL="${KQ_GIT_EMAIL:-joe216533@gmail.com}"; GIT_NAME="${KQ_GIT_NAME:-joe216533}"

echo "===== 发布 v${VERSION} ====="

echo "[1/8] 同步版本号"
python - "$SKILL_DIR" "$VERSION" <<'PY'
import json,sys,re
d,v=sys.argv[1],sys.argv[2]
p=d+'/manifest.json'; m=json.load(open(p,encoding='utf-8'))
m['version']=v; m['package']=f'kuake-quarkclouddrive-v{v}.zip'
open(p,'w',encoding='utf-8',newline='\n').write(json.dumps(m,ensure_ascii=False,indent=2))
s=open(d+'/SKILL.md',encoding='utf-8').read()
s=re.sub(r'^version: ".*"$', f'version: "{v}"', s, count=1, flags=re.M)
open(d+'/SKILL.md','w',encoding='utf-8',newline='\n').write(s)
PY

echo "[2/8] 白名单打包（只收允许的文件，不依赖黑名单）"
STAGE="$BASE/.stage"; rm -rf "$STAGE"; mkdir -p "$STAGE/kuake-quarkclouddrive"
ALLOW="SKILL.md README.md manifest.json scripts references assets LICENSES"
for item in $ALLOW; do
  if [[ -e "$SKILL_DIR/$item" ]]; then cp -r "$SKILL_DIR/$item" "$STAGE/kuake-quarkclouddrive/"; fi
done
python "$SC/scripts/package_skill.py" "$STAGE/kuake-quarkclouddrive" "$STAGE" | tail -1
mv "$STAGE/kuake-quarkclouddrive.zip" "$BASE/$ZIP"
rm -rf "$STAGE"

echo "[3/8] 生成 SHA256"
python - "$BASE" "$ZIP" <<'PY'
import hashlib,sys,os
b,n=sys.argv[1],sys.argv[2]; d=open(os.path.join(b,n),'rb').read()
h=hashlib.sha256(d).hexdigest()
open(os.path.join(b,n+'.sha256'),'w',encoding='utf-8').write(f'{h}  {n}\n')
print('SHA256',h)
PY

echo "[3.5/8] 发布预检（阻断项存在则终止）"
set +e
node "$BASE/preflight.js" "$BASE/$ZIP"; PFC=$?
set -e
if [[ $PFC -eq 1 ]]; then echo "预检发现阻断项，终止发布"; exit 1; fi
if [[ $PFC -eq 2 ]]; then echo "预检有警告（直链尚未生成，属预期），继续"; fi

echo "[3.6/8] 生成发布记录 release-manifest.json"
python - "$BASE" "$ZIP" "$VERSION" "$TAG" "$OWNER" "$REPO" "${KQ_FEISHU_CATALOG:-https://e0undhzt9zh.feishu.cn/docx/UVgedPwzMoPzwvx75OHcLtCEngc}" <<'PY'
import json,sys,os,hashlib,datetime
base,zipname,ver,tag,owner,repo,catalog=sys.argv[1:8]
path=os.path.join(base,zipname)
data=open(path,'rb').read()
sha=hashlib.sha256(data).hexdigest()
rec={
 "skill":repo,"version":ver,"status":"building",
 "published_at":datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
 "operator":"executor",
 "package":{"filename":zipname,"bytes":len(data),"sha256":sha},
 "links":{
   "github_tag":f"https://github.com/{owner}/{repo}/releases/tag/{tag}",
   "github_package":f"https://raw.githubusercontent.com/{owner}/{repo}/{tag}/{zipname}",
   "quark_package":"","feishu_catalog":catalog}
}
open(os.path.join(base,'release-manifest.json'),'w',encoding='utf-8').write(json.dumps(rec,ensure_ascii=False,indent=2))
print('bytes',len(data),'sha256',sha[:16]+'…')
PY

echo "[4/8] 同步仓库（旧版进 archive/，根目录只留最新）"
cd "$REPO_DIR"
mkdir -p archive
for f in kuake-quarkclouddrive-v*.zip kuake-quarkclouddrive-v*.zip.sha256; do
  [[ -e "$f" ]] || continue
  [[ "$f" == "$ZIP" || "$f" == "$ZIP.sha256" ]] && continue
  git mv "$f" "archive/$f" 2>/dev/null || mv "$f" "archive/$f"
done
cp "$BASE/$ZIP" "$BASE/$ZIP.sha256" .
rm -rf skill && cp -r "$SKILL_DIR" skill
git add -A
git -c user.email="$GIT_EMAIL" -c user.name="$GIT_NAME" commit -m "release v${VERSION}" || echo "无变更"

echo "[5/8] 推送 + 打 tag"
git push origin main
git tag -f "$TAG"; git push -f origin "$TAG"

echo "[6/8] 验证直链"
sleep 6
HOST1="https://raw.githubusercontent.com/$OWNER/$REPO/$TAG/$ZIP"
HOST2="https://cdn.jsdelivr.net/gh/$OWNER/$REPO@$TAG/$ZIP"
for u in "$HOST1" "$HOST2"; do
  for i in 1 2 3; do
    code=$(curl -sL --proxy "$PROXY" -o /tmp/_v.zip -w "%{http_code}" -m 40 "$u" || echo 000)
    if [[ "$code" == "200" ]]; then
      echo "  OK  $(stat -c%s /tmp/_v.zip 2>/dev/null || wc -c </tmp/_v.zip) bytes  $u"; break
    fi
    echo "  重试 $i ($code)"; sleep 3
  done
done

echo "[7/8] 上传夸克（需国内直连）"
# 全局出口默认已是国内直连（tun.enable=False），夸克天然走直连；
# 遵守 VPN 共享资源铁律：默认不动全局状态，不调用 vpn.py off。
node "$QCLI" upload "$BASE/$ZIP" --parent-fid "$QUARK_DIR" --session-id "rel$VERSION" --session-input "上传 $ZIP" 2>&1 | tail -1

if [[ "$DELETE_OLD" == "true" ]]; then
  echo "  [旧版本移入夸克归档目录]"
  node "$QCLI" create-folder --dir-path "历史版本" --parent-fid "$QUARK_DIR" --session-id "arc$VERSION" --session-input "建归档目录" >/dev/null 2>&1 || true
  ARC_FID=$(node "$QCLI" browse --parent-fid "$QUARK_DIR" --session-id "arc$VERSION" --session-input "查归档目录" 2>/dev/null   | python -c "
import sys,json
for l in sys.stdin:
    l=l.strip()
    if not l.startswith('{'): continue
    j=json.loads(l)
    if j.get('action')=='browse' and j.get('type')=='result':
        for f in j['data']['file_list']:
            if f['filename']=='历史版本': print(f['fid'])
")
  if [[ -n "${ARC_FID:-}" ]]; then
    node "$QCLI" browse --parent-fid "$QUARK_DIR" --session-id "arc$VERSION" --session-input "列出旧包" 2>/dev/null     | python -c "
import sys,json
for l in sys.stdin:
    l=l.strip()
    if not l.startswith('{'): continue
    j=json.loads(l)
    if j.get('action')=='browse' and j.get('type')=='result':
        for f in j['data']['file_list']:
            if f['filename']!='$ZIP' and f['filename'].endswith('.zip'):
                print(f['fid'])
" > /tmp/_old.txt
    while read -r fid; do
      [[ -z "$fid" ]] && continue
      node "$QCLI" move "$fid" --target-fid "$ARC_FID" --session-id "arc$VERSION" --session-input "归档旧包" 2>&1 | tail -1 || echo "  归档失败: $fid"
    done < /tmp/_old.txt
  else
    echo "  未找到归档目录，跳过"
  fi
fi

echo "[8/8] 创建分享"
FID=$(node "$QCLI" browse --parent-fid "$QUARK_DIR" --session-id "sh$VERSION" --session-input "查FID" 2>/dev/null \
 | python -c "
import sys,json
for l in sys.stdin:
    l=l.strip()
    if not l.startswith('{'): continue
    j=json.loads(l)
    if j.get('action')=='browse' and j.get('type')=='result':
        for f in j['data']['file_list']:
            if f['filename']=='$ZIP': print(f['fid'])
")
node "$QCLI" share "$FID" --title "$ZIP 技能压缩包" --url-type 1 --expired-type 1 --session-id "sh$VERSION" --session-input "创建分享" 2>&1 | tail -1

SHA=$(cut -d' ' -f1 "$BASE/$ZIP.sha256")
SIZE=$(wc -c < "$BASE/$ZIP" | tr -d ' ')
cat <<EOF

================ 发布完成 v${VERSION} ================
SHA256 : ${SHA}
SIZE   : ${SIZE} bytes
主直链 : ${HOST1}
备用链 : ${HOST2}

【必须手动完成的两项（无法自动化）】
1. 飞书目录指南第 4 项：把新附件拖到该字段下方，删除旧附件
2. 飞书目录指南第 5 项：在夸克 App/网页对该文件重新分享，复制含中文口令码的完整文案替换
   —— CLI 无法生成中文口令码，这是平台限制

【指南需要同步的三处】
第 4 项：版本 ${VERSION} / ${ZIP} / ${SIZE} 字节 / SHA256 ${SHA}
第 5 项：见上面手动项
第 6 项：两条直链换成 ${TAG}
=====================================================
EOF
